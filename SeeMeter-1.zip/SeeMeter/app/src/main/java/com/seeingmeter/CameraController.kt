package com.seeingmeter

import android.annotation.SuppressLint
import android.content.Context
import android.graphics.ImageFormat
import android.graphics.SurfaceTexture
import android.hardware.camera2.*
import android.media.ImageReader
import android.os.Handler
import android.os.HandlerThread
import android.util.Log
import android.util.Size
import android.view.Surface
import android.view.TextureView
import java.util.concurrent.Semaphore
import java.util.concurrent.TimeUnit

/**
 * Camera2 controller — Seykora diffuser scintillometer mode.
 *
 * Camera selection: camera "0" (main back camera on all Samsung devices).
 *
 * Resolution selection: maximise ROW COUNT in the YUV stream.
 * More rows per frame → more rolling-shutter time samples → higher effective
 * sample rate (f_s = rows / RS_skew_sec).
 *
 *   1920 × 1080  (1080 rows, RS ~15 ms) → ~72 kHz
 *   3840 × 2160  (2160 rows, RS ~20 ms) → ~108 kHz  ← preferred
 *
 * Full-frame averaging: every row's mean across ALL columns is computed.
 * With a paper diffuser the intensity is spatially uniform, so all columns
 * contribute equally — no ROI selection is needed.
 */
class CameraController(
    private val context: Context,
    private val analyzer: SeeingAnalyzer,
    private val onMetadataUpdate: (skewNs: Long, expNs: Long, iso: Int) -> Unit
) {
    companion object {
        const val TAG = "CameraController"
        const val AE_WARMUP_FRAMES = 90
    }

    /** Per-frame exposure statistics, updated on every frame. */
    data class FrameStats(
        val meanRowMean:   Double,   // mean of all row means      (0–255)
        val peakRowMean:   Double,   // max  of all row means      (0–255)
        val satRows:       Int,      // rows with mean > 250
        val totalRows:     Int,      // total rows in frame
        val meanPct:       Double,   // meanRowMean / 255 * 100
        val peakPct:       Double    // peakRowMean / 255 * 100
    )
    @Volatile var lastFrameStats: FrameStats = FrameStats(0.0,0.0,0,0,0.0,0.0)
        private set

    private val camManager = context.getSystemService(Context.CAMERA_SERVICE) as CameraManager

    private var textureView: TextureView? = null
    private var cameraDevice: CameraDevice? = null
    private var captureSession: CameraCaptureSession? = null
    private var imageReader: ImageReader? = null

    @Volatile private var previewSurface:  Surface? = null
    @Volatile private var analysisSurface: Surface? = null

    private val openLock = Semaphore(1)
    var bgThread: HandlerThread? = null
    var bgHandler: Handler? = null

    var isRunning = false; private set
    private var frameCount = 0
    @Volatile private var aeLocked = false

    // Selected camera info (set in findMainCamera)
    var selectedCameraId:   String = "?"
    var selectedCameraDesc: String = "?"
    var analysisWidth:  Int = 1920
    var analysisHeight: Int = 1080

    // ── Thread management ──────────────────────────────────────────────────────

    fun startBackgroundThread() {
        if (bgThread?.isAlive == true) return
        bgThread = HandlerThread("CamBG").also { it.start() }
        bgHandler = Handler(bgThread!!.looper)
    }

    fun stopBackgroundThread() {
        bgThread?.quitSafely()
        try { bgThread?.join(1000) } catch (_: InterruptedException) {}
        bgThread = null; bgHandler = null
    }

    // ── Attach / detach ────────────────────────────────────────────────────────

    fun attachTextureView(tv: TextureView) {
        textureView = tv
        tv.surfaceTextureListener = surfaceListener
        if (tv.isAvailable) openCameraInternal(tv)
    }

    fun detach() {
        closeCamera()
        textureView?.surfaceTextureListener = null
        textureView = null
    }

    // ── Surface listener ───────────────────────────────────────────────────────

    private val surfaceListener = object : TextureView.SurfaceTextureListener {
        override fun onSurfaceTextureAvailable(st: SurfaceTexture, w: Int, h: Int) {
            textureView?.let { openCameraInternal(it) }
        }
        override fun onSurfaceTextureDestroyed(st: SurfaceTexture): Boolean {
            closeCamera(); return true
        }
        override fun onSurfaceTextureSizeChanged(st: SurfaceTexture, w: Int, h: Int) {}
        override fun onSurfaceTextureUpdated(st: SurfaceTexture) {}
    }

    // ── Open camera (main thread) ──────────────────────────────────────────────

    @SuppressLint("MissingPermission")
    private fun openCameraInternal(tv: TextureView) {
        val st = tv.surfaceTexture ?: return
        st.setDefaultBufferSize(tv.width.coerceAtLeast(640), tv.height.coerceAtLeast(480))

        closeCamera()

        val cameraId = findMainCamera() ?: run { Log.e(TAG, "No back camera"); return }
        val bestSize = getBestYuvSize(cameraId)
        analysisWidth  = bestSize.width
        analysisHeight = bestSize.height
        Log.d(TAG, "Analysis stream: ${analysisWidth}×${analysisHeight}  rows=${analysisHeight}")

        val reader = ImageReader.newInstance(analysisWidth, analysisHeight,
            ImageFormat.YUV_420_888, 3)
        reader.setOnImageAvailableListener(imageListener, bgHandler)
        imageReader    = reader
        previewSurface  = Surface(st)
        analysisSurface = reader.surface

        if (!openLock.tryAcquire(2500, TimeUnit.MILLISECONDS)) {
            Log.e(TAG, "Camera lock timeout"); return
        }
        frameCount = 0; aeLocked = false
        try {
            Log.d(TAG, "Opening camera $cameraId ($selectedCameraDesc)")
            camManager.openCamera(cameraId, deviceCallback, bgHandler)
        } catch (e: Exception) {
            openLock.release()
            Log.e(TAG, "openCamera failed: $e")
        }
    }

    // ── Device callback ────────────────────────────────────────────────────────

    private val deviceCallback = object : CameraDevice.StateCallback() {
        override fun onOpened(camera: CameraDevice) {
            openLock.release(); cameraDevice = camera
            createCaptureSession()
        }
        override fun onDisconnected(camera: CameraDevice) {
            openLock.release(); camera.close(); cameraDevice = null; isRunning = false
        }
        override fun onError(camera: CameraDevice, error: Int) {
            openLock.release(); camera.close(); cameraDevice = null; isRunning = false
            Log.e(TAG, "Camera error $error")
        }
    }

    private fun createCaptureSession() {
        val device = cameraDevice   ?: return
        val pSurf  = previewSurface  ?: return
        val aSurf  = analysisSurface ?: return
        try {
            device.createCaptureSession(listOf(pSurf, aSurf), sessionCallback, bgHandler)
        } catch (e: Exception) { Log.e(TAG, "createCaptureSession: $e") }
    }

    private val sessionCallback = object : CameraCaptureSession.StateCallback() {
        override fun onConfigured(session: CameraCaptureSession) {
            captureSession = session
            startRepeating(session)
            isRunning = true
        }
        override fun onConfigureFailed(session: CameraCaptureSession) {
            Log.e(TAG, "Session configuration FAILED")
        }
    }

    private fun startRepeating(session: CameraCaptureSession) {
        val device = cameraDevice    ?: return
        val pSurf  = previewSurface  ?: return
        val aSurf  = analysisSurface ?: return
        val req = device.createCaptureRequest(CameraDevice.TEMPLATE_PREVIEW).apply {
            addTarget(pSurf); addTarget(aSurf)
            set(CaptureRequest.CONTROL_MODE,     CaptureRequest.CONTROL_MODE_AUTO)
            set(CaptureRequest.CONTROL_AE_MODE,  CaptureRequest.CONTROL_AE_MODE_ON)
            set(CaptureRequest.CONTROL_AE_LOCK,  aeLocked)
            set(CaptureRequest.CONTROL_AWB_MODE, CaptureRequest.CONTROL_AWB_MODE_AUTO)
            set(CaptureRequest.CONTROL_AWB_LOCK, aeLocked)
            set(CaptureRequest.CONTROL_AF_MODE,  CaptureRequest.CONTROL_AF_MODE_OFF)
            set(CaptureRequest.LENS_FOCUS_DISTANCE, 0f)           // infinity
            set(CaptureRequest.NOISE_REDUCTION_MODE,
                CaptureRequest.NOISE_REDUCTION_MODE_OFF)
            set(CaptureRequest.EDGE_MODE, CaptureRequest.EDGE_MODE_OFF)
        }
        try { session.setRepeatingRequest(req.build(), captureCallback, bgHandler) }
        catch (e: Exception) { Log.e(TAG, "setRepeatingRequest: $e") }
    }

    // ── Capture callback ───────────────────────────────────────────────────────

    private val captureCallback = object : CameraCaptureSession.CaptureCallback() {
        override fun onCaptureCompleted(
            session: CameraCaptureSession,
            request: CaptureRequest,
            result: TotalCaptureResult
        ) {
            frameCount++
            val skewNs = result.get(CaptureResult.SENSOR_ROLLING_SHUTTER_SKEW) ?: 10_000_000L
            val expNs  = result.get(CaptureResult.SENSOR_EXPOSURE_TIME)         ?: 0L
            val iso    = result.get(CaptureResult.SENSOR_SENSITIVITY)           ?: 100
            analyzer.rollingShutterSkewNs = skewNs
            onMetadataUpdate(skewNs, expNs, iso)
            if (!aeLocked && frameCount == AE_WARMUP_FRAMES) {
                aeLocked = true
                captureSession?.let { startRepeating(it) }
                Log.d(TAG, "AE locked: exp=${expNs/1000}µs ISO=$iso RS=${skewNs/1000}µs")
            }
        }
    }

    // ── Image processing: full-frame row averaging ─────────────────────────────
    // With a paper diffuser the spatial pattern is uniform.
    // Average ALL columns for each row — no ROI needed.

    private val imageListener = ImageReader.OnImageAvailableListener { reader ->
        val img = reader.acquireLatestImage() ?: return@OnImageAvailableListener
        try { processFrame(img) } finally { img.close() }
    }

    private fun processFrame(image: android.media.Image) {
        val plane     = image.planes[0]
        val yBuf      = plane.buffer
        val rowStride = plane.rowStride
        val pixStride = plane.pixelStride
        val W         = image.width
        val H         = image.height
        val skewNs    = analyzer.rollingShutterSkewNs

        val yBytes = ByteArray(yBuf.remaining()).also { yBuf.get(it) }
        val means  = DoubleArray(H) { row ->
            var sum = 0L
            var idx = row * rowStride
            repeat(W) { sum += yBytes[idx].toInt() and 0xFF; idx += pixStride }
            sum.toDouble() / W
        }
        // ── Exposure statistics ──────────────────────────────────────────────
        val meanVal  = means.average()
        val peakVal  = means.maxOrNull() ?: 0.0
        val satCount = means.count { it > 250.0 }
        lastFrameStats = FrameStats(
            meanRowMean = meanVal,
            peakRowMean = peakVal,
            satRows     = satCount,
            totalRows   = H,
            meanPct     = meanVal / 255.0 * 100.0,
            peakPct     = peakVal / 255.0 * 100.0
        )
        analyzer.addFrame(means, skewNs)
    }

    // ── Cleanup ────────────────────────────────────────────────────────────────

    fun closeCamera() {
        isRunning = false; aeLocked = false; frameCount = 0
        try {
            if (!openLock.tryAcquire(2500, TimeUnit.MILLISECONDS)) return
            captureSession?.close(); captureSession = null
            cameraDevice?.close();  cameraDevice  = null
            imageReader?.close();   imageReader   = null
            previewSurface?.release();  previewSurface  = null
            analysisSurface?.release(); analysisSurface = null
        } catch (e: Exception) { Log.e(TAG, "closeCamera: $e") }
        finally { try { openLock.release() } catch (_: Exception) {} }
    }

    // ── Camera selection ───────────────────────────────────────────────────────

    /**
     * Returns camera "0" if it is back-facing (true on all Samsung devices).
     * Falls back to the shortest-focal-length back camera otherwise.
     */
    private fun findMainCamera(): String? {
        val ids = camManager.cameraIdList
        val backIds = ids.filter {
            camManager.getCameraCharacteristics(it)
                .get(CameraCharacteristics.LENS_FACING) ==
                CameraCharacteristics.LENS_FACING_BACK
        }
        if (backIds.isEmpty()) return null
        val id = if ("0" in backIds) "0"
        else backIds.minByOrNull {
            camManager.getCameraCharacteristics(it)
                .get(CameraCharacteristics.LENS_INFO_AVAILABLE_FOCAL_LENGTHS)
                ?.minOrNull() ?: Float.MAX_VALUE
        } ?: backIds.first()

        try {
            val ch  = camManager.getCameraCharacteristics(id)
            val fl  = ch.get(CameraCharacteristics.LENS_INFO_AVAILABLE_FOCAL_LENGTHS)?.minOrNull() ?: 0f
            val fno = ch.get(CameraCharacteristics.LENS_INFO_AVAILABLE_APERTURES)?.minOrNull() ?: 0f
            selectedCameraId   = id
            selectedCameraDesc = "cam$id  f=${fl}mm  f/${fno}"
        } catch (_: Exception) { selectedCameraId = id; selectedCameraDesc = "cam$id" }
        return id
    }

    /**
     * Find the YUV_420_888 size with the maximum number of rows (height),
     * capped at 4K to avoid excessive processing.
     * More rows → more rolling-shutter samples → higher effective sample rate.
     */
    private fun getBestYuvSize(cameraId: String): Size {
        return try {
            val ch  = camManager.getCameraCharacteristics(cameraId)
            val map = ch.get(CameraCharacteristics.SCALER_STREAM_CONFIGURATION_MAP)
            map?.getOutputSizes(ImageFormat.YUV_420_888)
                ?.filter { it.width <= 4096 && it.height <= 2160 }
                ?.maxByOrNull { it.height }
                ?: Size(1920, 1080)
        } catch (_: Exception) { Size(1920, 1080) }
    }

    fun rowPeriodUs() = if (analyzer.streamHeight > 1)
        analyzer.rollingShutterSkewNs / 1_000.0 / (analyzer.streamHeight - 1) else 0.0
}
