package com.seeingmeter

import android.Manifest
import android.content.pm.PackageManager
import android.graphics.Color
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.util.AttributeSet
import android.view.*
import android.widget.*
import androidx.appcompat.app.AlertDialog
import androidx.appcompat.app.AppCompatActivity
import androidx.core.app.ActivityCompat
import androidx.core.content.ContextCompat

class MainActivity : AppCompatActivity() {

    companion object {
        private const val PERM_CAMERA   = Manifest.permission.CAMERA
        private const val REQ_CAMERA    = 1001
        private const val ANALYSIS_MS   = 500L    // 0.5 s analysis interval
    }

    private lateinit var textureView:    TextureView
    private lateinit var tvSignal:       TextView
    private lateinit var tvR0:           TextView
    private lateinit var tvSeeing:       TextView
    private lateinit var tvSigma:        TextView
    private lateinit var tvFreq:         TextView
    private lateinit var tvStatus:       TextView
    private lateinit var tvInfo:         TextView
    private lateinit var btnMeasure:     Button
    private lateinit var timeSeriesView: TimeSeriesView
    private lateinit var spectrumView:   SpectrumView

    private lateinit var analyzer:         SeeingAnalyzer
    private lateinit var cameraController: CameraController

    private val mainHandler = Handler(Looper.getMainLooper())
    private var isMeasuring = false

    // ── Lifecycle ──────────────────────────────────────────────────────────────

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        window.addFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON)
        setContentView(R.layout.activity_main)

        textureView    = findViewById(R.id.textureView)
        tvR0           = findViewById(R.id.tvR0)
        tvSeeing       = findViewById(R.id.tvSeeing)
        tvSigma        = findViewById(R.id.tvSigma)
        tvFreq         = findViewById(R.id.tvFreq)
        tvStatus       = findViewById(R.id.tvStatus)
        tvInfo         = findViewById(R.id.tvInfo)
        tvSignal       = findViewById(R.id.tvSignal)
        btnMeasure     = findViewById(R.id.btnMeasure)
        timeSeriesView = findViewById(R.id.timeSeriesView)
        spectrumView   = findViewById(R.id.spectrumView)

        analyzer = SeeingAnalyzer()
        cameraController = CameraController(this, analyzer) { skewNs, expNs, iso ->
            mainHandler.post { updateInfo(skewNs, expNs, iso) }
        }

        btnMeasure.setOnClickListener { if (!isMeasuring) start() else stop() }
        findViewById<Button>(R.id.btnSettings).setOnClickListener { showSettings() }
        findViewById<Button>(R.id.btnReset).setOnClickListener {
            analyzer.reset(); timeSeriesView.clear()
            spectrumView.updateSpectrum(DoubleArray(0), DoubleArray(0), Double.NaN, Double.NaN)
            tvStatus.text = "Reset"
        }
        showSolarWarning()
    }

    override fun onResume() {
        super.onResume()
        if (hasCameraPermission()) openCamera()
    }

    override fun onPause() {
        super.onPause()
        stop()
        mainHandler.removeCallbacksAndMessages(null)
        cameraController.detach()
        cameraController.stopBackgroundThread()
    }

    private fun openCamera() {
        cameraController.startBackgroundThread()
        cameraController.attachTextureView(textureView)
    }

    // ── Measurement ────────────────────────────────────────────────────────────

    private fun start() {
        isMeasuring = true; analyzer.reset()
        btnMeasure.text = "■  Stop"
        btnMeasure.setBackgroundColor(Color.parseColor("#CC2222"))
        tvStatus.text = "Auto-exposing…  hold steady"
        mainHandler.postDelayed(loop, ANALYSIS_MS)
    }

    private fun stop() {
        isMeasuring = false
        mainHandler.removeCallbacks(loop)
        btnMeasure.text = "▶  Measure"
        btnMeasure.setBackgroundColor(Color.parseColor("#1B5E20"))
        tvStatus.text = "Stopped"
    }

    private val loop = object : Runnable {
        override fun run() {
            if (!isMeasuring) return
            tick()
            mainHandler.postDelayed(this, ANALYSIS_MS)
        }
    }

    private fun tick() {
        val res = analyzer.analyze()
        if (res == null) {
            tvStatus.text = "Collecting… ${analyzer.framesProcessed} frames"
            return
        }

        // Main results
        tvR0.text = if (res.r0Cm.isNaN()) "r₀ = —"
                    else "r₀ = %.1f cm  [%s]".format(res.r0Cm, res.qualityLabel)
        tvSeeing.text = if (res.seeingArcsec.isNaN()) "Seeing = —"
                        else "Seeing = %.2f\"".format(res.seeingArcsec)
        tvSigma.text  = "σ_I = %.4f  (%.3f%%)".format(
            res.scintillationSigma, res.scintillationSigma * 100.0)

        val fc = if (res.characteristicFreqHz.isFinite()) "%.0f Hz".format(res.characteristicFreqHz) else "—"
        val ff = if (res.fresnelFreqHz.isFinite())        "%.0f Hz".format(res.fresnelFreqHz)        else "—"
        val hs = if (res.hFromSpectralFitKm.isFinite() && !res.hFromSpectralFitKm.isNaN())
                     "  H_fit=%.1f km".format(res.hFromSpectralFitKm) else ""
        tvFreq.text  = "f_c=$fc  f_F=$ff$hs"
        tvStatus.text = "${analyzer.framesProcessed} frames · %.0f kHz · Δt=%.1f µs · H=%.1f km".format(
            res.sampleRateHz / 1000.0, res.rowPeriodUs, res.turbulenceHeightKm)

        // Time series
        if (!res.r0Cm.isNaN()) timeSeriesView.addSample(res.r0Cm, res.scintillationSigma)

        // Spectrum
        spectrumView.updateSpectrum(res.freqs, res.psd,
            res.characteristicFreqHz, res.fresnelFreqHz)
    }

    private fun updateInfo(skewNs: Long, expNs: Long, iso: Int) {
        val expMs  = expNs  / 1_000_000.0
        val skewMs = skewNs / 1_000_000.0
        val kHz    = if (skewMs > 0) cameraController.analysisHeight / (skewMs / 1000.0) / 1000.0 else 0.0
        tvInfo.text = "Exp %.2f ms · ISO %d · RS %.1f ms · ~%.0f kHz · [%s]  %d×%d".format(
            expMs, iso, skewMs, kHz, cameraController.selectedCameraDesc,
            cameraController.analysisWidth, cameraController.analysisHeight)
        updateSignal()
    }

    /**
     * Display per-frame signal statistics to guide exposure through the ND filter.
     *
     * The Y (luminance) channel is 8-bit (0–255).
     *   Mean row mean  — average intensity across all rows; ideal range 30–70 % FS
     *   Peak row mean  — maximum row mean; should stay < 95 % FS to avoid saturation
     *   Sat rows       — rows with mean > 250/255; should be 0 for a valid measurement
     *   % FS           — percentage of full scale (255)
     */
    private fun updateSignal() {
        val s = cameraController.lastFrameStats
        if (s.totalRows == 0) return

        val meanPct = s.meanPct
        val peakPct = s.peakPct
        val satPct  = if (s.totalRows > 0) s.satRows * 100.0 / s.totalRows else 0.0

        // Exposure quality hint
        val hint = when {
            s.satRows > s.totalRows / 10 ->
                "⚠ SATURATED"
            meanPct < 5.0  -> "⚠ UNDEREXPOSED"
            meanPct > 85.0 -> "⚠ NEAR SATURATION"
            meanPct in 25.0..70.0 -> "✓ Good exposure"
            else -> "OK"
        }

        // Colour: red if saturated, amber if marginal, green if good
        val col = when {
            s.satRows > 0  -> android.graphics.Color.parseColor("#FF5252")
            meanPct < 5.0  -> android.graphics.Color.parseColor("#FF9800")
            meanPct > 85.0 -> android.graphics.Color.parseColor("#FF9800")
            else           -> android.graphics.Color.parseColor("#69F0AE")
        }

        tvSignal.setTextColor(col)
        tvSignal.text = "Signal:  mean %.1f%%  (%.0f/255)  ·  peak %.1f%%  (%.0f/255)  ·  "             .format(meanPct, s.meanRowMean, peakPct, s.peakRowMean) +
            "sat rows %d/%d  (%.1f%%)    %s".format(s.satRows, s.totalRows, satPct, hint)
    }

    // ── Settings ────────────────────────────────────────────────────────────────

    private fun showSettings() {
        val v = layoutInflater.inflate(R.layout.dialog_settings, null)
        val etZ   = v.findViewById<EditText>(R.id.etZenith)
        val etH   = v.findViewById<EditText>(R.id.etHeight)
        val etW   = v.findViewById<EditText>(R.id.etWind)
        val etL   = v.findViewById<EditText>(R.id.etLambda)
        val etSun = v.findViewById<EditText>(R.id.etSunRadius)
        val etCal = v.findViewById<EditText>(R.id.etCalib)
        etZ.setText("%.1f".format(analyzer.zenithAngleDeg))
        etH.setText("%.1f".format(analyzer.turbulenceHeightM / 1000.0))
        etW.setText("%.1f".format(analyzer.windSpeedMs))
        etL.setText("%.0f".format(analyzer.wavelengthNm))
        etSun.setText("%.0f".format(analyzer.sunAngularRadiusArcsec))
        etCal.setText("%.2f".format(analyzer.solarCalibration))
        AlertDialog.Builder(this, android.R.style.Theme_Material_Dialog_Alert)
            .setTitle("Seykora Scintillometer Parameters")
            .setView(v)
            .setPositiveButton("Apply") { _, _ ->
                etZ.text.toString().toDoubleOrNull()?.let  { analyzer.zenithAngleDeg        = it.coerceIn(0.0, 85.0) }
                etH.text.toString().toDoubleOrNull()?.let  { analyzer.turbulenceHeightM     = (it*1000).coerceIn(50.0,20000.0) }
                etW.text.toString().toDoubleOrNull()?.let  { analyzer.windSpeedMs           = it.coerceIn(0.5,50.0) }
                etL.text.toString().toDoubleOrNull()?.let  { analyzer.wavelengthNm          = it.coerceIn(400.0,700.0) }
                etSun.text.toString().toDoubleOrNull()?.let{ analyzer.sunAngularRadiusArcsec = it.coerceIn(800.0,1100.0) }
                etCal.text.toString().toDoubleOrNull()?.let{ analyzer.solarCalibration      = it.coerceIn(0.1,10.0) }
            }
            .setNegativeButton("Cancel", null).show()
    }

    // ── Solar safety ────────────────────────────────────────────────────────────

    private fun showSolarWarning() {
        AlertDialog.Builder(this, android.R.style.Theme_Material_Dialog_Alert)
            .setTitle("☀  SOLAR SAFETY")
            .setMessage(
                "Camera sensor will be PERMANENTLY DAMAGED without a proper solar filter.\n\n" +
                "Required: Baader AstroSolar ND 5.0 film over ALL rear lenses.\n\n" +
                "Setup:\n" +
                "1. Attach solar filter over the rear camera\n" +
                "2. Place a WHITE PAPER DIFFUSER over the filter\n" +
                "   → Converts camera to a Seykora solar scintillometer\n" +
                "3. Point at the Sun and press MEASURE\n" +
                "4. Hold steady — r₀ time history appears below"
            )
            .setPositiveButton("I have a solar filter") { _, _ ->
                if (!hasCameraPermission())
                    ActivityCompat.requestPermissions(this, arrayOf(PERM_CAMERA), REQ_CAMERA)
            }
            .setNegativeButton("Exit") { _, _ -> finish() }
            .setCancelable(false).show()
    }

    private fun hasCameraPermission() =
        ContextCompat.checkSelfPermission(this, PERM_CAMERA) == PackageManager.PERMISSION_GRANTED

    override fun onRequestPermissionsResult(
        requestCode: Int, permissions: Array<String>, grantResults: IntArray
    ) {
        super.onRequestPermissionsResult(requestCode, permissions, grantResults)
        if (requestCode == REQ_CAMERA &&
            grantResults.isNotEmpty() &&
            grantResults[0] == PackageManager.PERMISSION_GRANTED) openCamera()
        else tvStatus.text = "Camera permission denied"
    }
}
