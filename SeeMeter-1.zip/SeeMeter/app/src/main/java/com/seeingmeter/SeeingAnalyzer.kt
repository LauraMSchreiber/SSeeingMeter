package com.seeingmeter

import kotlin.math.*

/**
 * Atmospheric Seeing Analyzer — Solar Scintillometer (Seykora 1993)
 * =================================================================
 *
 * MEASUREMENT SETUP
 * ─────────────────
 * Place a white paper diffuser over the camera lens.
 * The camera measures the TOTAL INTEGRATED FLUX through the aperture,
 * identical in geometry to a Seykora (1993) single-photodiode scintillometer.
 * No ROI selection is needed — the diffuser makes all pixels equivalent.
 *
 * ROLLING SHUTTER TIME BASE
 * ─────────────────────────
 * Row r is exposed at  t_r = t_0 + r · Δt
 * Δt = SENSOR_ROLLING_SHUTTER_SKEW / (N_rows − 1)
 * S25 Ultra at 4K (2160 rows, skew ~20ms): Δt ≈ 9 µs → f_sample ≈ 110 kHz
 *
 * SEYKORA FORMULA (Roddier 1981 extended to solar source)
 * ────────────────────────────────────────────────────────
 * For aperture D ≪ r_F and solar disk α_s ≫ θ_F:
 *
 *   σ²_I = COEFF · k^(−5/6) · sec(z)^(5/6) · H^(−1/6) · λ / α_s² · r₀^(−5/3)
 *
 * where COEFF = 8 × Q × (0.563/0.423) ≈ 13.47
 *       Q ≈ 1.27  (Gaussian approximation of Kolmogorov log-amplitude covariance)
 *       H^(−1/6) : solar scintillometer weights LOW-ALTITUDE turbulence
 *
 * References:
 *   Seykora (1993) Solar Physics 145, 389–397
 *   Beckers (2009) Optical Turbulence, pp. 23–25
 *   Roddier (1981) Prog. Optics XIX, 281–376
 */
class SeeingAnalyzer(
    var wavelengthNm:           Double = 550.0,
    /** Effective turbulence height (km). Solar scintillometer → boundary layer, ~1 km. */
    var turbulenceHeightM:      Double = 1_000.0,
    var windSpeedMs:            Double = 10.0,
    var zenithAngleDeg:         Double = 45.0,
    var sunAngularRadiusArcsec: Double = 960.0,
    /** Empirical calibration factor (1.0 = theory value; adjust against DIMM if available). */
    var solarCalibration:       Double = 1.0
) {
    companion object {
        const val TAG         = "SeeingAnalyzer"
        /** Seykora/Roddier constant: 8 × Q × (0.563/0.423) where Q ≈ 1.27 */
        const val COEFF_SOLAR = 13.47
        const val MAX_BUFFER  = 262_144   // ~2.4 s at 110 kHz
        const val MIN_SAMPLES = 512
        /** Window of samples used per analysis call (0.5 s at ~110 kHz = ~55 000 samples). */
        const val WINDOW_SAMPLES = 55_000
    }

    // ── Ring buffer ───────────────────────────────────────────────────────────
    private val buf = ArrayDeque<Double>(MAX_BUFFER)

    @Volatile var rollingShutterSkewNs: Long   = 10_000_000L
    @Volatile var streamHeight:         Int    = 2160
    @Volatile var sampleRateHz:         Double = 0.0

    var framesProcessed: Int = 0; private set

    // ── PSD accumulator ───────────────────────────────────────────────────────
    private var _psdAccum = DoubleArray(0)
    private var psdFreqs  = DoubleArray(0)
    private var psdCount  = 0

    var result: AnalysisResult? = null; private set

    // ── Frame ingestion ───────────────────────────────────────────────────────

    fun addFrame(rowMeans: DoubleArray, rollingSkewNs: Long) {
        val n = rowMeans.size; if (n < 2) return
        rollingShutterSkewNs = rollingSkewNs
        streamHeight         = n
        val dtNs = rollingSkewNs.toDouble() / (n - 1)
        sampleRateHz = if (dtNs > 0) 1e9 / dtNs else 0.0

        synchronized(this) {
            val mean = rowMeans.average(); if (mean <= 0.0) return
            for (v in rowMeans) {
                if (buf.size >= MAX_BUFFER) buf.removeFirst()
                buf.addLast(v / mean)
            }
            if (sampleRateHz > 0) addFrameSpectrum(rowMeans, mean)
        }
        framesProcessed++
    }

    private fun addFrameSpectrum(rowMeans: DoubleArray, mean: Double) {
        val segLen = FFTUtils.nextPow2(rowMeans.size).coerceAtMost(2048)
        val nFreqs = segLen / 2 + 1
        if (_psdAccum.size != nFreqs) {
            _psdAccum = DoubleArray(nFreqs)
            psdFreqs  = DoubleArray(nFreqs) { it * sampleRateHz / segLen }
            psdCount  = 0
        }
        val s = linearDetrend(DoubleArray(rowMeans.size) { rowMeans[it] / mean - 1.0 })
        val win = DoubleArray(segLen) { 0.5 * (1.0 - cos(2.0 * PI * it / (segLen - 1))) }
        val wp  = win.sumOf { it * it }
        val re  = DoubleArray(segLen) { if (it < s.size) s[it] * win[it] else 0.0 }
        val im  = DoubleArray(segLen)
        FFTUtils.fft(re, im)
        for (k in 0 until nFreqs) {
            val p = (re[k]*re[k] + im[k]*im[k]) / (sampleRateHz * wp)
            _psdAccum[k] += if (k == 0 || k == segLen/2) p else 2.0 * p
        }
        psdCount++
    }

    // ── Analysis ──────────────────────────────────────────────────────────────

    fun analyze(): AnalysisResult? {
        val samples: DoubleArray
        val fs: Double
        synchronized(this) {
            if (buf.size < MIN_SAMPLES || sampleRateHz <= 0) return null
            // Use last WINDOW_SAMPLES (≈ 0.5 s) for variance estimate
            val n = minOf(buf.size, WINDOW_SAMPLES)
            samples = DoubleArray(n) { buf[buf.size - n + it] }
            fs = sampleRateHz
        }

        val mean = samples.average(); if (mean <= 0.0) return null
        val det  = linearDetrend(DoubleArray(samples.size) { samples[it] - mean })
        val norm = DoubleArray(det.size) { det[it] / mean }
        val vI   = norm.sumOf { it * it } / norm.size
        val sI   = sqrt(vI)

        // PSD (accumulated across frames)
        val (freqs, psd) = if (psdCount > 0)
            Pair(psdFreqs, DoubleArray(_psdAccum.size) { _psdAccum[it] / psdCount })
        else {
            val seg = FFTUtils.nextPow2(samples.size / 4).coerceAtMost(2048)
            FFTUtils.welchPSD(norm, fs, seg, 0.5)
        }
        if (freqs.isEmpty()) return null

        val fcFit = FFTUtils.fitKolmogorovFrequency(freqs, psd, 30.0)

        val lam        = wavelengthNm * 1e-9
        val fresnelHz  = windSpeedMs / sqrt(lam * turbulenceHeightM)
        val hFromFc    = if (fcFit.isFinite() && fcFit > 0 && windSpeedMs > 0)
                            (windSpeedMs / fcFit).pow(2.0) / lam else Double.NaN
        val zenRad     = zenithAngleDeg * PI / 180.0

        val r0m        = computeR0(vI, zenRad)
        val r0cm       = if (r0m.isNaN()) Double.NaN else r0m * 100.0
        val seeing     = if (r0m.isNaN() || r0m <= 0) Double.NaN
                         else 0.976 * lam / r0m * 206_265.0

        result = AnalysisResult(
            r0Cm = r0cm, seeingArcsec = seeing,
            scintillationSigma = sI, scintillationVar = vI,
            characteristicFreqHz = fcFit, fresnelFreqHz = fresnelHz,
            hFromSpectralFitKm = if (hFromFc.isNaN()) Double.NaN else hFromFc / 1000.0,
            freqs = freqs, psd = psd,
            nSamples = samples.size, sampleRateHz = fs,
            rowPeriodUs = 1e6 / fs, framesProcessed = framesProcessed,
            wavelengthNm = wavelengthNm, turbulenceHeightKm = turbulenceHeightM / 1000.0,
            windSpeedMs = windSpeedMs, zenithAngleDeg = zenithAngleDeg,
            sunAngularRadiusArcsec = sunAngularRadiusArcsec
        )
        return result
    }

    /**
     * Seykora (1993) r₀ formula — derived from Roddier (1981) for extended source, D ≪ r_F.
     *
     *   σ²_I = COEFF_SOLAR · k^(−5/6) · sec(z)^(5/6) · H^(−1/6) · λ / α_s² · r₀^(−5/3)
     *
     * Note H^(−1/6): opposite sign to stellar formula. Weak H dependence is an advantage —
     * 100× uncertainty in H changes r₀ by only ~2×.
     */
    private fun computeR0(varI: Double, zenRad: Double): Double {
        if (varI <= 0.0) return Double.NaN
        val lam = wavelengthNm * 1e-9
        val k   = 2.0 * PI / lam
        val secZ = 1.0 / cos(zenRad)
        val H    = turbulenceHeightM
        val aRad = sunAngularRadiusArcsec * PI / (180.0 * 3600.0)
        val num  = COEFF_SOLAR * solarCalibration *
                   k.pow(-5.0/6.0) * secZ.pow(5.0/6.0) *
                   H.pow(-1.0/6.0) * lam / (aRad * aRad)
        return (num / varI).pow(3.0 / 5.0)
    }

    private fun linearDetrend(d: DoubleArray): DoubleArray {
        val n = d.size; if (n < 2) return d
        val xm = (n-1)/2.0; val ym = d.average()
        var sxx = 0.0; var sxy = 0.0
        for (i in d.indices) { val dx = i-xm; sxx += dx*dx; sxy += dx*(d[i]-ym) }
        val sl = if (sxx > 0) sxy/sxx else 0.0
        return DoubleArray(n) { i -> d[i] - (ym + sl*(i-xm)) }
    }

    fun reset() {
        synchronized(this) {
            buf.clear()
            _psdAccum = DoubleArray(0); psdFreqs = DoubleArray(0); psdCount = 0
        }
        framesProcessed = 0; result = null
    }

    data class AnalysisResult(
        val r0Cm: Double, val seeingArcsec: Double,
        val scintillationSigma: Double, val scintillationVar: Double,
        val characteristicFreqHz: Double, val fresnelFreqHz: Double,
        val hFromSpectralFitKm: Double,
        val freqs: DoubleArray, val psd: DoubleArray,
        val nSamples: Int, val sampleRateHz: Double, val rowPeriodUs: Double,
        val framesProcessed: Int,
        val wavelengthNm: Double, val turbulenceHeightKm: Double,
        val windSpeedMs: Double, val zenithAngleDeg: Double,
        val sunAngularRadiusArcsec: Double
    ) {
        val qualityLabel: String get() = when {
            r0Cm.isNaN()  -> "—"
            r0Cm >= 20.0  -> "Excellent"
            r0Cm >= 12.0  -> "Good"
            r0Cm >= 7.0   -> "Average"
            r0Cm >= 4.0   -> "Poor"
            else          -> "Very Poor"
        }
    }
}
