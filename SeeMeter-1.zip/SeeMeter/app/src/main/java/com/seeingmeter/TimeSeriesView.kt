package com.seeingmeter

import android.content.Context
import android.graphics.*
import android.util.AttributeSet
import android.view.View
import kotlin.math.*

/**
 * Scrolling time-series display of r₀ (Fried radius) measured every 0.5 s.
 *
 * Layout:
 *   X axis  — elapsed time in seconds, scrolling (most recent on the right)
 *   Y axis  — r₀ in cm, auto-scaling with quality colour bands
 *
 * Quality colour bands (background):
 *   Excellent  r₀ ≥ 20 cm  — deep green
 *   Good       12–20 cm    — green
 *   Average    7–12 cm     — amber
 *   Poor       4–7 cm      — orange
 *   Very Poor  < 4 cm      — red
 */
class TimeSeriesView @JvmOverloads constructor(
    context: Context, attrs: AttributeSet? = null, defStyle: Int = 0
) : View(context, attrs, defStyle) {

    data class Sample(val timestampMs: Long, val r0Cm: Double, val sigmaI: Double)

    private val history   = ArrayDeque<Sample>()
    private val WINDOW_S  = 120.0      // seconds of history shown
    private val MIN_RANGE = 5.0        // minimum Y range (cm)

    // Paints
    private val bgPaint   = Paint().apply { style = Paint.Style.FILL }
    private val bandPaint = Paint().apply { style = Paint.Style.FILL; alpha = 60 }
    private val gridPaint = Paint().apply {
        color = Color.parseColor("#2A2A4A"); strokeWidth = 1f; style = Paint.Style.STROKE
    }
    private val linePaint = Paint().apply {
        strokeWidth = 2.5f; style = Paint.Style.STROKE; isAntiAlias = true
        strokeJoin = Paint.Join.ROUND; strokeCap = Paint.Cap.ROUND
    }
    private val dotPaint  = Paint().apply { isAntiAlias = true; style = Paint.Style.FILL }
    private val labelPaint = Paint().apply {
        color = Color.parseColor("#AAAACC"); textSize = 26f; isAntiAlias = true
    }
    private val valuePaint = Paint().apply {
        color = Color.WHITE; textSize = 30f; isAntiAlias = true; isFakeBoldText = true
    }
    private val noDataPaint = Paint().apply {
        color = Color.parseColor("#666688"); textSize = 34f; isAntiAlias = true
        textAlign = Paint.Align.CENTER
    }
    private val axisLabelPaint = Paint().apply {
        color = Color.parseColor("#888899"); textSize = 22f; isAntiAlias = true
        textAlign = Paint.Align.CENTER
    }

    // Margins
    private val ml = 80f; private val mr = 16f; private val mt = 16f; private val mb = 44f

    // Quality colour map
    private fun r0Color(r0: Double): Int = when {
        r0 >= 20 -> Color.parseColor("#00C853")   // Excellent — bright green
        r0 >= 12 -> Color.parseColor("#76FF03")   // Good — green
        r0 >= 7  -> Color.parseColor("#FFD600")   // Average — amber
        r0 >= 4  -> Color.parseColor("#FF6D00")   // Poor — orange
        else     -> Color.parseColor("#FF1744")   // Very Poor — red
    }

    // ── Public API ────────────────────────────────────────────────────────────

    fun addSample(r0Cm: Double, sigmaI: Double) {
        if (r0Cm.isNaN() || r0Cm <= 0) return
        val nowMs = System.currentTimeMillis()
        history.addLast(Sample(nowMs, r0Cm, sigmaI))
        // Trim data older than WINDOW_S
        val cutoffMs = nowMs - (WINDOW_S * 1000).toLong()
        while (history.isNotEmpty() && history.first().timestampMs < cutoffMs)
            history.removeFirst()
        postInvalidate()
    }

    fun clear() { history.clear(); postInvalidate() }

    // ── Drawing ────────────────────────────────────────────────────────────────

    override fun onDraw(canvas: Canvas) {
        val W = width.toFloat(); val H = height.toFloat()
        canvas.drawRect(0f, 0f, W, H, Paint().also { it.color = Color.parseColor("#0D0D1A") })

        if (history.size < 2) {
            canvas.drawText("Measuring…  (time series appears here)", W/2, H/2, noDataPaint)
            return
        }

        val plotW = W - ml - mr
        val plotH = H - mt - mb

        // ── Axis ranges ───────────────────────────────────────────────────────
        val nowMs  = System.currentTimeMillis()
        val t0Ms   = nowMs - (WINDOW_S * 1000).toLong()

        val r0Min0 = history.minOf { it.r0Cm }
        val r0Max0 = history.maxOf { it.r0Cm }
        val range  = maxOf(r0Max0 - r0Min0, MIN_RANGE)
        val pad    = range * 0.15
        val yMin   = maxOf(0.0, r0Min0 - pad)
        val yMax   = r0Max0 + pad

        fun xOf(tMs: Long)  = ml + ((tMs - t0Ms).toFloat() / (WINDOW_S * 1000).toFloat() * plotW)
        fun yOf(r0: Double) = mt + plotH - ((r0 - yMin) / (yMax - yMin) * plotH).toFloat()

        // ── Quality colour bands ──────────────────────────────────────────────
        val bands = listOf(
            Triple(0.0,   4.0,   Color.parseColor("#440000")),  // Very Poor
            Triple(4.0,   7.0,   Color.parseColor("#442200")),  // Poor
            Triple(7.0,   12.0,  Color.parseColor("#333300")),  // Average
            Triple(12.0,  20.0,  Color.parseColor("#003300")),  // Good
            Triple(20.0,  200.0, Color.parseColor("#003310"))   // Excellent
        )
        for ((lo, hi, col) in bands) {
            val y1 = yOf(hi.coerceAtMost(yMax)).coerceIn(mt, mt + plotH)
            val y2 = yOf(lo.coerceAtLeast(yMin)).coerceIn(mt, mt + plotH)
            if (y2 > y1) {
                bandPaint.color = col; bandPaint.alpha = 120
                canvas.drawRect(ml, y1, ml + plotW, y2, bandPaint)
            }
        }

        // ── Grid lines (Y) ────────────────────────────────────────────────────
        val thresholds = listOf(4.0, 7.0, 12.0, 20.0)
        for (th in thresholds) {
            if (th in yMin..yMax) {
                val y = yOf(th)
                canvas.drawLine(ml, y, ml + plotW, y, gridPaint)
                labelPaint.textAlign = Paint.Align.RIGHT
                canvas.drawText("${th.toInt()}", ml - 4f, y + 9f, labelPaint)
            }
        }
        // A few intermediate Y labels
        for (step in listOf(2.0, 5.0, 10.0, 25.0, 50.0)) {
            val firstTick = (yMin / step).toInt() * step
            var t = firstTick
            while (t <= yMax) {
                if (t !in thresholds && t >= yMin) {
                    val y = yOf(t)
                    canvas.drawLine(ml, y, ml + plotW, y,
                        Paint().also { it.color = Color.parseColor("#1A1A3A"); it.strokeWidth = 1f })
                    labelPaint.textAlign = Paint.Align.RIGHT
                    canvas.drawText(if (t >= 10) "${t.toInt()}" else "%.1f".format(t),
                        ml - 4f, y + 9f, labelPaint)
                }
                t += step
            }
            if ((yMax - yMin) / step < 10) break
        }

        // ── Grid lines (X — time ticks) ───────────────────────────────────────
        for (sAgo in listOf(0, 10, 20, 30, 60, 90, 120)) {
            val tMs = nowMs - sAgo * 1000L
            if (tMs < t0Ms) continue
            val x = xOf(tMs)
            canvas.drawLine(x, mt, x, mt + plotH, gridPaint)
            canvas.drawText(if (sAgo == 0) "now" else "-${sAgo}s",
                x, mt + plotH + mb * 0.8f, axisLabelPaint)
        }

        // ── Data line (colour-coded by quality) ───────────────────────────────
        val path  = Path()
        var first = true
        for (s in history) {
            val x = xOf(s.timestampMs)
            val y = yOf(s.r0Cm)
            if (first) { path.moveTo(x, y); first = false } else path.lineTo(x, y)
        }
        // Draw in segments coloured by quality
        if (history.size >= 2) {
            for (i in 1 until history.size) {
                val s0 = history[i-1]; val s1 = history[i]
                linePaint.color = r0Color((s0.r0Cm + s1.r0Cm) / 2.0)
                canvas.drawLine(xOf(s0.timestampMs), yOf(s0.r0Cm),
                                xOf(s1.timestampMs), yOf(s1.r0Cm), linePaint)
            }
        }

        // Latest dot
        history.lastOrNull()?.let { s ->
            dotPaint.color = r0Color(s.r0Cm)
            canvas.drawCircle(xOf(s.timestampMs), yOf(s.r0Cm), 7f, dotPaint)
        }

        // ── Axes ─────────────────────────────────────────────────────────────
        canvas.drawLine(ml, mt, ml, mt + plotH, Paint().also {
            it.color = Color.parseColor("#8888AA"); it.strokeWidth = 1.5f })
        canvas.drawLine(ml, mt + plotH, ml + plotW, mt + plotH, Paint().also {
            it.color = Color.parseColor("#8888AA"); it.strokeWidth = 1.5f })

        // Y axis title (rotated)
        canvas.save()
        canvas.rotate(-90f, 14f, mt + plotH / 2)
        canvas.drawText("r₀ (cm)", 14f - 30f, mt + plotH / 2, axisLabelPaint)
        canvas.restore()

        // Latest value as large text
        history.lastOrNull()?.let { s ->
            valuePaint.color = r0Color(s.r0Cm)
            valuePaint.textAlign = Paint.Align.RIGHT
            val label = "r₀=%.1f cm".format(s.r0Cm)
            canvas.drawText(label, ml + plotW, mt + 28f, valuePaint)
        }
    }
}
