# SeeMeter — Atmospheric Seeing Meter for Android

A scientific Android app that measures atmospheric seeing (Fried radius r₀)
using the **rolling shutter** of the phone camera as a high-rate photometer.

---

## Physical Principle

A CMOS rolling-shutter camera reads each sensor row at a slightly later time.
Android's Camera2 API reports this as `SENSOR_ROLLING_SHUTTER_SKEW` (nanoseconds).

```
Row 0    ──► exposes at  t₀
Row 1    ──► exposes at  t₀ + Δt
  ⋮
Row N-1  ──► exposes at  t₀ + (N-1)·Δt

Δt = SENSOR_ROLLING_SHUTTER_SKEW / (N - 1)
```

For the Samsung S25 Ultra at 1080p:
- Typical skew ≈ 8–12 ms
- Δt ≈ 7–11 µs/row  →  **sample rate ≈ 90–140 kHz**

Scintillation frequencies of interest: **50–2000 Hz**.
Nyquist limit at 100 kHz: 50 kHz  →  **far more than sufficient**.

---

## Physics: From Scintillation to Fried Radius

For Kolmogorov turbulence, a point aperture (D ≪ r_Fresnel), and a single
equivalent turbulent layer at height H (Roddier 1981):

```
σ²_I = 5.324 · k^(-5/6) · sec(z)^(5/6) · H^(5/6) · r₀^(-5/3)
```

where:
- `σ²_I = Var[δI/⟨I⟩]`   normalised intensity variance
- `k = 2π/λ`              optical wavenumber (λ = 550 nm default)
- `z`                     solar zenith angle
- `H`                     effective turbulence height (default 5 km)

Solving for r₀:
```
r₀ = [ 5.324 · k^(-5/6) · sec(z)^(5/6) · H^(5/6)  /  σ²_I ]^(3/5)
```

Seeing (FWHM of long-exposure PSF):
```
ε [arcsec] = 0.976 · λ / r₀  × 206265
```

Fresnel (rolloff) frequency of the temporal PSD:
```
f_c = v_wind / √(λ · H)
```

### Why is σ_I so large for a phone?

The smartphone lens aperture D ≈ 2–3 mm is far smaller than the Fresnel
scale r_F = √(λH) ≈ 52 mm (λ=550 nm, H=5 km). There is no aperture averaging.
Consequently σ_I can be 20–70% — much larger than for a telescope (which
integrates over many Fresnel zones), but perfectly measurable.

---

## Build Instructions

### Requirements
- Android Studio Hedgehog (2023.1.1) or later
- Android SDK 34, NDK not required
- Kotlin 1.9+
- Physical device running Android 8.0+ (API 26+)
  — Camera2 `SENSOR_ROLLING_SHUTTER_SKEW` requires a real device

### Steps
1. Clone / extract this project
2. Open in Android Studio: **File → Open → SeeMeter/**
3. Connect your Samsung S25 Ultra via USB, enable USB debugging
4. Run → **Run 'app'**

---

## Usage

### Equipment required
**A solar ND 5.0 filter (optical density ≥ 4.0) covering the rear camera lens.**
Suitable options:
- Baader AstroSolar™ Safety Film (Visual, ND 5.0)
- Any certified white-light solar filter sheet cut to fit

Without this filter the **camera sensor will be destroyed** by concentrated sunlight.

### Procedure
1. Attach solar filter securely over the rear camera module
2. Launch SeeMeter — read and accept the safety warning
3. Point phone at the Sun (the disk should appear dim grey)
4. **Drag the yellow ROI box** onto the solar disk
5. Tap **Measure**
6. Wait ~5 s for auto-exposure to lock
7. Hold the phone steady for 15–30 s
8. Read r₀ and seeing from the results panel

### Settings (⚙ Params button)
| Parameter | Effect on r₀ | Typical value |
|---|---|---|
| Zenith angle z | sec(z)^(5/6) factor | 30–60° for mid-day Sun |
| Turbulence height H | H^(5/6) factor | 5 km (lower boundary layer) |
| Wind speed | Fresnel frequency only | 5–15 m/s |
| Wavelength λ | k^(-5/6) factor | 550 nm (green) |

**Only z and λ affect r₀.** H and wind speed only determine the theoretical
Fresnel frequency overlay on the spectrum.

### Interpreting results

| r₀ (cm) | Seeing (arcsec) | Quality |
|---|---|---|
| ≥ 20 | ≤ 0.55″ | Excellent |
| 12–20 | 0.55–0.9″ | Good |
| 7–12 | 0.9–1.6″ | Average |
| 4–7  | 1.6–2.8″ | Poor |
| < 4  | > 2.8″   | Very Poor |

### Spectrum plot
- **Cyan line**: measured scintillation PSD
- **Red dashed**: fitted characteristic frequency f_char
- **Green dashed**: theoretical Fresnel frequency f_F = v/√(λH)
- **Grey dashed**: Kolmogorov f^(-8/3) reference slope
- Good data shows a flat (white noise) region below f_c, then f^(-8/3) roll-off

---

## Caveats and Limitations

1. **Single-layer model**: The formula assumes all turbulence at one height H.
   For more accurate results, use a site-specific C²n(h) profile. The app
   gives a reasonable estimate for boundary-layer dominated daytime seeing.

2. **Weak scintillation**: The formula requires σ²_χ ≪ 1. For small apertures
   this is usually satisfied, but in very poor seeing it may break down.

3. **Point aperture**: Valid when D ≪ r_Fresnel ≈ 52 mm. Smartphone lenses
   (D ≈ 2–3 mm) satisfy this well.

4. **Solar disk uniformity**: Select an ROI within the central solar disk
   (away from the limb) to minimise limb-darkening gradients.

5. **Exposure stability**: The app locks AE after 5 s. Frame normalisation
   also removes residual slow drifts.

6. **The r₀ derivation uses H as a free parameter.** Typical daytime values
   are 2–8 km. Varying H by 2× changes r₀ by a factor of 2^(3/5) ≈ 1.5.

---

## References

- Roddier, F. (1981). *The effects of atmospheric turbulence in optical astronomy.*
  Progress in Optics, XIX, 281–376.
- Dravins, D. et al. (1997). *Atmospheric intensity scintillation of stars.*
  PASP 109, 173.
- Hardy, J.W. (1998). *Adaptive Optics for Astronomical Telescopes.*
  Oxford University Press.

---

## File structure

```
SeeMeter/
├── app/src/main/java/com/seeingmeter/
│   ├── FFTUtils.kt        Cooley-Tukey FFT + Welch PSD + Kolmogorov fitter
│   ├── SeeingAnalyzer.kt  Time series ingestion, σ²_I → r₀ formula
│   ├── CameraController.kt  Camera2 API, rolling-shutter metadata, YUV processing
│   ├── SpectrumView.kt    Log-log PSD Canvas view
│   └── MainActivity.kt   UI, lifecycle, ROI overlay, settings dialog
└── app/src/main/res/
    ├── layout/activity_main.xml
    ├── layout/dialog_settings.xml
    └── values/{strings,colors}.xml
```
