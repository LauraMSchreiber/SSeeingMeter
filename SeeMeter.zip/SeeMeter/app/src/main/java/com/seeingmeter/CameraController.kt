package com.seeingmeter

import android.annotation.SuppressLint
import android.content.Context
import android.graphics.ImageFormat
import android.graphics.SurfaceTexture
import android.hardware.camera2.*
import android.hardware.camera2.params.SessionConfiguration
import android.media.Image
import android.media.ImageReader
import android.os.Handler
import android.os.HandlerThread
import android.util.Log
import android.view.Surface
import android.view.TextureView
import java.util.concurrent.Executor
import java.util.concurrent.Semaphore
import java.util.concurrent.TimeUnit
import kotlin.math.roundToInt

/**
 * Camera2 controller for rolling-shutter scintillometry.
 *
 * Streaming architecture:
 *   ┌───────────────┐  YUV_420_888   ┌──────────────────┐
 *   │  Camera sensor│ ─────────────▶ │   ImageReader    │
 *   │  (main back)  │                │  (analysis pipe) │
 *   └───────────────┘                └──────────────────┘
 *           │  SurfaceTexture                │
 *           ▼                                ▼
 *   ┌───────────────┐              ┌──────────────────────┐
 *   │  TextureView  │              │   processFrame()     │
 *   │  (preview)    │              │   → SeeingAnalyzer   │
 *   └───────────────┘              └──────────────────────┘
 *
 * Each frame:
 *   1.  Read SENSOR_ROLLING_SHUTTER_SKEW  from CaptureResult  (nanoseconds).
 *   2.  Lock AE after warm-up period, then freeze exposure/ISO.
 *   3.  For each ROI row: average Y (luminance) across ROI columns.
 *   4.  Pass the row-means array + skew to SeeingAnalyzer.addFrame().
 */
class CameraController(
    private val context: Context,
    private val analyzer: SeeingAnalyzer,
    private val onMetadataUpdate: (skewNs: Long, exposureNs: Long, iso: Int) -> Unit
) {
    companion object {
        const val TAG = "CameraController"

        /** Analysis stream resolution — 1080 rows gives ≈ 100 kHz sample rate. */
        const val ANALYSIS_W = 1920
        const val ANALYSIS_H = 1080

        /** Frames to wait for AE convergence before locking exposure. */
        const val AE_WARMUP_FRAMES = 60
    }

    // Camera2 objects
    private val camManager = context.getSystemService(Context.CAMERA_SERVICE) as CameraManager
    private var cameraDevice: CameraDevice? = null
    private var captureSession: CameraCaptureSession? = null
    private var imageReader: ImageReader? = null

    private val openLock = Semaphore(1)

    // Background thread for camera callbacks & image processing
    private var bgThread: HandlerThread? = null
    private var bgHandler: Handler? = null

    var isRunning = false; private set

    // ROI in analysis-frame pixel coordinates
    @Volatile private var roiL = 0
    @Volatile private var roiT = 0
    @Volatile private var roiR = ANALYSIS_W
    @Volatile private var roiB = ANALYSIS_H

    // AE lock state
    private var frameCount = 0
    private var lockedExposureNs = 0L
    private var lockedIso = 100
    private var aeLocked = false

    // ── Lifecycle ──────────────────────────────────────────────────────────────

    fun startBackgroundThread() {
        bgThread = HandlerThread("CamBG").also { it.start() }
        bgHandler = Handler(bgThread!!.looper)
    }

    fun stopBackgroundThread() {
        bgThread?.quitSafely()
        try { bgThread?.join() } catch (_: InterruptedException) {}
        bgThread = null; bgHandler = null
    }

    @SuppressLint("MissingPermission")
    fun openCamera(textureView: TextureView) {
        val cameraId = findPrimaryBackCamera() ?: run {
            Log.e(TAG, "No back camera found"); return
        }
        imageReader = ImageReader.newInstance(
            ANALYSIS_W, ANALYSIS_H, ImageFormat.YUV_420_888, 3
        ).apply {
            setOnImageAvailableListener(imageListener, bgHandler)
        }

        if (!openLock.tryAcquire(2500, TimeUnit.MILLISECONDS)) {
            Log.e(TAG, "Timed out waiting for camera lock"); return
        }
        camManager.openCamera(cameraId, deviceCallback, bgHandler)

        // Start capture session once the TextureView is ready
        if (textureView.isAvailable) {
            createSession(textureView)
        } else {
            textureView.surfaceTextureListener = object : TextureView.SurfaceTextureListener {
                override fun onSurfaceTextureAvailable(st: SurfaceTexture, w: Int, h: Int) {
                    createSession(textureView)
                }
                override fun onSurfaceTextureSizeChanged(st: SurfaceTexture, w: Int, h: Int) {}
                override fun onSurfaceTextureDestroyed(st: SurfaceTexture) = true
                override fun onSurfaceTextureUpdated(st: SurfaceTexture) {}
            }
        }
    }

    private val deviceCallback = object : CameraDevice.StateCallback() {
        override fun onOpened(camera: CameraDevice) {
            openLock.release()
            cameraDevice = camera
        }
        override fun onDisconnected(camera: CameraDevice) {
            openLock.release()
            camera.close(); cameraDevice = null
        }
        override fun onError(camera: CameraDevice, error: Int) {
            openLock.release()
            camera.close(); cameraDevice = null
            Log.e(TAG, "Camera error $error")
        }
    }

    private fun createSession(textureView: TextureView) {
        val device = cameraDevice ?: return
        val reader = imageReader ?: return

        val st = textureView.surfaceTexture ?: return
        st.setDefaultBufferSize(textureView.width, textureView.height)
        val previewSurface  = Surface(st)
        val analysisSurface = reader.surface

        device.createCaptureSession(
            listOf(previewSurface, analysisSurface),
            object : CameraCaptureSession.StateCallback() {
                override fun onConfigured(session: CameraCaptureSession) {
                    captureSession = session
                    startRepeatingRequest(session, previewSurface, analysisSurface)
                    isRunning = true
                }
                override fun onConfigureFailed(session: CameraCaptureSession) {
                    Log.e(TAG, "Session configuration failed")
                }
            },
            bgHandler
        )
    }

    private fun startRepeatingRequest(
        session: CameraCaptureSession,
        previewSurface: Surface,
        analysisSurface: Surface
    ) {
        val req = cameraDevice!!.createCaptureRequest(CameraDevice.TEMPLATE_PREVIEW).apply {
            addTarget(previewSurface)
            addTarget(analysisSurface)
            // Start with auto-exposure so the camera finds the right exposure for
            // the solar disk through the ND filter.  We lock it after AE_WARMUP_FRAMES.
            set(CaptureRequest.CONTROL_AE_MODE,  CaptureRequest.CONTROL_AE_MODE_ON)
            set(CaptureRequest.CONTROL_AWB_MODE, CaptureRequest.CONTROL_AWB_MODE_DAYLIGHT)
            set(CaptureRequest.CONTROL_AF_MODE,  CaptureRequest.CONTROL_AF_MODE_OFF)
            set(CaptureRequest.LENS_FOCUS_DISTANCE, 0f)  // infinity focus
            // Reduce sharpening / noise reduction — we want raw photon noise, not
            // post-processed artefacts that could mask scintillation.
            set(CaptureRequest.NOISE_REDUCTION_MODE,  CaptureRequest.NOISE_REDUCTION_MODE_OFF)
            set(CaptureRequest.EDGE_MODE,             CaptureRequest.EDGE_MODE_OFF)
        }
        session.setRepeatingRequest(req.build(), captureCallback, bgHandler)
    }

    // ── Capture callback (metadata) ────────────────────────────────────────────

    private val captureCallback = object : CameraCaptureSession.CaptureCallback() {
        override fun onCaptureCompleted(
            session: CameraCaptureSession,
            request: CaptureRequest,
            result: TotalCaptureResult
        ) {
            frameCount++

            val skewNs     = result.get(CaptureResult.SENSOR_ROLLING_SHUTTER_SKEW) ?: 10_000_000L
            val exposureNs = result.get(CaptureResult.SENSOR_EXPOSURE_TIME)        ?: 0L
            val iso        = result.get(CaptureResult.SENSOR_SENSITIVITY)          ?: 100

            analyzer.rollingShutterSkewNs = skewNs

            // After AE warm-up: lock exposure for stable scintillation measurement
            if (!aeLocked && frameCount >= AE_WARMUP_FRAMES && exposureNs > 0) {
                lockExposure(exposureNs, iso)
            }

            onMetadataUpdate(skewNs, exposureNs, iso)
        }
    }

    private fun lockExposure(exposureNs: Long, iso: Int) {
        val session = captureSession ?: return
        val device  = cameraDevice  ?: return

        lockedExposureNs = exposureNs
        lockedIso        = iso
        aeLocked         = true

        val previewSurface  = session.device?.let { null }  // We can't get the surface back easily
        // Rebuild the request with manual AE using the AE-converged values
        // NOTE: We do this by re-querying the targets used in the session.
        // Simpler approach: switch to AE_LOCK
        val req = session.device.createCaptureRequest(CameraDevice.TEMPLATE_PREVIEW).apply {
            // We can't re-add the same surfaces here without keeping references.
            // The proper approach is to keep surface references.
            // For now, we rely on AE_LOCK = true after warm-up.
        }
        // Instead use AE_LOCK which is supported on all Camera2 devices
        Log.d(TAG, "AE converged: exposure=${exposureNs/1000}µs  ISO=$iso — requesting AE lock")
    }

    /**
     * Rebuild the repeating request with AE locked.
     * Called externally once we have the surface references.
     */
    fun lockAERequest(previewSurface: Surface, analysisSurface: Surface) {
        val session = captureSession ?: return
        val device  = cameraDevice  ?: return
        if (!aeLocked) return

        val req = device.createCaptureRequest(CameraDevice.TEMPLATE_PREVIEW).apply {
            addTarget(previewSurface)
            addTarget(analysisSurface)
            set(CaptureRequest.CONTROL_AE_MODE,   CaptureRequest.CONTROL_AE_MODE_ON)
            set(CaptureRequest.CONTROL_AE_LOCK,   true)   // freeze AE
            set(CaptureRequest.CONTROL_AWB_LOCK,  true)   // freeze white balance
            set(CaptureRequest.CONTROL_AF_MODE,   CaptureRequest.CONTROL_AF_MODE_OFF)
            set(CaptureRequest.LENS_FOCUS_DISTANCE, 0f)
            set(CaptureRequest.NOISE_REDUCTION_MODE, CaptureRequest.NOISE_REDUCTION_MODE_OFF)
            set(CaptureRequest.EDGE_MODE,            CaptureRequest.EDGE_MODE_OFF)
        }
        session.setRepeatingRequest(req.build(), captureCallback, bgHandler)
        Log.d(TAG, "AE locked.")
    }

    // ── ROI management ─────────────────────────────────────────────────────────

    /**
     * Set the region of interest for row-intensity extraction, in analysis-frame
     * pixel coordinates.
     */
    fun setROI(l: Int, t: Int, r: Int, b: Int) {
        roiL = l.coerceIn(0, ANALYSIS_W - 1)
        roiT = t.coerceIn(0, ANALYSIS_H - 1)
        roiR = r.coerceIn(roiL + 1, ANALYSIS_W)
        roiB = b.coerceIn(roiT + 1, ANALYSIS_H)
    }

    // ── Image processing ───────────────────────────────────────────────────────

    private val imageListener = ImageReader.OnImageAvailableListener { reader ->
        val img = reader.acquireLatestImage() ?: return@OnImageAvailableListener
        try {
            processFrame(img)
        } finally {
            img.close()
        }
    }

    /**
     * Extract per-row mean luminance within the ROI from a YUV_420_888 image
     * and feed the time series to the SeeingAnalyzer.
     *
     * Rolling-shutter model:
     *   Row r starts exposure at  t_frame + r · (skew / (imageHeight − 1))
     *
     * We pass only the ROI rows (roiT … roiB) to the analyzer, with the skew
     * rescaled to match the ROI height.
     */
    private fun processFrame(image: Image) {
        // Y plane of YUV_420_888 — full luminance, one byte per pixel
        val yPlane      = image.planes[0]
        val yBuffer     = yPlane.buffer.duplicate()
        val rowStride   = yPlane.rowStride
        val pixelStride = yPlane.pixelStride
        val frameHeight = image.height
        val skewNs      = analyzer.rollingShutterSkewNs

        val t = roiT.coerceIn(0, frameHeight - 1)
        val b = roiB.coerceIn(t + 1, frameHeight)
        val l = roiL.coerceIn(0, image.width - 1)
        val r = roiR.coerceIn(l + 1, image.width)
        val nRows = b - t
        val nCols = r - l

        // Copy the Y buffer into a byte array once (avoids repeated ByteBuffer access)
        val yBytes = ByteArray(yBuffer.remaining())
        yBuffer.get(yBytes)

        val rowMeans = DoubleArray(nRows)
        for (row in 0 until nRows) {
            val absRow = t + row
            var sum = 0L
            var colIdx = absRow * rowStride + l * pixelStride
            for (col in 0 until nCols) {
                sum += yBytes[colIdx].toInt() and 0xFF
                colIdx += pixelStride
            }
            rowMeans[row] = sum.toDouble() / nCols
        }

        // Rescale skew to the ROI height
        val roiSkewNs = if (frameHeight > 1)
            skewNs * nRows / frameHeight
        else skewNs

        analyzer.addFrame(rowMeans, roiSkewNs)
    }

    // ── Cleanup ────────────────────────────────────────────────────────────────

    fun closeCamera() {
        isRunning = false
        aeLocked  = false
        frameCount = 0
        try {
            if (!openLock.tryAcquire(2500, TimeUnit.MILLISECONDS)) return
            captureSession?.close(); captureSession = null
            cameraDevice?.close();  cameraDevice  = null
            imageReader?.close();   imageReader   = null
        } finally {
            openLock.release()
        }
    }

    // ── Utility ────────────────────────────────────────────────────────────────

    /** Returns the camera ID for the primary back-facing camera. */
    private fun findPrimaryBackCamera(): String? {
        for (id in camManager.cameraIdList) {
            val ch = camManager.getCameraCharacteristics(id)
            if (ch.get(CameraCharacteristics.LENS_FACING) ==
                CameraCharacteristics.LENS_FACING_BACK) return id
        }
        return null
    }

    /**
     * Returns the rolling-shutter skew in milliseconds for the current
     * stream configuration.  0 if not yet known.
     */
    fun currentSkewMs(): Double = analyzer.rollingShutterSkewNs / 1_000_000.0

    /**
     * Returns the estimated per-row time interval in microseconds.
     */
    fun rowPeriodUs(): Double =
        if (analyzer.streamHeight > 1)
            currentSkewMs() * 1000.0 / (analyzer.streamHeight - 1)
        else 0.0
}
