package com.seeingmeter

import android.annotation.SuppressLint
import android.content.Context
import android.graphics.ImageFormat
import android.graphics.SurfaceTexture
import android.hardware.camera2.*
import android.media.ImageReader
import android.os.Handler
import android.os.HandlerThread
import android.util.Log
import android.view.Surface
import android.view.TextureView
import java.util.concurrent.Semaphore
import java.util.concurrent.TimeUnit

/**
 * Camera2 controller — clean, race-condition-free design.
 *
 * Design principle:
 *   All surface setup happens on the MAIN THREAD inside openCameraInternal(),
 *   which is called directly from the SurfaceTexture callbacks (main thread).
 *   By the time openCamera() fires its async onOpened() callback, the Surface
 *   objects are already fully constructed and stored — no thread-unsafe
 *   View.isAvailable() calls needed on the background thread.
 *
 * Call sequence:
 *   MainActivity.onResume()
 *     → cameraController.startBackgroundThread()
 *     → cameraController.attachTextureView(textureView)
 *         → if surface ready: openCameraInternal()   [main thread]
 *         → else: wait for onSurfaceTextureAvailable → openCameraInternal()
 *
 *   openCameraInternal()  [main thread]
 *     → build previewSurface + analysisSurface
 *     → camManager.openCamera(...)  [async]
 *
 *   deviceCallback.onOpened()  [bg thread]
 *     → createCaptureSession()   ← surfaces already set, no View access needed
 */
class CameraController(
    private val context: Context,
    private val analyzer: SeeingAnalyzer,
    private val onMetadataUpdate: (skewNs: Long, exposureNs: Long, iso: Int) -> Unit
) {
    companion object {
        const val TAG = "CameraController"
        const val ANALYSIS_W = 1920
        const val ANALYSIS_H = 1080
        const val AE_WARMUP_FRAMES = 90   // ~3 s at 30 fps before locking AE
    }

    private val camManager =
        context.getSystemService(Context.CAMERA_SERVICE) as CameraManager

    private var textureView: TextureView? = null
    private var cameraDevice: CameraDevice? = null
    private var captureSession: CameraCaptureSession? = null
    private var imageReader: ImageReader? = null

    // Surfaces built on main thread, read on bg thread — volatile for visibility
    @Volatile private var previewSurface: Surface? = null
    @Volatile private var analysisSurface: Surface? = null

    private val openLock = Semaphore(1)
    var bgThread: HandlerThread? = null
    var bgHandler: Handler? = null

    var isRunning = false; private set

    private var frameCount = 0
    @Volatile private var aeLocked = false

    // ROI defaults to full frame
    @Volatile var roiL = 0; @Volatile var roiT = 0
    @Volatile var roiR = ANALYSIS_W; @Volatile var roiB = ANALYSIS_H

    // ── Thread management ──────────────────────────────────────────────────────

    fun startBackgroundThread() {
        if (bgThread?.isAlive == true) return   // already running
        bgThread = HandlerThread("CamBG").also { it.start() }
        bgHandler = Handler(bgThread!!.looper)
    }

    fun stopBackgroundThread() {
        bgThread?.quitSafely()
        try { bgThread?.join(1000) } catch (_: InterruptedException) {}
        bgThread = null; bgHandler = null
    }

    // ── Attach / detach ────────────────────────────────────────────────────────

    /**
     * Attach to a TextureView.  If the surface is already available, opens the
     * camera immediately.  Otherwise waits for onSurfaceTextureAvailable.
     * Must be called on the MAIN thread.
     */
    fun attachTextureView(tv: TextureView) {
        textureView = tv
        tv.surfaceTextureListener = surfaceListener
        if (tv.isAvailable) {
            Log.d(TAG, "Surface already available — opening camera now")
            openCameraInternal(tv)
        } else {
            Log.d(TAG, "Surface not yet available — waiting for callback")
        }
    }

    fun detach() {
        closeCamera()
        textureView?.surfaceTextureListener = null
        textureView = null
    }

    // ── Surface listener (main thread callbacks) ───────────────────────────────

    private val surfaceListener = object : TextureView.SurfaceTextureListener {
        override fun onSurfaceTextureAvailable(st: SurfaceTexture, w: Int, h: Int) {
            Log.d(TAG, "onSurfaceTextureAvailable ${w}x${h}")
            val tv = textureView ?: return
            openCameraInternal(tv)
        }
        override fun onSurfaceTextureSizeChanged(st: SurfaceTexture, w: Int, h: Int) {
            Log.d(TAG, "onSurfaceTextureSizeChanged ${w}x${h}")
        }
        override fun onSurfaceTextureDestroyed(st: SurfaceTexture): Boolean {
            Log.d(TAG, "onSurfaceTextureDestroyed — closing camera")
            closeCamera()
            return true
        }
        override fun onSurfaceTextureUpdated(st: SurfaceTexture) {}
    }

    // ── Open camera (called on main thread, surfaces set here) ─────────────────

    @SuppressLint("MissingPermission")
    private fun openCameraInternal(tv: TextureView) {
        // ── Build surfaces on main thread (safe to access View here) ──────────
        val st = tv.surfaceTexture ?: run {
            Log.e(TAG, "surfaceTexture is null"); return
        }
        val w = tv.width.coerceAtLeast(640)
        val h = tv.height.coerceAtLeast(480)
        st.setDefaultBufferSize(w, h)

        // Close any previous reader/session first
        closeCamera()

        val reader = ImageReader.newInstance(
            ANALYSIS_W, ANALYSIS_H, ImageFormat.YUV_420_888, 3
        ).apply { setOnImageAvailableListener(imageListener, bgHandler) }

        imageReader   = reader
        previewSurface  = Surface(st)
        analysisSurface = reader.surface

        // ── Open camera asynchronously ────────────────────────────────────────
        val cameraId = findBackCamera() ?: run {
            Log.e(TAG, "No back camera found"); return
        }

        if (!openLock.tryAcquire(2500, TimeUnit.MILLISECONDS)) {
            Log.e(TAG, "Timed out waiting for camera open lock"); return
        }

        frameCount = 0; aeLocked = false

        try {
            Log.d(TAG, "Calling camManager.openCamera id=$cameraId")
            camManager.openCamera(cameraId, deviceCallback, bgHandler)
        } catch (e: SecurityException) {
            openLock.release()
            Log.e(TAG, "Camera permission denied: $e")
        } catch (e: Exception) {
            openLock.release()
            Log.e(TAG, "openCamera failed: $e")
        }
    }

    // ── Device callback (bg thread) ────────────────────────────────────────────

    private val deviceCallback = object : CameraDevice.StateCallback() {
        override fun onOpened(camera: CameraDevice) {
            Log.d(TAG, "onOpened — creating capture session")
            openLock.release()
            cameraDevice = camera
            // Surfaces were set on main thread — safe to read @Volatile fields here
            createCaptureSession()
        }
        override fun onDisconnected(camera: CameraDevice) {
            Log.w(TAG, "Camera disconnected")
            openLock.release()
            camera.close(); cameraDevice = null; isRunning = false
        }
        override fun onError(camera: CameraDevice, error: Int) {
            Log.e(TAG, "Camera device error: $error")
            openLock.release()
            camera.close(); cameraDevice = null; isRunning = false
        }
    }

    // ── Session creation (bg thread) ──────────────────────────────────────────

    private fun createCaptureSession() {
        val device = cameraDevice   ?: run { Log.e(TAG, "No cameraDevice"); return }
        val pSurf  = previewSurface  ?: run { Log.e(TAG, "No previewSurface"); return }
        val aSurf  = analysisSurface ?: run { Log.e(TAG, "No analysisSurface"); return }

        try {
            device.createCaptureSession(
                listOf(pSurf, aSurf),
                object : CameraCaptureSession.StateCallback() {
                    override fun onConfigured(session: CameraCaptureSession) {
                        Log.d(TAG, "Session configured — starting repeating request")
                        captureSession = session
                        startRepeatingRequest(session)
                        isRunning = true
                    }
                    override fun onConfigureFailed(session: CameraCaptureSession) {
                        Log.e(TAG, "Session configuration FAILED")
                    }
                },
                bgHandler
            )
        } catch (e: Exception) {
            Log.e(TAG, "createCaptureSession failed: $e")
        }
    }

    // ── Repeating capture request ──────────────────────────────────────────────

    private fun startRepeatingRequest(session: CameraCaptureSession) {
        val device = cameraDevice    ?: return
        val pSurf  = previewSurface  ?: return
        val aSurf  = analysisSurface ?: return

        val req = device.createCaptureRequest(CameraDevice.TEMPLATE_PREVIEW).apply {
            addTarget(pSurf)
            addTarget(aSurf)
            set(CaptureRequest.CONTROL_MODE,    CaptureRequest.CONTROL_MODE_AUTO)
            set(CaptureRequest.CONTROL_AE_MODE, CaptureRequest.CONTROL_AE_MODE_ON)
            set(CaptureRequest.CONTROL_AE_LOCK, aeLocked)
            set(CaptureRequest.CONTROL_AWB_MODE, CaptureRequest.CONTROL_AWB_MODE_AUTO)
            set(CaptureRequest.CONTROL_AWB_LOCK, aeLocked)
            set(CaptureRequest.CONTROL_AF_MODE,  CaptureRequest.CONTROL_AF_MODE_OFF)
            set(CaptureRequest.LENS_FOCUS_DISTANCE, 0f)        // infinity
            set(CaptureRequest.NOISE_REDUCTION_MODE,
                CaptureRequest.NOISE_REDUCTION_MODE_OFF)
            set(CaptureRequest.EDGE_MODE, CaptureRequest.EDGE_MODE_OFF)
        }
        try {
            session.setRepeatingRequest(req.build(), captureCallback, bgHandler)
        } catch (e: Exception) {
            Log.e(TAG, "setRepeatingRequest failed: $e")
        }
    }

    // ── Capture callback ───────────────────────────────────────────────────────

    private val captureCallback = object : CameraCaptureSession.CaptureCallback() {
        override fun onCaptureCompleted(
            session: CameraCaptureSession,
            request: CaptureRequest,
            result: TotalCaptureResult
        ) {
            frameCount++
            val skewNs = result.get(CaptureResult.SENSOR_ROLLING_SHUTTER_SKEW) ?: 10_000_000L
            val expNs  = result.get(CaptureResult.SENSOR_EXPOSURE_TIME)         ?: 0L
            val iso    = result.get(CaptureResult.SENSOR_SENSITIVITY)           ?: 100

            analyzer.rollingShutterSkewNs = skewNs
            onMetadataUpdate(skewNs, expNs, iso)

            if (!aeLocked && frameCount == AE_WARMUP_FRAMES) {
                Log.d(TAG, "Locking AE: exp=${expNs/1000}µs ISO=$iso")
                aeLocked = true
                val sess = captureSession ?: return
                startRepeatingRequest(sess)
            }
        }
        override fun onCaptureFailed(
            session: CameraCaptureSession,
            request: CaptureRequest,
            failure: CaptureFailure
        ) {
            Log.w(TAG, "Capture failed reason=${failure.reason}")
        }
    }

    // ── Image processing ───────────────────────────────────────────────────────

    private val imageListener = ImageReader.OnImageAvailableListener { reader ->
        val img = reader.acquireLatestImage() ?: return@OnImageAvailableListener
        try { processFrame(img) } finally { img.close() }
    }

    private fun processFrame(image: android.media.Image) {
        val yPlane    = image.planes[0]
        val yBuffer   = yPlane.buffer
        val rowStride = yPlane.rowStride
        val pixStride = yPlane.pixelStride
        val skewNs    = analyzer.rollingShutterSkewNs

        val t     = roiT.coerceIn(0, image.height - 1)
        val b     = roiB.coerceIn(t + 1, image.height)
        val l     = roiL.coerceIn(0, image.width - 1)
        val r     = roiR.coerceIn(l + 1, image.width)
        val nRows = b - t
        val nCols = r - l

        val yBytes = ByteArray(yBuffer.remaining()).also { yBuffer.get(it) }
        val rowMeans = DoubleArray(nRows) { row ->
            var sum = 0L
            var idx = (t + row) * rowStride + l * pixStride
            repeat(nCols) { sum += yBytes[idx].toInt() and 0xFF; idx += pixStride }
            sum.toDouble() / nCols
        }

        val roiSkewNs = if (image.height > 1) skewNs * nRows / image.height else skewNs
        analyzer.addFrame(rowMeans, roiSkewNs)
    }

    // ── ROI ───────────────────────────────────────────────────────────────────

    fun setROI(l: Int, t: Int, r: Int, b: Int) {
        roiL = l.coerceIn(0, ANALYSIS_W - 1); roiT = t.coerceIn(0, ANALYSIS_H - 1)
        roiR = r.coerceIn(roiL + 1, ANALYSIS_W); roiB = b.coerceIn(roiT + 1, ANALYSIS_H)
    }

    // ── Cleanup ────────────────────────────────────────────────────────────────

    fun closeCamera() {
        isRunning = false
        try {
            if (!openLock.tryAcquire(2500, TimeUnit.MILLISECONDS)) {
                Log.w(TAG, "closeCamera: lock timeout"); return
            }
            captureSession?.close(); captureSession = null
            cameraDevice?.close();  cameraDevice  = null
            imageReader?.close();   imageReader   = null
            previewSurface?.release();  previewSurface  = null
            analysisSurface?.release(); analysisSurface = null
        } catch (e: Exception) {
            Log.e(TAG, "closeCamera error: $e")
        } finally {
            try { openLock.release() } catch (_: Exception) {}
        }
    }

    // ── Utility ───────────────────────────────────────────────────────────────

    private fun findBackCamera(): String? {
        // Prefer camera "0" which is typically the primary back camera
        // Fall back to first LENS_FACING_BACK if "0" is front-facing
        val ids = camManager.cameraIdList
        // First try: the camera explicitly facing back with the longest focal length
        return ids.filter { id ->
            val ch = camManager.getCameraCharacteristics(id)
            ch.get(CameraCharacteristics.LENS_FACING) ==
                    CameraCharacteristics.LENS_FACING_BACK
        }.maxByOrNull { id ->
            val ch = camManager.getCameraCharacteristics(id)
            ch.get(CameraCharacteristics.LENS_INFO_AVAILABLE_FOCAL_LENGTHS)
                ?.maxOrNull() ?: 0f
        }
    }

    fun currentSkewMs() = analyzer.rollingShutterSkewNs / 1_000_000.0
    fun rowPeriodUs()   = if (analyzer.streamHeight > 1)
        currentSkewMs() * 1000.0 / (analyzer.streamHeight - 1) else 0.0
}
