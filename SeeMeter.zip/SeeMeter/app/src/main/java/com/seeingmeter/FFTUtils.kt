package com.seeingmeter

import kotlin.math.*

/**
 * FFT utilities for scintillation spectral analysis.
 *
 * Provides:
 *  - In-place Cooley-Tukey radix-2 FFT
 *  - Welch power spectral density estimator (averaged periodograms)
 *  - Characteristic frequency finder
 *  - Kolmogorov spectrum fitter
 */
object FFTUtils {

    /**
     * In-place Cooley-Tukey FFT. N must be a power of 2.
     * After the call, re[k] + j*im[k] is the k-th DFT coefficient.
     */
    fun fft(re: DoubleArray, im: DoubleArray) {
        val n = re.size
        require(n and (n - 1) == 0) { "FFT size must be a power of 2, got $n" }

        // Bit-reversal permutation
        var j = 0
        for (i in 1 until n) {
            var bit = n ushr 1
            while (j and bit != 0) {
                j = j xor bit
                bit = bit ushr 1
            }
            j = j xor bit
            if (i < j) {
                var t = re[i]; re[i] = re[j]; re[j] = t
                t = im[i]; im[i] = im[j]; im[j] = t
            }
        }

        // Danielson-Lanczos butterfly
        var len = 2
        while (len <= n) {
            val ang = -2.0 * PI / len
            val wBaseRe = cos(ang)
            val wBaseIm = sin(ang)
            var i = 0
            while (i < n) {
                var wRe = 1.0; var wIm = 0.0
                for (jj in 0 until len / 2) {
                    val uRe = re[i + jj];     val uIm = im[i + jj]
                    val vRe = re[i + jj + len / 2] * wRe - im[i + jj + len / 2] * wIm
                    val vIm = re[i + jj + len / 2] * wIm + im[i + jj + len / 2] * wRe
                    re[i + jj]         = uRe + vRe;  im[i + jj]         = uIm + vIm
                    re[i + jj + len/2] = uRe - vRe;  im[i + jj + len/2] = uIm - vIm
                    val newWRe = wRe * wBaseRe - wIm * wBaseIm
                    wIm = wRe * wBaseIm + wIm * wBaseRe
                    wRe = newWRe
                }
                i += len
            }
            len = len shl 1
        }
    }

    /**
     * Welch power spectral density estimator.
     *
     * Divides [signal] into overlapping Hann-windowed segments, computes the
     * periodogram of each, and returns the ensemble average.  This gives a
     * consistent PSD estimate in units of (signal_unit)²/Hz.
     *
     * @param signal        Normalized intensity time series  s(t) = δI/⟨I⟩
     * @param sampleRateHz  Sampling frequency (rows / rolling-shutter duration)
     * @param segmentLen    Segment length (power-of-2, default 512)
     * @param overlap       Fractional overlap between segments (0 … 0.9)
     * @return Pair(frequencies_Hz, psd_values)
     */
    fun welchPSD(
        signal: DoubleArray,
        sampleRateHz: Double,
        segmentLen: Int = 512,
        overlap: Double = 0.5
    ): Pair<DoubleArray, DoubleArray> {

        val nFreqs = segmentLen / 2 + 1
        val psdAccum = DoubleArray(nFreqs)
        val step = ((1.0 - overlap) * segmentLen).toInt().coerceAtLeast(1)

        // Hann window and its power (for normalisation)
        val window = DoubleArray(segmentLen) { k ->
            0.5 * (1.0 - cos(2.0 * PI * k / (segmentLen - 1)))
        }
        val windowPower = window.sumOf { it * it }

        var count = 0
        var start = 0
        while (start + segmentLen <= signal.size) {
            val re = DoubleArray(segmentLen) { signal[start + it] * window[it] }
            val im = DoubleArray(segmentLen)
            fft(re, im)

            for (k in 0 until nFreqs) {
                val p = (re[k] * re[k] + im[k] * im[k]) / (sampleRateHz * windowPower)
                // One-sided PSD: double all bins except DC and Nyquist
                psdAccum[k] += if (k == 0 || k == segmentLen / 2) p else 2.0 * p
            }
            count++
            start += step
        }

        if (count == 0) return Pair(DoubleArray(0), DoubleArray(0))

        val freqs = DoubleArray(nFreqs) { it * sampleRateHz / segmentLen }
        val psd   = DoubleArray(nFreqs) { psdAccum[it] / count }
        return Pair(freqs, psd)
    }

    /**
     * Estimates the characteristic (Fresnel rolloff) frequency by fitting the
     * theoretical Kolmogorov scintillation PSD shape:
     *
     *   P(f) ∝ (f/fc)^(1/3) · [1 + (f/fc)²]^(-11/6)
     *
     * Uses log-least-squares over the range [minFreq, maxFreq].
     *
     * @return Best-fit fc in Hz, or NaN if fit fails.
     */
    fun fitKolmogorovFrequency(
        freqs: DoubleArray,
        psd: DoubleArray,
        minFreqHz: Double = 20.0,
        maxFreqHz: Double = Double.MAX_VALUE
    ): Double {
        if (freqs.size < 10) return Double.NaN

        // Grid search over fc candidates in log space
        val fcCandidates = (1..200).map { 10.0.pow(it * 0.03 - 0.5) }  // ~3 … ~3000 Hz
        var bestFc = Double.NaN
        var bestResidual = Double.MAX_VALUE

        for (fc in fcCandidates) {
            var ssr = 0.0; var cnt = 0
            for (i in freqs.indices) {
                val f = freqs[i]
                if (f < minFreqHz || f > maxFreqHz || psd[i] <= 0.0) continue
                val x = f / fc
                val model = x.pow(1.0/3.0) * (1.0 + x * x).pow(-11.0/6.0)
                if (model <= 0.0) continue
                val res = ln(psd[i]) - ln(model)
                ssr += res * res
                cnt++
            }
            if (cnt > 5 && ssr < bestResidual) {
                bestResidual = ssr
                bestFc = fc
            }
        }
        return bestFc
    }

    /** Returns the smallest power of 2 ≥ n. */
    fun nextPow2(n: Int): Int {
        var p = 1
        while (p < n) p = p shl 1
        return p
    }
}
