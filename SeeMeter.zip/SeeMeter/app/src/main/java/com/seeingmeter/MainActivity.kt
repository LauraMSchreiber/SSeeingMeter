package com.seeingmeter

import android.Manifest
import android.content.pm.PackageManager
import android.graphics.*
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.view.*
import android.widget.*
import androidx.appcompat.app.AlertDialog
import androidx.appcompat.app.AppCompatActivity
import androidx.core.app.ActivityCompat
import androidx.core.content.ContextCompat
import kotlin.math.*

/**
 * SeeMeter — Atmospheric Seeing Meter
 *
 * Uses the rolling shutter of the phone camera as a high-rate photometer:
 *   • Each sensor row is read at a slightly later time (Δt ~ 3–10 µs)
 *   • Row-averaged brightness within the solar-disk ROI forms a ~100 kHz
 *     intensity time series
 *   • FFT of that time series gives the scintillation power spectrum
 *   • Scintillation variance → Fried radius r₀ and seeing in arcseconds
 *
 * ⚠️  ALWAYS use a certified solar ND 5.0 filter over the camera lens.
 */
class MainActivity : AppCompatActivity() {

    companion object {
        private const val TAG = "SeeMeter"
        private const val PERM_CAMERA = Manifest.permission.CAMERA
        private const val REQ_CAMERA  = 1001
        private const val ANALYSIS_INTERVAL_MS = 2000L
        private const val AE_LOCK_DELAY_MS      = 5000L  // lock AE after 5 s
    }

    // ── Views ──────────────────────────────────────────────────────────────────
    private lateinit var textureView:  TextureView
    private lateinit var roiOverlay:   RoiOverlayView
    private lateinit var tvR0:         TextView
    private lateinit var tvSeeing:     TextView
    private lateinit var tvSigma:      TextView
    private lateinit var tvFreq:       TextView
    private lateinit var tvSampleRate: TextView
    private lateinit var tvStatus:     TextView
    private lateinit var tvExposure:   TextView
    private lateinit var btnMeasure:   Button
    private lateinit var btnSettings:  Button
    private lateinit var btnReset:     Button
    private lateinit var spectrumView: SpectrumView

    // ── Core objects ───────────────────────────────────────────────────────────
    private lateinit var analyzer:          SeeingAnalyzer
    private lateinit var cameraController:  CameraController

    // ── State ──────────────────────────────────────────────────────────────────
    private val mainHandler = Handler(Looper.getMainLooper())
    private var isMeasuring  = false
    private var lastSkewNs   = 0L
    private var lastExpNs    = 0L
    private var lastIso      = 0

    // Preview/analysis surface references kept for AE locking
    private var previewSurface:  Surface? = null
    private var analysisSurface: Surface? = null

    // ── Analysis loop ──────────────────────────────────────────────────────────
    private val analysisRunnable = object : Runnable {
        override fun run() {
            if (isMeasuring) {
                updateResults()
                mainHandler.postDelayed(this, ANALYSIS_INTERVAL_MS)
            }
        }
    }

    // ── AE lock after warm-up ──────────────────────────────────────────────────
    private val aeLockRunnable = Runnable {
        val ps = previewSurface ?: return@Runnable
        val as_ = analysisSurface ?: return@Runnable
        cameraController.lockAERequest(ps, as_)
        tvStatus.text = "AE locked — measuring"
    }

    // ══════════════════════════════════════════════════════════════════════════
    //  Lifecycle
    // ══════════════════════════════════════════════════════════════════════════

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)

        // Full-screen, keep screen on during measurement
        window.addFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON)
        setContentView(R.layout.activity_main)

        bindViews()
        setupAnalyzerAndCamera()
        setupButtons()
        showSolarWarning()
    }

    override fun onResume() {
        super.onResume()
        if (hasCameraPermission()) openCamera()
    }

    override fun onPause() {
        super.onPause()
        stopMeasurement()
        mainHandler.removeCallbacks(aeLockRunnable)
        cameraController.closeCamera()
        cameraController.stopBackgroundThread()
    }

    // ══════════════════════════════════════════════════════════════════════════
    //  Setup
    // ══════════════════════════════════════════════════════════════════════════

    private fun bindViews() {
        textureView  = findViewById(R.id.textureView)
        roiOverlay   = findViewById(R.id.roiOverlay)
        tvR0         = findViewById(R.id.tvR0)
        tvSeeing     = findViewById(R.id.tvSeeing)
        tvSigma      = findViewById(R.id.tvSigma)
        tvFreq       = findViewById(R.id.tvFreq)
        tvSampleRate = findViewById(R.id.tvSampleRate)
        tvStatus     = findViewById(R.id.tvStatus)
        tvExposure   = findViewById(R.id.tvExposure)
        btnMeasure   = findViewById(R.id.btnMeasure)
        btnSettings  = findViewById(R.id.btnSettings)
        btnReset     = findViewById(R.id.btnReset)
        spectrumView = findViewById(R.id.spectrumView)
    }

    private fun setupAnalyzerAndCamera() {
        analyzer = SeeingAnalyzer()
        cameraController = CameraController(this, analyzer) { skewNs, expNs, iso ->
            lastSkewNs = skewNs; lastExpNs = expNs; lastIso = iso
            mainHandler.post { updateExposureDisplay() }
        }
    }

    private fun setupButtons() {
        btnMeasure.setOnClickListener {
            if (!isMeasuring) startMeasurement() else stopMeasurement()
        }
        btnSettings.setOnClickListener { showSettingsDialog() }
        btnReset.setOnClickListener {
            analyzer.reset()
            spectrumView.updateSpectrum(DoubleArray(0), DoubleArray(0), Double.NaN, Double.NaN)
            tvStatus.text = "Reset — point at solar disk, press Measure"
        }

        // Touch on preview → move ROI
        textureView.setOnTouchListener { _, event ->
            handleROITouch(event)
            true
        }
    }

    // ══════════════════════════════════════════════════════════════════════════
    //  Camera
    // ══════════════════════════════════════════════════════════════════════════

    private fun openCamera() {
        cameraController.startBackgroundThread()
        textureView.surfaceTextureListener = object : TextureView.SurfaceTextureListener {
            override fun onSurfaceTextureAvailable(st: SurfaceTexture, w: Int, h: Int) {
                cameraController.openCamera(textureView)
                updateROIOnCamera()
            }
            override fun onSurfaceTextureSizeChanged(st: SurfaceTexture, w: Int, h: Int) {
                updateROIOnCamera()
            }
            override fun onSurfaceTextureDestroyed(st: SurfaceTexture) = true
            override fun onSurfaceTextureUpdated(st: SurfaceTexture) {}
        }
        if (textureView.isAvailable) {
            cameraController.openCamera(textureView)
            updateROIOnCamera()
        }
    }

    // ══════════════════════════════════════════════════════════════════════════
    //  ROI management
    // ══════════════════════════════════════════════════════════════════════════

    // ROI in normalised preview coordinates [0,1]
    private var roiCx = 0.5f; private var roiCy = 0.5f
    private val roiHW = 0.18f;  private val roiHH = 0.22f   // half-width/height

    private fun handleROITouch(event: MotionEvent) {
        if (event.action == MotionEvent.ACTION_DOWN || event.action == MotionEvent.ACTION_MOVE) {
            roiCx = (event.x / textureView.width).coerceIn(roiHW, 1f - roiHW)
            roiCy = (event.y / textureView.height).coerceIn(roiHH, 1f - roiHH)
            updateROIOnCamera()
            roiOverlay.setROI(roiCx, roiCy, roiHW, roiHH)
        }
    }

    private fun updateROIOnCamera() {
        val l = ((roiCx - roiHW) * CameraController.ANALYSIS_W).toInt()
        val t = ((roiCy - roiHH) * CameraController.ANALYSIS_H).toInt()
        val r = ((roiCx + roiHW) * CameraController.ANALYSIS_W).toInt()
        val b = ((roiCy + roiHH) * CameraController.ANALYSIS_H).toInt()
        cameraController.setROI(l, t, r, b)
        roiOverlay.setROI(roiCx, roiCy, roiHW, roiHH)
    }

    // ══════════════════════════════════════════════════════════════════════════
    //  Measurement control
    // ══════════════════════════════════════════════════════════════════════════

    private fun startMeasurement() {
        isMeasuring = true
        analyzer.reset()
        btnMeasure.text = "■  Stop"
        btnMeasure.setBackgroundColor(Color.parseColor("#CC2222"))
        tvStatus.text = "Auto-exposing (5 s) — hold steady"
        mainHandler.postDelayed(aeLockRunnable, AE_LOCK_DELAY_MS)
        mainHandler.postDelayed(analysisRunnable, ANALYSIS_INTERVAL_MS)
    }

    private fun stopMeasurement() {
        isMeasuring = false
        mainHandler.removeCallbacks(analysisRunnable)
        mainHandler.removeCallbacks(aeLockRunnable)
        btnMeasure.text = "▶  Measure"
        btnMeasure.setBackgroundColor(Color.parseColor("#1B5E20"))
        tvStatus.text = "Stopped.  Last result shown above."
    }

    // ══════════════════════════════════════════════════════════════════════════
    //  Results display
    // ══════════════════════════════════════════════════════════════════════════

    private fun updateResults() {
        val res = analyzer.analyze()

        if (res == null) {
            tvStatus.text = "Collecting… ${analyzer.framesProcessed} frames buffered"
            return
        }

        // r₀ and seeing
        if (res.r0Cm.isNaN()) {
            tvR0.text    = "r₀ = —"
            tvSeeing.text = "Seeing = —"
        } else {
            tvR0.text    = "r₀ = %.1f cm  [%s]".format(res.r0Cm, res.qualityLabel)
            tvSeeing.text = "Seeing = %.2f\"".format(res.seeingArcsec)
        }

        tvSigma.text = "σ_I = %.4f  (scintillation index)".format(res.scintillationSigma)

        val fcStr = if (res.characteristicFreqHz.isFinite())
            "%.0f Hz".format(res.characteristicFreqHz) else "—"
        val ffStr = if (res.fresnelFreqHz.isFinite())
            "%.0f Hz".format(res.fresnelFreqHz) else "—"
        tvFreq.text = "f_char = $fcStr  |  f_Fresnel = $ffStr"

        tvSampleRate.text = "%.0f kHz  |  Δt_row = %.1f µs  |  %d frames".format(
            res.sampleRateHz / 1000.0,
            res.rowPeriodUs,
            res.framesProcessed
        )

        tvStatus.text = "Measuring  |  z = %.1f°  |  %d samples".format(
            res.zenithAngleDeg, res.nSamples
        )

        if (!res.isReliable) {
            tvStatus.text = tvStatus.text.toString() + "  ⚠ check exposure"
        }

        spectrumView.updateSpectrum(
            res.freqs, res.psd,
            res.characteristicFreqHz,
            res.fresnelFreqHz
        )
    }

    private fun updateExposureDisplay() {
        val expMs  = lastExpNs / 1_000_000.0
        val skewMs = lastSkewNs / 1_000_000.0
        val sRate  = if (skewMs > 0 && CameraController.ANALYSIS_H > 1)
            CameraController.ANALYSIS_H / (skewMs / 1000.0) / 1000.0 else 0.0
        tvExposure.text =
            "Exp: %.2f ms  ISO: %d  RS skew: %.1f ms  (~%.0f kHz)".format(
                expMs, lastIso, skewMs, sRate
            )
    }

    // ══════════════════════════════════════════════════════════════════════════
    //  Settings dialog
    // ══════════════════════════════════════════════════════════════════════════

    private fun showSettingsDialog() {
        val v = layoutInflater.inflate(R.layout.dialog_settings, null)

        val etZenith = v.findViewById<EditText>(R.id.etZenith)
        val etHeight = v.findViewById<EditText>(R.id.etHeight)
        val etWind   = v.findViewById<EditText>(R.id.etWind)
        val etLambda = v.findViewById<EditText>(R.id.etLambda)

        etZenith.setText("%.1f".format(analyzer.zenithAngleDeg))
        etHeight.setText("%.1f".format(analyzer.turbulenceHeightM / 1000.0))
        etWind.setText("%.1f".format(analyzer.windSpeedMs))
        etLambda.setText("%.0f".format(analyzer.wavelengthNm))

        AlertDialog.Builder(this, android.R.style.Theme_Material_Dialog_Alert)
            .setTitle("Measurement Parameters")
            .setView(v)
            .setPositiveButton("Apply") { _, _ ->
                etZenith.text.toString().toDoubleOrNull()?.let {
                    analyzer.zenithAngleDeg = it.coerceIn(0.0, 85.0)
                }
                etHeight.text.toString().toDoubleOrNull()?.let {
                    analyzer.turbulenceHeightM = (it * 1000.0).coerceIn(500.0, 20_000.0)
                }
                etWind.text.toString().toDoubleOrNull()?.let {
                    analyzer.windSpeedMs = it.coerceIn(0.5, 50.0)
                }
                etLambda.text.toString().toDoubleOrNull()?.let {
                    analyzer.wavelengthNm = it.coerceIn(400.0, 700.0)
                }
            }
            .setNegativeButton("Cancel", null)
            .show()
    }

    // ══════════════════════════════════════════════════════════════════════════
    //  Solar safety warning
    // ══════════════════════════════════════════════════════════════════════════

    private fun showSolarWarning() {
        AlertDialog.Builder(this, android.R.style.Theme_Material_Dialog_Alert)
            .setTitle("☀  SOLAR SAFETY — READ BEFORE USE")
            .setMessage(
                "WARNING: Direct solar observation WITHOUT a proper filter " +
                "will PERMANENTLY DAMAGE the camera sensor.\n\n" +
                "Required equipment:\n" +
                "  • Baader AstroSolar™ ND 5.0 safety film, OR\n" +
                "  • Any certified solar filter (optical density ≥ 4.0)\n" +
                "  • The filter MUST completely cover the lens\n\n" +
                "How to use:\n" +
                "  1. Attach the solar filter securely over the rear camera\n" +
                "  2. Point at the Sun — the disk should appear dim and grey\n" +
                "  3. Drag the ROI box onto the solar disk\n" +
                "  4. Tap MEASURE; wait 5 s for auto-exposure to settle\n\n" +
                "Results require a ~10–30 s measurement period.\n\n" +
                "This app is provided for scientific use. The authors accept " +
                "no liability for equipment damage."
            )
            .setPositiveButton("I have a solar filter — continue") { _, _ ->
                checkCameraPermission()
            }
            .setNegativeButton("Exit") { _, _ -> finish() }
            .setCancelable(false)
            .show()
    }

    // ══════════════════════════════════════════════════════════════════════════
    //  Permissions
    // ══════════════════════════════════════════════════════════════════════════

    private fun hasCameraPermission() =
        ContextCompat.checkSelfPermission(this, PERM_CAMERA) == PackageManager.PERMISSION_GRANTED

    private fun checkCameraPermission() {
        if (!hasCameraPermission()) {
            ActivityCompat.requestPermissions(this, arrayOf(PERM_CAMERA), REQ_CAMERA)
        }
        // Camera opened in onResume
    }

    override fun onRequestPermissionsResult(
        requestCode: Int,
        permissions: Array<String>,
        grantResults: IntArray
    ) {
        super.onRequestPermissionsResult(requestCode, permissions, grantResults)
        if (requestCode == REQ_CAMERA &&
            grantResults.isNotEmpty() &&
            grantResults[0] == PackageManager.PERMISSION_GRANTED) {
            openCamera()
        } else {
            tvStatus.text = "Camera permission denied"
        }
    }
}

// ══════════════════════════════════════════════════════════════════════════════
//  ROI overlay view (drawn on top of the TextureView)
// ══════════════════════════════════════════════════════════════════════════════

class RoiOverlayView @JvmOverloads constructor(
    context: android.content.Context,
    attrs: android.util.AttributeSet? = null,
    defStyle: Int = 0
) : View(context, attrs, defStyle) {

    private var cx = 0.5f; private var cy = 0.5f
    private var hw = 0.18f; private var hh = 0.22f

    private val borderPaint = Paint().apply {
        color = Color.YELLOW
        strokeWidth = 3f
        style = Paint.Style.STROKE
        pathEffect = DashPathEffect(floatArrayOf(16f, 8f), 0f)
    }
    private val dimPaint = Paint().apply {
        color = Color.parseColor("#66000000")
        style = Paint.Style.FILL
    }
    private val labelPaint = Paint().apply {
        color = Color.YELLOW
        textSize = 28f
        isAntiAlias = true
    }
    private val crossPaint = Paint().apply {
        color = Color.parseColor("#AAFFFF")
        strokeWidth = 1.5f
        style = Paint.Style.STROKE
    }

    fun setROI(cx: Float, cy: Float, hw: Float, hh: Float) {
        this.cx = cx; this.cy = cy; this.hw = hw; this.hh = hh
        invalidate()
    }

    override fun onDraw(canvas: Canvas) {
        val W = width.toFloat(); val H = height.toFloat()
        val l = (cx - hw) * W; val t = (cy - hh) * H
        val r = (cx + hw) * W; val b = (cy + hh) * H

        // Dim region outside ROI
        canvas.drawRect(0f, 0f, W, t, dimPaint)
        canvas.drawRect(0f, b, W, H, dimPaint)
        canvas.drawRect(0f, t, l, b, dimPaint)
        canvas.drawRect(r, t, W, b, dimPaint)

        // ROI border
        canvas.drawRect(l, t, r, b, borderPaint)

        // Crosshairs
        canvas.drawLine(cx * W - 20, cy * H, cx * W + 20, cy * H, crossPaint)
        canvas.drawLine(cx * W, cy * H - 20, cx * W, cy * H + 20, crossPaint)

        // Label
        canvas.drawText("ROI — drag to move", l + 8f, t - 8f, labelPaint)
    }
}
