package com.seeingmeter

import android.Manifest
import android.content.pm.PackageManager
import android.graphics.*
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.util.AttributeSet
import android.view.*
import android.widget.*
import androidx.appcompat.app.AlertDialog
import androidx.appcompat.app.AppCompatActivity
import androidx.core.app.ActivityCompat
import androidx.core.content.ContextCompat

class MainActivity : AppCompatActivity() {

    companion object {
        private const val PERM_CAMERA      = Manifest.permission.CAMERA
        private const val REQ_CAMERA       = 1001
        private const val ANALYSIS_MS      = 2000L
        private const val AE_LOCK_DELAY_MS = 5000L
    }

    // Views
    private lateinit var textureView:  TextureView
    private lateinit var roiOverlay:   RoiOverlayView
    private lateinit var tvR0:         TextView
    private lateinit var tvSeeing:     TextView
    private lateinit var tvSigma:      TextView
    private lateinit var tvFreq:       TextView
    private lateinit var tvSampleRate: TextView
    private lateinit var tvStatus:     TextView
    private lateinit var tvExposure:   TextView
    private lateinit var btnMeasure:   Button
    private lateinit var spectrumView: SpectrumView

    private lateinit var analyzer:         SeeingAnalyzer
    private lateinit var cameraController: CameraController

    private val mainHandler = Handler(Looper.getMainLooper())
    private var isMeasuring = false

    // ROI centre in normalised [0,1] coords
    private var roiCx = 0.5f; private var roiCy = 0.5f
    private val roiHW = 0.20f; private val roiHH = 0.25f

    // ── Lifecycle ──────────────────────────────────────────────────────────────

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        window.addFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON)
        setContentView(R.layout.activity_main)
        bindViews()

        analyzer = SeeingAnalyzer()
        cameraController = CameraController(this, analyzer) { skewNs, expNs, iso ->
            mainHandler.post { updateExposureDisplay(skewNs, expNs, iso) }
        }

        setupButtons()
        showSolarWarning()
    }

    override fun onResume() {
        super.onResume()
        if (hasCameraPermission()) startCameraIfReady()
    }

    override fun onPause() {
        super.onPause()
        stopMeasurement()
        mainHandler.removeCallbacksAndMessages(null)
        cameraController.detach()
        cameraController.stopBackgroundThread()
    }

    // ── Camera start ───────────────────────────────────────────────────────────

    private fun startCameraIfReady() {
        cameraController.startBackgroundThread()
        // attachTextureView handles "is surface ready?" internally
        cameraController.attachTextureView(textureView)
        updateROI()
    }

    // ── Buttons & touch ────────────────────────────────────────────────────────

    private fun setupButtons() {
        findViewById<Button>(R.id.btnMeasure).also { btnMeasure = it }.setOnClickListener {
            if (!isMeasuring) startMeasurement() else stopMeasurement()
        }
        findViewById<Button>(R.id.btnSettings).setOnClickListener { showSettings() }
        findViewById<Button>(R.id.btnReset).setOnClickListener {
            analyzer.reset()
            spectrumView.updateSpectrum(DoubleArray(0), DoubleArray(0), Double.NaN, Double.NaN)
            tvStatus.text = "Reset — point at solar disk and press Measure"
        }
        textureView.setOnTouchListener { _, ev ->
            if (ev.action == MotionEvent.ACTION_DOWN || ev.action == MotionEvent.ACTION_MOVE) {
                roiCx = (ev.x / textureView.width).coerceIn(roiHW, 1f - roiHW)
                roiCy = (ev.y / textureView.height).coerceIn(roiHH, 1f - roiHH)
                updateROI()
            }
            true
        }
    }

    private fun updateROI() {
        val l = ((roiCx - roiHW) * CameraController.ANALYSIS_W).toInt()
        val t = ((roiCy - roiHH) * CameraController.ANALYSIS_H).toInt()
        val r = ((roiCx + roiHW) * CameraController.ANALYSIS_W).toInt()
        val b = ((roiCy + roiHH) * CameraController.ANALYSIS_H).toInt()
        cameraController.setROI(l, t, r, b)
        roiOverlay.setROI(roiCx, roiCy, roiHW, roiHH)
    }

    // ── Measurement ────────────────────────────────────────────────────────────

    private fun startMeasurement() {
        isMeasuring = true
        analyzer.reset()
        btnMeasure.text = "■  Stop"
        btnMeasure.setBackgroundColor(Color.parseColor("#CC2222"))
        tvStatus.text = "Auto-exposing…  hold phone steady"
        mainHandler.postDelayed(analysisLoop, ANALYSIS_MS)
    }

    private fun stopMeasurement() {
        isMeasuring = false
        mainHandler.removeCallbacks(analysisLoop)
        btnMeasure.text = "▶  Measure"
        btnMeasure.setBackgroundColor(Color.parseColor("#1B5E20"))
        tvStatus.text = "Stopped"
    }

    private val analysisLoop = object : Runnable {
        override fun run() {
            if (!isMeasuring) return
            updateResults()
            mainHandler.postDelayed(this, ANALYSIS_MS)
        }
    }

    // ── Results ────────────────────────────────────────────────────────────────

    private fun updateResults() {
        val res = analyzer.analyze()
        if (res == null) {
            val frames = analyzer.framesProcessed
            tvStatus.text = if (frames == 0)
                "Waiting for camera frames…  (is camera running?)"
            else
                "Collecting… $frames frames buffered"
            return
        }

        tvR0.text = if (res.r0Cm.isNaN()) "r₀ = —"
                    else "r₀ = %.1f cm  [%s]".format(res.r0Cm, res.qualityLabel)
        tvSeeing.text = if (res.seeingArcsec.isNaN()) "Seeing = —"
                        else "Seeing = %.2f\"".format(res.seeingArcsec)
        tvSigma.text = "σ_I = %.4f  (scintillation index)".format(res.scintillationSigma)

        val fc = if (res.characteristicFreqHz.isFinite()) "%.0f Hz".format(res.characteristicFreqHz) else "—"
        val ff = if (res.fresnelFreqHz.isFinite()) "%.0f Hz".format(res.fresnelFreqHz) else "—"
        tvFreq.text = "f_char=$fc  |  f_Fresnel=$ff"

        tvSampleRate.text = "%.0f kHz · Δt=%.1f µs · %d frames".format(
            res.sampleRateHz / 1000.0, res.rowPeriodUs, res.framesProcessed)
        tvStatus.text = "Measuring · z=%.1f° · %d samples%s".format(
            res.zenithAngleDeg, res.nSamples,
            if (!res.isReliable) "  ⚠ check exposure" else "")

        spectrumView.updateSpectrum(res.freqs, res.psd,
            res.characteristicFreqHz, res.fresnelFreqHz)
    }

    private fun updateExposureDisplay(skewNs: Long, expNs: Long, iso: Int) {
        val expMs  = expNs  / 1_000_000.0
        val skewMs = skewNs / 1_000_000.0
        val kHz    = if (skewMs > 0) CameraController.ANALYSIS_H / (skewMs / 1000.0) / 1000.0 else 0.0
        tvExposure.text = "Exp %.2f ms · ISO %d · RS %.1f ms · ~%.0f kHz".format(
            expMs, iso, skewMs, kHz)
    }

    // ── Settings dialog ────────────────────────────────────────────────────────

    private fun showSettings() {
        val v = layoutInflater.inflate(R.layout.dialog_settings, null)
        val etZ = v.findViewById<EditText>(R.id.etZenith)
        val etH = v.findViewById<EditText>(R.id.etHeight)
        val etW = v.findViewById<EditText>(R.id.etWind)
        val etL = v.findViewById<EditText>(R.id.etLambda)
        etZ.setText("%.1f".format(analyzer.zenithAngleDeg))
        etH.setText("%.1f".format(analyzer.turbulenceHeightM / 1000.0))
        etW.setText("%.1f".format(analyzer.windSpeedMs))
        etL.setText("%.0f".format(analyzer.wavelengthNm))
        AlertDialog.Builder(this, android.R.style.Theme_Material_Dialog_Alert)
            .setTitle("Measurement Parameters")
            .setView(v)
            .setPositiveButton("Apply") { _, _ ->
                etZ.text.toString().toDoubleOrNull()?.let { analyzer.zenithAngleDeg     = it.coerceIn(0.0, 85.0) }
                etH.text.toString().toDoubleOrNull()?.let { analyzer.turbulenceHeightM  = (it * 1000).coerceIn(500.0, 20000.0) }
                etW.text.toString().toDoubleOrNull()?.let { analyzer.windSpeedMs        = it.coerceIn(0.5, 50.0) }
                etL.text.toString().toDoubleOrNull()?.let { analyzer.wavelengthNm       = it.coerceIn(400.0, 700.0) }
            }
            .setNegativeButton("Cancel", null).show()
    }

    // ── Solar warning ──────────────────────────────────────────────────────────

    private fun showSolarWarning() {
        AlertDialog.Builder(this, android.R.style.Theme_Material_Dialog_Alert)
            .setTitle("☀  SOLAR SAFETY")
            .setMessage(
                "WARNING: Without a proper solar filter the camera sensor will be " +
                "PERMANENTLY DAMAGED.\n\n" +
                "Required: Baader AstroSolar ND 5.0 film or equivalent, " +
                "covering the entire rear camera module.\n\n" +
                "Usage:\n" +
                "1. Attach solar filter over ALL rear lenses\n" +
                "2. Point at the Sun — disk should appear dim grey\n" +
                "3. Drag the yellow ROI box onto the solar disk\n" +
                "4. Tap MEASURE and hold steady for 15–30 s"
            )
            .setPositiveButton("I have a solar filter") { _, _ ->
                if (!hasCameraPermission())
                    ActivityCompat.requestPermissions(this, arrayOf(PERM_CAMERA), REQ_CAMERA)
                // If permission already granted, camera started in onResume
            }
            .setNegativeButton("Exit") { _, _ -> finish() }
            .setCancelable(false).show()
    }

    // ── Permissions ────────────────────────────────────────────────────────────

    private fun hasCameraPermission() =
        ContextCompat.checkSelfPermission(this, PERM_CAMERA) == PackageManager.PERMISSION_GRANTED

    override fun onRequestPermissionsResult(
        requestCode: Int, permissions: Array<String>, grantResults: IntArray
    ) {
        super.onRequestPermissionsResult(requestCode, permissions, grantResults)
        if (requestCode == REQ_CAMERA &&
            grantResults.isNotEmpty() &&
            grantResults[0] == PackageManager.PERMISSION_GRANTED) {
            startCameraIfReady()
        } else {
            tvStatus.text = "Camera permission denied"
        }
    }

    // ── View binding (safe: after setContentView) ──────────────────────────────

    private fun bindViews() {
        textureView  = findViewById(R.id.textureView)
        roiOverlay   = findViewById(R.id.roiOverlay)
        tvR0         = findViewById(R.id.tvR0)
        tvSeeing     = findViewById(R.id.tvSeeing)
        tvSigma      = findViewById(R.id.tvSigma)
        tvFreq       = findViewById(R.id.tvFreq)
        tvSampleRate = findViewById(R.id.tvSampleRate)
        tvStatus     = findViewById(R.id.tvStatus)
        tvExposure   = findViewById(R.id.tvExposure)
        btnMeasure   = findViewById(R.id.btnMeasure)
        spectrumView = findViewById(R.id.spectrumView)
    }
}

// ── ROI overlay ────────────────────────────────────────────────────────────────

class RoiOverlayView @JvmOverloads constructor(
    context: android.content.Context, attrs: AttributeSet? = null, defStyle: Int = 0
) : View(context, attrs, defStyle) {

    private var cx = 0.5f; private var cy = 0.5f
    private var hw = 0.20f; private var hh = 0.25f

    private val border = Paint().apply {
        color = Color.YELLOW; strokeWidth = 3f; style = Paint.Style.STROKE
        pathEffect = android.graphics.DashPathEffect(floatArrayOf(16f, 8f), 0f)
    }
    private val dim = Paint().apply { color = Color.parseColor("#55000000"); style = Paint.Style.FILL }
    private val label = Paint().apply { color = Color.YELLOW; textSize = 28f; isAntiAlias = true }
    private val cross = Paint().apply { color = Color.parseColor("#AAFFFF"); strokeWidth = 2f; style = Paint.Style.STROKE }

    fun setROI(cx: Float, cy: Float, hw: Float, hh: Float) {
        this.cx = cx; this.cy = cy; this.hw = hw; this.hh = hh; invalidate()
    }

    override fun onDraw(canvas: Canvas) {
        val W = width.toFloat(); val H = height.toFloat()
        val l = (cx - hw) * W; val t = (cy - hh) * H
        val r = (cx + hw) * W; val b = (cy + hh) * H
        canvas.drawRect(0f, 0f, W, t, dim)
        canvas.drawRect(0f, b, W, H, dim)
        canvas.drawRect(0f, t, l, b, dim)
        canvas.drawRect(r, t, W, b, dim)
        canvas.drawRect(l, t, r, b, border)
        canvas.drawLine(cx * W - 20, cy * H, cx * W + 20, cy * H, cross)
        canvas.drawLine(cx * W, cy * H - 20, cx * W, cy * H + 20, cross)
        canvas.drawText("ROI — drag to move", l + 8f, (t - 8f).coerceAtLeast(20f), label)
    }
}
