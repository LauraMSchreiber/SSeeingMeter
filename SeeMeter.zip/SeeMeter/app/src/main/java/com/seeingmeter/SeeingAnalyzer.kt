package com.seeingmeter

import kotlin.math.*

/**
 * Atmospheric Seeing Analyzer — Rolling-Shutter Scintillometry
 * ============================================================
 *
 * TWO MEASUREMENT MODES
 * ─────────────────────
 *
 * ① SOLAR_SCINTILLOMETER  (recommended — use with paper diffuser)
 *   ┌─────────────────────────────────────────────────────────────┐
 *   │  Place a white paper diffuser over the camera lens.        │
 *   │  The camera now measures the TOTAL INTEGRATED FLUX         │
 *   │  through the aperture — identical geometry to a Seykora    │
 *   │  (1993) solar scintillometer / single photodiode.          │
 *   └─────────────────────────────────────────────────────────────┘
 *   Formula (derived from Roddier 1981 for extended source, D ≪ r_F):
 *
 *     σ²_I = COEFF_SOL · k^(-5/6) · sec(z)^(5/6) · H^(-1/6) · λ · r₀^(-5/3) / α_s²
 *
 *   where
 *     COEFF_SOL = (2Q/π) · COEFF_STELLAR ≈ 4.29
 *     Q         = ∫₀^∞ B(ρ) ρ dρ ≈ 1.27  (normalised Kolmogorov log-amplitude covariance)
 *     α_s       = solar angular radius   [radians]
 *     H         = effective turbulence height
 *
 *   Key property: H^(-1/6) gives OPPOSITE height sensitivity to the stellar formula
 *   (H^+5/6)). The solar scintillometer is most sensitive to LOW-ALTITUDE turbulence,
 *   making it ideal for monitoring boundary-layer dominated daytime seeing.
 *   The H dependence is very weak: 100× change in H → only ~2× change in σ_I.
 *
 *   References:
 *     Seykora, E.J. (1993) Solar Physics 145, 389–397
 *     Beckers, J.M. (2009) Optical Turbulence, pp. 23–25
 *     Coulter, Kuhn & Rimmele (1996) Solar Physics 163, 7–19
 *     Roddier, F. (1981) Prog. Optics XIX, 281–376
 *
 * ② IMAGING_WITH_CORRECTION  (use without diffuser, imaging the solar disk)
 *   Uses the stellar scintillation formula (Roddier 1981) with correction factors
 *   to account for PSF averaging (N_PSF) and solar disk pixel averaging (N_disk).
 *   Less well-calibrated than ①; correction factors depend on camera geometry.
 *
 * ROLLING SHUTTER TIME BASE
 * ─────────────────────────
 *   Row r of the sensor is exposed at  t_r = t_0 + r · Δt
 *   Δt = SENSOR_ROLLING_SHUTTER_SKEW / (N_rows − 1)   [nanoseconds per row]
 *   Typical S25 Ultra at 1080p: Δt ≈ 14 µs → f_sample ≈ 70 kHz
 */
class SeeingAnalyzer(
    var wavelengthNm:          Double = 550.0,
    var turbulenceHeightM:     Double = 1_000.0,   // default 1 km for solar (boundary layer)
    var windSpeedMs:           Double = 10.0,
    var zenithAngleDeg:        Double = 45.0,
    var mode:                  Mode   = Mode.SOLAR_SCINTILLOMETER,

    // ── Solar scintillometer parameters (Mode ①) ──
    /** Solar angular radius in arcseconds. Mean value 960"; range 944"–976" over year. */
    var sunAngularRadiusArcsec: Double = 960.0,
    /** Empirical calibration factor (default 1.0). Adjust if DIMM comparison available. */
    var solarCalibration:       Double = 1.0,

    // ── Imaging-with-correction parameters (Mode ②) ──
    /** Camera lens entrance-pupil diameter in mm. S25 Ultra main: f=6.7mm/f1.7 ≈ 4 mm */
    var lensDiameterMm:         Double = 4.0,
    /** Solar disk width in analysis-frame pixels. S25 Ultra 1920×1080: ≈ 12 pixels */
    var solarDiskPixels:        Int    = 12
) {
    // ─────────────────────────────────────────────────────────────────────────────
    companion object {
        const val TAG              = "SeeingAnalyzer"
        const val COEFF_STELLAR    = 5.324   // 4 × (0.563/0.423)
        /** Seykora/Roddier coefficient for solar scintillometer.
         *  COEFF_SOL = (2·Q/π) · COEFF_STELLAR where Q ≈ 1.27 from Kolmogorov theory. */
        const val COEFF_SOLAR      = 4.290
        const val MAX_BUFFER       = 131_072
        const val MIN_SAMPLES      = 512
    }

    enum class Mode {
        /** Paper diffuser over lens → total-flux solar scintillometer (Seykora 1993). */
        SOLAR_SCINTILLOMETER,
        /** Direct imaging of solar disk → stellar formula + PSF/disk correction. */
        IMAGING_WITH_CORRECTION
    }

    // ── Ring buffer ───────────────────────────────────────────────────────────────
    private val intensityBuf = ArrayDeque<Double>(MAX_BUFFER)

    // ── Camera metadata ───────────────────────────────────────────────────────────
    @Volatile var rollingShutterSkewNs: Long  = 10_000_000L
    @Volatile var streamHeight:         Int   = 1080
    @Volatile var sampleRateHz:         Double = 0.0

    var framesProcessed: Int = 0; private set

    // ── PSD accumulator ───────────────────────────────────────────────────────────
    private var _psdAccum  = DoubleArray(0)
    private var psdFreqs   = DoubleArray(0)
    private var psdCount   = 0

    var result: AnalysisResult? = null; private set

    // ─────────────────────────────────────────────────────────────────────────────
    // Frame ingestion
    // ─────────────────────────────────────────────────────────────────────────────

    fun addFrame(rowMeans: DoubleArray, rollingSkewNs: Long) {
        val nRows = rowMeans.size
        if (nRows < 2) return
        rollingShutterSkewNs = rollingSkewNs
        streamHeight         = nRows
        val dtNs = rollingSkewNs.toDouble() / (nRows - 1)
        sampleRateHz = if (dtNs > 0) 1e9 / dtNs else 0.0

        synchronized(this) {
            val frameMean = rowMeans.average()
            if (frameMean <= 0.0) return
            for (v in rowMeans) {
                if (intensityBuf.size >= MAX_BUFFER) intensityBuf.removeFirst()
                intensityBuf.addLast(v / frameMean)
            }
            if (sampleRateHz > 0) addFrameSpectrum(rowMeans, frameMean)
        }
        framesProcessed++
    }

    private fun addFrameSpectrum(rowMeans: DoubleArray, frameMean: Double) {
        val segLen = FFTUtils.nextPow2(rowMeans.size).coerceAtMost(1024)
        val nFreqs = segLen / 2 + 1
        if (_psdAccum.size != nFreqs) {
            _psdAccum = DoubleArray(nFreqs)
            psdFreqs  = DoubleArray(nFreqs) { it * sampleRateHz / segLen }
            psdCount  = 0
        }
        val s = linearDetrend(DoubleArray(rowMeans.size) { rowMeans[it] / frameMean - 1.0 })
        val window = DoubleArray(segLen) { 0.5 * (1.0 - cos(2.0 * PI * it / (segLen - 1))) }
        val winPow = window.sumOf { it * it }
        val re = DoubleArray(segLen) { if (it < s.size) s[it] * window[it] else 0.0 }
        val im = DoubleArray(segLen)
        FFTUtils.fft(re, im)
        for (k in 0 until nFreqs) {
            val p = (re[k]*re[k] + im[k]*im[k]) / (sampleRateHz * winPow)
            _psdAccum[k] += if (k == 0 || k == segLen/2) p else 2.0 * p
        }
        psdCount++
    }

    // ─────────────────────────────────────────────────────────────────────────────
    // Analysis
    // ─────────────────────────────────────────────────────────────────────────────

    fun analyze(): AnalysisResult? {
        val samples: DoubleArray
        val fs: Double
        synchronized(this) {
            if (intensityBuf.size < MIN_SAMPLES || sampleRateHz <= 0) return null
            samples = intensityBuf.toDoubleArray()
            fs = sampleRateHz
        }

        val meanI = samples.average()
        if (meanI <= 0.0) return null

        // Detrend and normalise
        val detrended  = linearDetrend(DoubleArray(samples.size) { samples[it] - meanI })
        val normalised = DoubleArray(detrended.size) { detrended[it] / meanI }
        val varianceI  = normalised.sumOf { it * it } / normalised.size
        val sigmaI     = sqrt(varianceI)

        // Power spectral density
        val (freqs, psd) = if (psdCount > 0)
            Pair(psdFreqs, DoubleArray(_psdAccum.size) { _psdAccum[it] / psdCount })
        else {
            val seg = FFTUtils.nextPow2(samples.size / 4).coerceAtMost(1024)
            FFTUtils.welchPSD(normalised, fs, seg, 0.5)
        }
        if (freqs.isEmpty()) return null

        // Spectral fit
        val fcFit = FFTUtils.fitKolmogorovFrequency(freqs, psd, 30.0)
        val lambdaM = wavelengthNm * 1e-9
        val fresnelFreqHz = windSpeedMs / sqrt(lambdaM * turbulenceHeightM)

        // H from spectral fit (self-consistency check)
        val hFromFitM = if (fcFit.isFinite() && fcFit > 0 && windSpeedMs > 0)
            (windSpeedMs / fcFit).pow(2.0) / lambdaM else Double.NaN

        val zenithRad = zenithAngleDeg * PI / 180.0

        // ── Compute r₀ using selected mode ─────────────────────────────────────
        val r0m = when (mode) {
            Mode.SOLAR_SCINTILLOMETER    -> computeR0Solar(varianceI, zenithRad)
            Mode.IMAGING_WITH_CORRECTION -> computeR0Imaging(varianceI, zenithRad)
        }
        val r0cm         = if (r0m.isNaN()) Double.NaN else r0m * 100.0
        val seeingArcsec = if (r0m.isNaN() || r0m <= 0) Double.NaN
                           else 0.976 * lambdaM / r0m * 206_265.0

        result = AnalysisResult(
            r0Cm                 = r0cm,
            seeingArcsec         = seeingArcsec,
            scintillationSigma   = sigmaI,
            scintillationVar     = varianceI,
            characteristicFreqHz = fcFit,
            fresnelFreqHz        = fresnelFreqHz,
            hFromSpectralFitKm   = if (hFromFitM.isNaN()) Double.NaN else hFromFitM / 1000.0,
            freqs                = freqs,
            psd                  = psd,
            nSamples             = samples.size,
            sampleRateHz         = fs,
            rowPeriodUs          = 1e6 / fs,
            framesProcessed      = framesProcessed,
            mode                 = mode,
            wavelengthNm         = wavelengthNm,
            turbulenceHeightKm   = turbulenceHeightM / 1000.0,
            windSpeedMs          = windSpeedMs,
            zenithAngleDeg       = zenithAngleDeg,
            sunAngularRadiusArcsec = sunAngularRadiusArcsec,
            lensDiameterMm       = lensDiameterMm,
            solarDiskPixels      = solarDiskPixels
        )
        return result
    }

    // ─────────────────────────────────────────────────────────────────────────────
    // Mode ①: Solar scintillometer formula  (Seykora 1993 / Roddier 1981)
    // ─────────────────────────────────────────────────────────────────────────────

    /**
     * Derive r₀ using the extended-source scintillometer formula.
     *
     * Valid when:
     *   D ≪ r_F = √(λH)          [small aperture: 4 mm ≪ 52 mm for H=5 km  ✓]
     *   α_s ≫ θ_F = √(λ/H)       [large source:   960" ≫ 2.2" for H=5 km  ✓]
     *
     * σ²_I = COEFF_SOL · k^(-5/6) · sec(z)^(5/6) · H^(-1/6) · λ / α_s² · r₀^(-5/3)
     *
     * H^(-1/6) gives the characteristic OPPOSITE height weighting compared to the
     * stellar formula — the solar scintillometer is most sensitive to the boundary
     * layer, ideal for daytime site monitoring.
     *
     * COEFF_SOL ≈ 4.29 derived theoretically; empirical calibration recommended.
     */
    private fun computeR0Solar(varianceI: Double, zenithRad: Double): Double {
        if (varianceI <= 0.0) return Double.NaN
        val lambdaM  = wavelengthNm * 1e-9
        val k        = 2.0 * PI / lambdaM
        val secZ     = 1.0 / cos(zenithRad)
        val H        = turbulenceHeightM
        val alphaSRad = sunAngularRadiusArcsec * PI / (180.0 * 3600.0)

        val numer = COEFF_SOLAR * solarCalibration *
                    k.pow(-5.0/6.0) *
                    secZ.pow(5.0/6.0) *
                    H.pow(-1.0/6.0) *          // <── KEY DIFFERENCE from stellar formula
                    lambdaM /
                    (alphaSRad * alphaSRad)

        return (numer / varianceI).pow(3.0 / 5.0)
    }

    // ─────────────────────────────────────────────────────────────────────────────
    // Mode ②: Stellar formula with PSF/disk correction
    // ─────────────────────────────────────────────────────────────────────────────

    /**
     * Derive r₀ using the stellar scintillation formula (Roddier 1981) with
     * correction for PSF averaging (N_PSF) and solar disk pixel averaging (N_disk).
     *
     * N_PSF  = number of independent scintillation cells in the Airy disc
     *        = (1.22 λ/D)² / (λ/H)  = 1.488 · λ · H / D²
     *
     * N_disk = number of solar-disk pixels per row (independently scintillating
     *          for θ_F ≪ pixel scale)
     *
     * σ²_I_effective = σ²_I_measured · N_PSF · N_disk  (recovers stellar equivalent)
     */
    private fun computeR0Imaging(varianceI: Double, zenithRad: Double): Double {
        if (varianceI <= 0.0) return Double.NaN
        val lambdaM = wavelengthNm * 1e-9
        val k       = 2.0 * PI / lambdaM
        val secZ    = 1.0 / cos(zenithRad)
        val H       = turbulenceHeightM
        val D_m     = lensDiameterMm * 1e-3
        val nPSF    = 1.488 * lambdaM * H / (D_m * D_m)
        val nDisk   = solarDiskPixels.toDouble().coerceAtLeast(1.0)

        val varianceCorrected = varianceI * nPSF * nDisk
        val numer = COEFF_STELLAR * k.pow(-5.0/6.0) * secZ.pow(5.0/6.0) * H.pow(5.0/6.0)
        return (numer / varianceCorrected).pow(3.0 / 5.0)
    }

    // ─────────────────────────────────────────────────────────────────────────────
    // Helpers
    // ─────────────────────────────────────────────────────────────────────────────

    private fun linearDetrend(data: DoubleArray): DoubleArray {
        val n = data.size; if (n < 2) return data
        val xm = (n-1)/2.0; val ym = data.average()
        var ssXX = 0.0; var ssXY = 0.0
        for (i in data.indices) { val dx = i - xm; ssXX += dx*dx; ssXY += dx*(data[i]-ym) }
        val slope = if (ssXX > 0) ssXY/ssXX else 0.0
        return DoubleArray(n) { i -> data[i] - (ym + slope*(i-xm)) }
    }

    fun reset() {
        synchronized(this) {
            intensityBuf.clear()
            _psdAccum = DoubleArray(0); psdFreqs = DoubleArray(0); psdCount = 0
        }
        framesProcessed = 0; result = null
    }

    // ─────────────────────────────────────────────────────────────────────────────
    // Result data class
    // ─────────────────────────────────────────────────────────────────────────────

    data class AnalysisResult(
        val r0Cm: Double,
        val seeingArcsec: Double,
        val scintillationSigma: Double,
        val scintillationVar: Double,
        val characteristicFreqHz: Double,
        val fresnelFreqHz: Double,
        /** H inferred from fitted f_c and wind speed (km). For consistency check. */
        val hFromSpectralFitKm: Double,
        val freqs: DoubleArray,
        val psd: DoubleArray,
        val nSamples: Int,
        val sampleRateHz: Double,
        val rowPeriodUs: Double,
        val framesProcessed: Int,
        val mode: SeeingAnalyzer.Mode,
        val wavelengthNm: Double,
        val turbulenceHeightKm: Double,
        val windSpeedMs: Double,
        val zenithAngleDeg: Double,
        val sunAngularRadiusArcsec: Double,
        val lensDiameterMm: Double,
        val solarDiskPixels: Int
    ) {
        val qualityLabel: String get() = when {
            r0Cm.isNaN()  -> "—"
            r0Cm >= 20.0  -> "Excellent"
            r0Cm >= 12.0  -> "Good"
            r0Cm >= 7.0   -> "Average"
            r0Cm >= 4.0   -> "Poor"
            else          -> "Very Poor"
        }
        val modeLabel: String get() = when (mode) {
            Mode.SOLAR_SCINTILLOMETER    -> "Seykora"
            Mode.IMAGING_WITH_CORRECTION -> "Imaging+corr"
        }
        val isReliable: Boolean get() = !r0Cm.isNaN() && scintillationVar > 0.0
    }
}
