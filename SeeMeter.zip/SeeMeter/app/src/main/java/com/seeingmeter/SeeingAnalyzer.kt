package com.seeingmeter

import kotlin.math.*

/**
 * Atmospheric Seeing Analyzer — Rolling-Shutter Scintillometry
 * ============================================================
 *
 * PHYSICS BACKGROUND
 * ------------------
 * The camera reads each row of the sensor at a slightly later time.
 * Android Camera2 exposes `SENSOR_ROLLING_SHUTTER_SKEW` (ns), the total
 * time elapsed between the exposure start of row 0 and row (height−1).
 * Row time step:  Δt = SENSOR_ROLLING_SHUTTER_SKEW / (height − 1)
 * Sample rate:    fs  = 1 / Δt   ≈ 50 000 – 200 000 Hz  (phone cameras)
 *
 * By averaging pixel values across the selected columns for each row we
 * obtain a high-rate intensity time series  I(t)  from within the solar disk.
 *
 * SCINTILLATION → FRIED RADIUS
 * -----------------------------
 * For weak Kolmogorov turbulence, a point (small) aperture, and a single
 * equivalent turbulent layer at height H (Roddier 1981):
 *
 *   σ²_I  =  5.324 · k^(−5/6) · sec(z)^(5/6) · H^(5/6) · r₀^(−5/3)
 *
 * where
 *   σ²_I = Var[δI/⟨I⟩]         (normalised intensity variance)
 *   k    = 2π/λ                  (optical wavenumber, m⁻¹)
 *   z    = solar zenith angle
 *   H    = effective turbulence height  (user-configurable, default 5 km)
 *   r₀   = Fried coherence radius       (quality of seeing; bigger = better)
 *
 * Derivation summary:
 *   From Roddier (1981):
 *     σ²_χ = 0.563 k^(7/6) sec^(11/6)(z) ∫ C²n h^(5/6) dh
 *     r₀   = [0.423 k² sec(z) ∫ C²n dh]^(−3/5)
 *   Substituting ∫ C²n dh = r₀^(−5/3) / (0.423 k² sec z) into σ²_χ
 *   and using σ²_I = 4 σ²_χ (weak scintillation):
 *     σ²_I = (4 × 0.563/0.423) k^(−5/6) sec^(5/6)(z) H^(5/6) r₀^(−5/3)
 *           ≈ 5.324 k^(−5/6) sec^(5/6)(z) H^(5/6) r₀^(−5/3)
 *
 * The Fresnel (rolloff) frequency of the PSD:
 *   f_c = v_wind / √(λ · H)
 *
 * Atmospheric seeing full-width at half-maximum:
 *   ε = 0.976 λ / r₀   [radians → arcseconds via × 206 265]
 *
 * NOTE ON APERTURE:  A smartphone lens has entrance pupil D ≈ 1–3 mm.
 * The Fresnel scale r_F = √(λH) ≈ 50 mm (λ=550 nm, H=5 km).
 * Since D ≪ r_F the point-aperture formula is valid and aperture
 * averaging is negligible.  Consequently σ_I can reach 20–70 % —
 * much larger than for a telescope but perfectly measurable.
 */
class SeeingAnalyzer(
    /** Wavelength in nm (default 550 nm — green peak of solar spectrum). */
    var wavelengthNm: Double = 550.0,
    /** Effective turbulence height in metres (default 5 km, lower atmosphere). */
    var turbulenceHeightM: Double = 5_000.0,
    /** Wind speed at turbulence layer in m/s (for Fresnel frequency estimation). */
    var windSpeedMs: Double = 10.0,
    /** Solar zenith angle in degrees. */
    var zenithAngleDeg: Double = 45.0
) {
    companion object {
        const val TAG = "SeeingAnalyzer"

        /** Combined constant: 4 × (0.563/0.423) */
        const val COEFF_SCINT = 5.324

        /** Maximum number of row-samples held in the ring buffer (≈ 2^17). */
        const val MAX_BUFFER = 131_072

        /** Minimum samples needed before attempting an analysis. */
        const val MIN_SAMPLES = 512
    }

    // ── Ring buffer ────────────────────────────────────────────────────────────
    private val intensityBuf = ArrayDeque<Double>(MAX_BUFFER)

    // ── Camera metadata ────────────────────────────────────────────────────────
    /** Sensor rolling-shutter skew in nanoseconds (from Camera2 capture result). */
    @Volatile var rollingShutterSkewNs: Long = 10_000_000L   // 10 ms default
    /** Image height in pixels for the current stream. */
    @Volatile var streamHeight: Int = 1080

    /** Computed sample rate (Hz) from the last processed frame. */
    @Volatile var sampleRateHz: Double = 0.0

    // ── Counters / results ─────────────────────────────────────────────────────
    var framesProcessed: Int = 0; private set

    // Per-spectrum accumulator (Welch across frames)
    private val psdAccum: DoubleArray get() = _psdAccum
    private var _psdAccum = DoubleArray(0)
    private var psdCount = 0
    private var psdFreqs = DoubleArray(0)

    // Published results (updated each call to analyze())
    var result: AnalysisResult? = null; private set

    // ── Frame ingestion ────────────────────────────────────────────────────────

    /**
     * Add one frame's row-intensity data.
     *
     * @param rowMeans        Array of length = ROI row count; each element is
     *                        the mean Y (luminance) value across the ROI columns.
     * @param rollingSkewNs   SENSOR_ROLLING_SHUTTER_SKEW for this frame (ns).
     */
    fun addFrame(rowMeans: DoubleArray, rollingSkewNs: Long) {
        val nRows = rowMeans.size
        if (nRows < 2) return

        this.rollingShutterSkewNs = rollingSkewNs
        this.streamHeight = nRows

        val dtNs = rollingSkewNs.toDouble() / (nRows - 1).toDouble()
        sampleRateHz = if (dtNs > 0) 1e9 / dtNs else 0.0

        synchronized(this) {
            // Normalise row means by frame mean (removes frame-to-frame exposure drift)
            val frameMean = rowMeans.average()
            if (frameMean <= 0.0) return

            for (v in rowMeans) {
                if (intensityBuf.size >= MAX_BUFFER) intensityBuf.removeFirst()
                intensityBuf.addLast(v / frameMean)   // fractional values ≈ 1.0
            }

            // Per-frame Welch contribution
            if (sampleRateHz > 0) addFrameSpectrum(rowMeans, frameMean)
        }
        framesProcessed++
    }

    /** Add this frame's periodogram to the running PSD average. */
    private fun addFrameSpectrum(rowMeans: DoubleArray, frameMean: Double) {
        val n = FFTUtils.nextPow2(rowMeans.size)
        val segLen = n.coerceAtMost(1024)   // cap at 1024 for speed
        val nFreqs = segLen / 2 + 1

        if (_psdAccum.size != nFreqs) {
            _psdAccum = DoubleArray(nFreqs)
            psdFreqs  = DoubleArray(nFreqs) { it * sampleRateHz / segLen }
            psdCount  = 0
        }

        // Detrend and normalise
        val s = linearDetrend(DoubleArray(rowMeans.size) { rowMeans[it] / frameMean - 1.0 })

        // Hann window
        val window = DoubleArray(segLen) { 0.5 * (1.0 - cos(2.0 * PI * it / (segLen - 1))) }
        val winPow = window.sumOf { it * it }

        // Take first segLen samples of s
        val re = DoubleArray(segLen) { if (it < s.size) s[it] * window[it] else 0.0 }
        val im = DoubleArray(segLen)
        FFTUtils.fft(re, im)

        for (k in 0 until nFreqs) {
            val p = (re[k]*re[k] + im[k]*im[k]) / (sampleRateHz * winPow)
            _psdAccum[k] += if (k == 0 || k == segLen/2) p else 2.0 * p
        }
        psdCount++
    }

    // ── Analysis ───────────────────────────────────────────────────────────────

    /**
     * Compute all seeing parameters from the accumulated time series.
     * Returns null if insufficient data has been collected.
     */
    fun analyze(): AnalysisResult? {
        val samples: DoubleArray
        val fs: Double
        synchronized(this) {
            if (intensityBuf.size < MIN_SAMPLES || sampleRateHz <= 0) return null
            samples = intensityBuf.toDoubleArray()
            fs = sampleRateHz
        }

        // ── 1. Scintillation index ──────────────────────────────────────────
        val meanI = samples.average()
        if (meanI <= 0.0) return null

        val detrended = linearDetrend(DoubleArray(samples.size) { samples[it] - meanI })
        val normalised = DoubleArray(detrended.size) { detrended[it] / meanI }

        val varianceI = normalised.sumOf { it * it } / normalised.size
        val sigmaI    = sqrt(varianceI)

        // ── 2. Power spectral density ───────────────────────────────────────
        val (freqs, psd) = if (psdCount > 0) {
            Pair(psdFreqs, DoubleArray(_psdAccum.size) { _psdAccum[it] / psdCount })
        } else {
            val segLen = FFTUtils.nextPow2(samples.size / 4).coerceAtMost(1024)
            FFTUtils.welchPSD(normalised, fs, segLen, 0.5)
        }

        if (freqs.isEmpty()) return null

        // ── 3. Characteristic frequency from PSD fit ────────────────────────
        val fcFit = FFTUtils.fitKolmogorovFrequency(freqs, psd, minFreqHz = 30.0)

        // ── 4. Fresnel (theoretical) frequency ─────────────────────────────
        val lambdaM   = wavelengthNm * 1e-9
        val fresnelFreqHz = windSpeedMs / sqrt(lambdaM * turbulenceHeightM)

        // ── 5. Fried radius from scintillation variance ─────────────────────
        val zenithRad = zenithAngleDeg * PI / 180.0
        val r0m       = computeR0(varianceI, zenithRad)
        val r0cm      = if (r0m.isNaN()) Double.NaN else r0m * 100.0

        // ── 6. Seeing angle ─────────────────────────────────────────────────
        val seeingArcsec = if (r0m.isNaN() || r0m <= 0) Double.NaN
                           else 0.976 * lambdaM / r0m * 206_265.0

        // ── 7. Independent r0 estimate from fitted fc ────────────────────────
        //  fc = v / √(λH)  →  H = (v/fc)² / λ  (no direct r0, needs H)
        //  But we can use fc to cross-check the H assumption.
        val hFromFc = if (fcFit.isFinite() && fcFit > 0)
            (windSpeedMs / fcFit).pow(2.0) / lambdaM else Double.NaN

        result = AnalysisResult(
            r0Cm            = r0cm,
            seeingArcsec    = seeingArcsec,
            scintillationSigma = sigmaI,
            scintillationVar   = varianceI,
            characteristicFreqHz = fcFit,
            fresnelFreqHz    = fresnelFreqHz,
            inferredHeightKm = hFromFc / 1000.0,
            freqs            = freqs,
            psd              = psd,
            nSamples         = samples.size,
            sampleRateHz     = fs,
            rowPeriodUs      = 1e6 / fs,
            framesProcessed  = framesProcessed,
            wavelengthNm     = wavelengthNm,
            turbulenceHeightKm = turbulenceHeightM / 1000.0,
            windSpeedMs      = windSpeedMs,
            zenithAngleDeg   = zenithAngleDeg,
            meanIntensity    = meanI * 255.0   // back to raw 0-255 scale
        )
        return result
    }

    // ── r₀ formula ─────────────────────────────────────────────────────────────

    /**
     * Fried radius in metres from normalised intensity variance.
     *
     *   r₀ = [ C · k^(−5/6) · sec(z)^(5/6) · H^(5/6) / σ²_I ]^(3/5)
     *
     * Valid for weak scintillation (σ²_I ≲ 1) and point aperture.
     */
    private fun computeR0(varianceI: Double, zenithRad: Double): Double {
        if (varianceI <= 0.0) return Double.NaN
        val k     = 2.0 * PI / (wavelengthNm * 1e-9)
        val secZ  = 1.0 / cos(zenithRad)
        val H     = turbulenceHeightM
        val numer = COEFF_SCINT * k.pow(-5.0/6.0) * secZ.pow(5.0/6.0) * H.pow(5.0/6.0)
        return (numer / varianceI).pow(3.0 / 5.0)
    }

    // ── Helpers ────────────────────────────────────────────────────────────────

    /** Remove the best-fit linear trend from a data array. */
    private fun linearDetrend(data: DoubleArray): DoubleArray {
        val n = data.size
        if (n < 2) return data
        val xMean = (n - 1) / 2.0
        val yMean = data.average()
        var ssXX = 0.0; var ssXY = 0.0
        for (i in data.indices) {
            val dx = i - xMean
            ssXX += dx * dx
            ssXY += dx * (data[i] - yMean)
        }
        val slope = if (ssXX > 0) ssXY / ssXX else 0.0
        return DoubleArray(n) { i -> data[i] - (yMean + slope * (i - xMean)) }
    }

    /** Reset all accumulated data and results. */
    fun reset() {
        synchronized(this) {
            intensityBuf.clear()
            _psdAccum = DoubleArray(0)
            psdFreqs  = DoubleArray(0)
            psdCount  = 0
        }
        framesProcessed = 0
        result = null
    }

    // ── Result data class ──────────────────────────────────────────────────────

    data class AnalysisResult(
        /** Fried radius in cm (NaN if not available). */
        val r0Cm: Double,
        /** FWHM seeing in arcseconds. */
        val seeingArcsec: Double,
        /** RMS normalised intensity fluctuation  σ_I = √⟨(δI/⟨I⟩)²⟩. */
        val scintillationSigma: Double,
        /** Variance  σ²_I. */
        val scintillationVar: Double,
        /** Fitted Kolmogorov characteristic (Fresnel rolloff) frequency, Hz. */
        val characteristicFreqHz: Double,
        /** Theoretical Fresnel frequency = v/√(λH), Hz. */
        val fresnelFreqHz: Double,
        /** H inferred from fc and wind speed (km); for consistency check. */
        val inferredHeightKm: Double,
        /** Frequency axis for the PSD (Hz). */
        val freqs: DoubleArray,
        /** One-sided PSD values (normalised intensity²/Hz). */
        val psd: DoubleArray,
        val nSamples: Int,
        val sampleRateHz: Double,
        /** Row-to-row time interval in microseconds. */
        val rowPeriodUs: Double,
        val framesProcessed: Int,
        // Measurement parameters (for display / provenance)
        val wavelengthNm: Double,
        val turbulenceHeightKm: Double,
        val windSpeedMs: Double,
        val zenithAngleDeg: Double,
        val meanIntensity: Double
    ) {
        /** Human-readable seeing quality label. */
        val qualityLabel: String get() = when {
            r0Cm.isNaN()  -> "—"
            r0Cm >= 20.0  -> "Excellent"
            r0Cm >= 12.0  -> "Good"
            r0Cm >= 7.0   -> "Average"
            r0Cm >= 4.0   -> "Poor"
            else          -> "Very Poor"
        }

        val isReliable: Boolean get() =
            !r0Cm.isNaN() && scintillationVar in 1e-5..2.0
    }
}
