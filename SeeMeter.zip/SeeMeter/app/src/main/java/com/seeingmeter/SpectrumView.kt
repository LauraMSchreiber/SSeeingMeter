package com.seeingmeter

import android.content.Context
import android.graphics.*
import android.util.AttributeSet
import android.view.View
import kotlin.math.*

/**
 * Custom View that renders the scintillation power spectral density on a
 * log-frequency / log-power plot, with annotations for the measured
 * characteristic frequency and theoretical Fresnel frequency.
 *
 * Frequency axis:  20 Hz … Nyquist  (log scale)
 * Power axis:      auto-range        (log scale)
 *
 * Overlays:
 *   ── red dashed    measured characteristic frequency  f_char
 *   ── green dashed  theoretical Fresnel frequency      f_Fresnel
 *   ─── grey         Kolmogorov f^(-8/3) reference slope
 */
class SpectrumView @JvmOverloads constructor(
    context: Context, attrs: AttributeSet? = null, defStyle: Int = 0
) : View(context, attrs, defStyle) {

    // Data
    private var freqs: DoubleArray = DoubleArray(0)
    private var psd:   DoubleArray = DoubleArray(0)
    private var fChar:    Double = Double.NaN
    private var fFresnel: Double = Double.NaN

    // Paints
    private val bgPaint    = Paint().apply { color = Color.parseColor("#1A1A2E"); style = Paint.Style.FILL }
    private val gridPaint  = Paint().apply { color = Color.parseColor("#2A2A4A"); strokeWidth = 1f; style = Paint.Style.STROKE }
    private val axisPaint  = Paint().apply { color = Color.parseColor("#8888AA"); strokeWidth = 1.5f; style = Paint.Style.STROKE }
    private val labelPaint = Paint().apply {
        color = Color.parseColor("#AAAACC")
        textSize = 26f
        isAntiAlias = true
    }
    private val specPaint  = Paint().apply {
        color = Color.parseColor("#00D4FF")
        strokeWidth = 2.5f
        style = Paint.Style.STROKE
        isAntiAlias = true
        strokeJoin = Paint.Join.ROUND
    }
    private val fCharPaint = Paint().apply {
        color = Color.parseColor("#FF4444")
        strokeWidth = 2f
        style = Paint.Style.STROKE
        pathEffect = DashPathEffect(floatArrayOf(12f, 8f), 0f)
    }
    private val fFresnelPaint = Paint().apply {
        color = Color.parseColor("#44FF88")
        strokeWidth = 2f
        style = Paint.Style.STROKE
        pathEffect = DashPathEffect(floatArrayOf(8f, 6f), 0f)
    }
    private val slopePaint = Paint().apply {
        color = Color.parseColor("#555577")
        strokeWidth = 1.5f
        style = Paint.Style.STROKE
        pathEffect = DashPathEffect(floatArrayOf(6f, 6f), 0f)
    }
    private val noDataPaint = Paint().apply {
        color = Color.parseColor("#666688")
        textSize = 36f
        isAntiAlias = true
        textAlign = Paint.Align.CENTER
    }
    private val annotationPaint = Paint().apply {
        color = Color.WHITE
        textSize = 24f
        isAntiAlias = true
    }

    // Plot margins (px)
    private val ml = 110f   // left   (y-axis labels)
    private val mr = 20f    // right
    private val mt = 20f    // top
    private val mb = 60f    // bottom (x-axis labels)

    fun updateSpectrum(
        freqs: DoubleArray,
        psd: DoubleArray,
        fCharHz: Double,
        fFresnelHz: Double
    ) {
        this.freqs    = freqs
        this.psd      = psd
        this.fChar    = fCharHz
        this.fFresnel = fFresnelHz
        postInvalidate()
    }

    override fun onDraw(canvas: Canvas) {
        super.onDraw(canvas)
        val W = width.toFloat()
        val H = height.toFloat()

        // Background
        canvas.drawRect(0f, 0f, W, H, bgPaint)

        if (freqs.isEmpty() || psd.isEmpty()) {
            canvas.drawText("Collecting data…", W / 2, H / 2, noDataPaint)
            return
        }

        // ── Axis ranges ─────────────────────────────────────────────────────
        val fMin = 20.0
        val fMax = freqs.last().coerceAtLeast(fMin * 10)

        // Find PSD range above fMin
        var pMin = Double.MAX_VALUE; var pMax = Double.MIN_VALUE
        for (i in freqs.indices) {
            if (freqs[i] < fMin || psd[i] <= 0.0) continue
            if (psd[i] < pMin) pMin = psd[i]
            if (psd[i] > pMax) pMax = psd[i]
        }
        if (pMin >= pMax) { canvas.drawText("No signal", W / 2, H / 2, noDataPaint); return }

        // Add a decade of padding
        val logPMin = floor(log10(pMin)) - 0.5
        val logPMax = ceil(log10(pMax))  + 0.5
        val logFMin = log10(fMin)
        val logFMax = log10(fMax)

        val plotW = W - ml - mr
        val plotH = H - mt - mb

        fun xOf(f: Double) = ml + ((log10(f) - logFMin) / (logFMax - logFMin) * plotW).toFloat()
        fun yOf(p: Double) = mt + ((logPMax - log10(p)) / (logPMax - logPMin) * plotH).toFloat()

        // ── Grid lines (frequency decades) ──────────────────────────────────
        var decade = 10.0
        while (decade <= fMax * 1.1) {
            if (decade >= fMin) {
                val x = xOf(decade)
                canvas.drawLine(x, mt, x, mt + plotH, gridPaint)
                canvas.drawText("${decade.toInt()} Hz", x - 18f, mt + plotH + mb * 0.7f, labelPaint)
            }
            for (sub in 2..9) {
                val f = decade * sub
                if (f in fMin..fMax) canvas.drawLine(xOf(f), mt, xOf(f), mt + plotH, gridPaint)
            }
            decade *= 10.0
        }

        // Power decade grid lines
        var logP = floor(logPMin).toInt()
        while (logP <= ceil(logPMax).toInt()) {
            val p = 10.0.pow(logP.toDouble())
            val y = yOf(p)
            if (y in mt..(mt + plotH)) {
                canvas.drawLine(ml, y, ml + plotW, y, gridPaint)
                val label = when {
                    logP >= 0  -> "1e$logP"
                    else       -> "1e$logP"
                }
                canvas.drawText(label, 4f, y + 9f, labelPaint)
            }
            logP++
        }

        // ── Kolmogorov reference slope f^(-8/3) ──────────────────────────────
        // Anchor it at the midpoint of the spectrum
        val midIdx = freqs.indices.firstOrNull { freqs[it] >= fMin * 10 } ?: 0
        if (midIdx < psd.size && psd[midIdx] > 0) {
            val fAnchor = freqs[midIdx]; val pAnchor = psd[midIdx]
            val slopePath = Path()
            var first = true
            for (i in freqs.indices) {
                val f = freqs[i]
                if (f < fMin || f > fMax) continue
                val pRef = pAnchor * (f / fAnchor).pow(-8.0 / 3.0)
                if (pRef <= 0 || log10(pRef) < logPMin || log10(pRef) > logPMax) continue
                val x = xOf(f); val y = yOf(pRef)
                if (first) { slopePath.moveTo(x, y); first = false } else slopePath.lineTo(x, y)
            }
            canvas.drawPath(slopePath, slopePaint)
            // Label
            val labelX = xOf(fMax * 0.5f)
            val labelF = fMax * 0.5
            val labelP = pAnchor * (labelF / fAnchor).pow(-8.0 / 3.0)
            if (log10(labelP) in logPMin..logPMax)
                canvas.drawText("f⁻⁸/³", labelX + 4f, yOf(labelP) - 6f, slopePaint.apply { pathEffect = null })
        }

        // ── Spectrum line ────────────────────────────────────────────────────
        val specPath = Path()
        var firstPt = true
        for (i in freqs.indices) {
            val f = freqs[i]; val p = psd[i]
            if (f < fMin || f > fMax || p <= 0.0) continue
            if (log10(p) < logPMin || log10(p) > logPMax) continue
            val x = xOf(f); val y = yOf(p)
            if (firstPt) { specPath.moveTo(x, y); firstPt = false } else specPath.lineTo(x, y)
        }
        canvas.drawPath(specPath, specPaint)

        // ── Vertical marker: measured f_char ─────────────────────────────────
        if (fChar.isFinite() && fChar in fMin..fMax) {
            val x = xOf(fChar)
            canvas.drawLine(x, mt, x, mt + plotH, fCharPaint)
            annotationPaint.color = Color.parseColor("#FF6666")
            canvas.drawText("fc=%.0fHz".format(fChar), x + 4f, mt + 30f, annotationPaint)
        }

        // ── Vertical marker: Fresnel frequency ───────────────────────────────
        if (fFresnel.isFinite() && fFresnel in fMin..fMax) {
            val x = xOf(fFresnel)
            canvas.drawLine(x, mt, x, mt + plotH, fFresnelPaint)
            annotationPaint.color = Color.parseColor("#66FF99")
            canvas.drawText("fF=%.0fHz".format(fFresnel), x + 4f, mt + 55f, annotationPaint)
        }

        // ── Axes ─────────────────────────────────────────────────────────────
        canvas.drawRect(ml, mt, ml + plotW, mt + plotH, axisPaint)

        // X-axis label
        labelPaint.textAlign = Paint.Align.CENTER
        canvas.drawText("Frequency (Hz)", ml + plotW / 2, H - 4f, labelPaint)
        labelPaint.textAlign = Paint.Align.LEFT

        // Y-axis label (rotated)
        canvas.save()
        canvas.rotate(-90f, 18f, mt + plotH / 2)
        canvas.drawText("PSD (σ²_I / Hz)", 18f - 60f, mt + plotH / 2, labelPaint)
        canvas.restore()
    }
}
