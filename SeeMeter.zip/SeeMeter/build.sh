#!/data/data/com.termux/files/usr/bin/bash
# ============================================================
#  SeeMeter — Termux build script
#  Run from anywhere:  bash ~/SeeMeter/build.sh
# ============================================================
set -e

RED='\033[0;31m'; GRN='\033[0;32m'; YEL='\033[1;33m'; NC='\033[0m'
info()  { echo -e "${GRN}[✔]${NC} $1"; }
warn()  { echo -e "${YEL}[!]${NC} $1"; }
die()   { echo -e "${RED}[✘]${NC} $1"; exit 1; }

SCRIPT_DIR="$(cd "$(dirname "$0")" && pwd)"
SDK_DIR="$HOME/android-sdk"
GRADLE_VER="8.6"
GRADLE_DIR="$HOME/gradle-${GRADLE_VER}"
CMDTOOLS_VER="11076708"
DOWNLOADS="/sdcard/Download"

echo ""
echo "╔══════════════════════════════════════╗"
echo "║   SeeMeter — Termux Builder          ║"
echo "╚══════════════════════════════════════╝"
echo ""

# ── 1. Install system packages ────────────────────────────────
info "Installing packages (openjdk-17, wget, unzip)..."
pkg update -y -q 2>/dev/null
pkg install -y -q openjdk-17 wget unzip 2>/dev/null || \
    die "pkg install failed. Check your internet connection."

java -version 2>&1 | head -1 | grep -q "17\|21" || \
    die "Java 17+ required. Try: pkg install openjdk-17"

info "Java OK: $(java -version 2>&1 | head -1)"

# ── 2. Android SDK command-line tools ─────────────────────────
CMDTOOLS_ZIP="$HOME/cmdtools.zip"
SDKMANAGER="$SDK_DIR/cmdline-tools/latest/bin/sdkmanager"

if [ -x "$SDKMANAGER" ]; then
    info "SDK command-line tools already present."
else
    info "Downloading Android SDK command-line tools (~130 MB)..."
    mkdir -p "$SDK_DIR/cmdline-tools"
    wget -q --show-progress \
        "https://dl.google.com/android/repository/commandlinetools-linux-${CMDTOOLS_VER}_latest.zip" \
        -O "$CMDTOOLS_ZIP" || die "Failed to download SDK tools."

    unzip -q "$CMDTOOLS_ZIP" -d "$SDK_DIR/cmdline-tools/"
    # Google puts it in cmdline-tools/cmdline-tools — move to cmdline-tools/latest
    if [ -d "$SDK_DIR/cmdline-tools/cmdline-tools" ]; then
        mv "$SDK_DIR/cmdline-tools/cmdline-tools" "$SDK_DIR/cmdline-tools/latest"
    fi
    rm -f "$CMDTOOLS_ZIP"
    info "SDK tools extracted."
fi

export ANDROID_HOME="$SDK_DIR"
export ANDROID_SDK_ROOT="$SDK_DIR"
export PATH="$PATH:$SDK_DIR/cmdline-tools/latest/bin:$SDK_DIR/platform-tools"

# ── 3. Install SDK platform + build-tools ─────────────────────
if [ ! -d "$SDK_DIR/build-tools/34.0.0" ]; then
    info "Accepting SDK licenses..."
    yes | "$SDKMANAGER" --licenses > /dev/null 2>&1 || true

    info "Installing SDK platform-tools, android-34, build-tools 34.0.0..."
    info "(This downloads ~200 MB — may take several minutes on mobile data)"
    "$SDKMANAGER" "platform-tools" "platforms;android-34" "build-tools;34.0.0" \
        || die "sdkmanager failed. Check storage space (need ~500 MB free in ~/)"
    info "SDK components installed."
else
    info "SDK build-tools 34.0.0 already installed."
fi

# ── 4. Gradle ─────────────────────────────────────────────────
if [ -x "$GRADLE_DIR/bin/gradle" ]; then
    info "Gradle ${GRADLE_VER} already present."
else
    info "Downloading Gradle ${GRADLE_VER} (~130 MB)..."
    wget -q --show-progress \
        "https://services.gradle.org/distributions/gradle-${GRADLE_VER}-bin.zip" \
        -O "$HOME/gradle.zip" || die "Failed to download Gradle."
    unzip -q "$HOME/gradle.zip" -d "$HOME/"
    rm -f "$HOME/gradle.zip"
    info "Gradle extracted."
fi

export PATH="$PATH:$GRADLE_DIR/bin"

# ── 5. Project configuration ──────────────────────────────────
cd "$SCRIPT_DIR"

info "Writing local.properties..."
echo "sdk.dir=$SDK_DIR" > local.properties

info "Writing gradle.properties..."
cat > gradle.properties << EOF
# Termux build settings
android.useAndroidX=true
android.enableJetifier=false
org.gradle.jvmargs=-Xmx1536m -XX:+HeapDumpOnOutOfMemoryError
org.gradle.daemon=true
org.gradle.parallel=false
EOF

# ── 6. Gradle wrapper (create minimal one that uses our Gradle) ─
mkdir -p gradle/wrapper
cat > gradle/wrapper/gradle-wrapper.properties << EOF
distributionBase=GRADLE_USER_HOME
distributionPath=wrapper/dists
distributionUrl=https\://services.gradle.org/distributions/gradle-${GRADLE_VER}-bin.zip
zipStoreBase=GRADLE_USER_HOME
zipStorePath=wrapper/dists
EOF

# ── 7. Build ───────────────────────────────────────────────────
echo ""
info "Starting build...  (first run: 3–8 min; subsequent runs: ~1 min)"
echo ""

GRADLE_USER_HOME="$HOME/.gradle" \
ANDROID_HOME="$SDK_DIR" \
    "$GRADLE_DIR/bin/gradle" \
    --no-daemon \
    --warning-mode none \
    -Dfile.encoding=UTF-8 \
    assembleDebug

# ── 8. Copy APK ────────────────────────────────────────────────
APK="app/build/outputs/apk/debug/app-debug.apk"
if [ -f "$APK" ]; then
    cp "$APK" "$DOWNLOADS/SeeMeter.apk"
    echo ""
    echo -e "${GRN}╔══════════════════════════════════════════════╗${NC}"
    echo -e "${GRN}║  BUILD SUCCESSFUL                            ║${NC}"
    echo -e "${GRN}║  APK → /sdcard/Download/SeeMeter.apk         ║${NC}"
    echo -e "${GRN}╚══════════════════════════════════════════════╝${NC}"
    echo ""
    echo "Install steps:"
    echo "  1. Open  Files  app  → Downloads → SeeMeter.apk"
    echo "  2. Tap Install — Android will ask to allow unknown sources"
    echo "  3. Allow for the Files app, then install"
    echo ""
else
    die "Build failed — APK not found. Check output above for errors."
fi
