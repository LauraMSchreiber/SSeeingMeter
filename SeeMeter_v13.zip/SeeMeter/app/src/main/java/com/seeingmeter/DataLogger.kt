package com.seeingmeter

import android.content.Context
import android.os.Environment
import org.json.JSONArray
import org.json.JSONObject
import java.io.File
import java.text.SimpleDateFormat
import java.util.*
import kotlin.math.*

/**
 * DataLogger — writes all SeeMeter measurement data to a JSON file.
 *
 * JSON structure:
 *   session          — id, start/end UTC, device info
 *   location         — GPS lat/lon/alt/accuracy
 *   atmosphere       — barometer pressure
 *   instrument       — camera, resolution, sample rate, method
 *   parameters       — Seykora formula parameters
 *   meteoblue        — forecast snapshots (start + every full UTC hour)
 *   samples_0_5s     — one record per 0.5 s analysis call
 *   hourly_stats     — statistics per completed UTC hour
 *   overall_stats    — statistics over full session
 *
 * File location: [external storage]/Documents/SeeMeter_YYYYMMDD_HHMMSS.json
 * or app-private Documents if external unavailable.
 */
class DataLogger(private val context: Context) {

    private val root = JSONObject()
    private val samplesArr = JSONArray()
    private val hourlyArr  = JSONArray()
    private val meteoblueArr = JSONArray()

    // Current-hour accumulator
    private val hourBucket = mutableListOf<Pair<Double, Double>>() // (r0_cm, seeing_arcsec)
    private var currentHourUtc: String = ""

    private val iso = SimpleDateFormat("yyyy-MM-dd'T'HH:mm:ss'Z'", Locale.US)
        .also { it.timeZone = TimeZone.getTimeZone("UTC") }
    private val isoMs = SimpleDateFormat("yyyy-MM-dd'T'HH:mm:ss.SSS'Z'", Locale.US)
        .also { it.timeZone = TimeZone.getTimeZone("UTC") }

    val sessionId: String = SimpleDateFormat("yyyyMMdd_HHmmss", Locale.US)
        .also { it.timeZone = TimeZone.getTimeZone("UTC") }
        .format(Date())

    private val fileName = "SeeMeter_$sessionId.json"

    // ── Initialise session ─────────────────────────────────────────────────────

    fun initSession(
        deviceModel: String,
        cameraDesc:  String,
        analysisRes: String
    ) {
        root.put("session", JSONObject().apply {
            put("id",         sessionId)
            put("start_utc",  iso.format(Date()))
            put("end_utc",    JSONObject.NULL)
        })
        root.put("instrument", JSONObject().apply {
            put("device",            deviceModel)
            put("camera",            cameraDesc)
            put("analysis_resolution", analysisRes)
            put("method",            "Seykora (1993) solar scintillometer")
            put("coeff_solar",       SeeingAnalyzer.COEFF_SOLAR)
        })
        root.put("location",    JSONObject.NULL)
        root.put("atmosphere",  JSONObject.NULL)
        root.put("parameters",  JSONObject.NULL)
        root.put("meteoblue",   meteoblueArr)
        root.put("samples_0_5s", samplesArr)
        root.put("hourly_stats", hourlyArr)
        root.put("overall_stats", JSONObject.NULL)
        currentHourUtc = currentHourString()
    }

    // ── Location & atmosphere ──────────────────────────────────────────────────

    fun setLocation(lat: Double, lon: Double, altM: Double, accM: Float) {
        root.put("location", JSONObject().apply {
            put("latitude_deg",  lat)
            put("longitude_deg", lon)
            put("altitude_m",    altM)
            put("accuracy_m",    accM.toDouble())
            put("timestamp_utc", iso.format(Date()))
        })
        saveAsync()
    }

    fun setPressure(hpa: Float) {
        root.put("atmosphere", JSONObject().apply {
            put("pressure_hpa",  hpa.toDouble())
            put("timestamp_utc", iso.format(Date()))
        })
        saveAsync()
    }

    // ── Parameters ─────────────────────────────────────────────────────────────

    fun setParameters(az: SeeingAnalyzer) {
        root.put("parameters", JSONObject().apply {
            put("wavelength_nm",         az.wavelengthNm)
            put("turbulence_height_km",  az.turbulenceHeightM / 1000.0)
            put("wind_speed_ms",         az.windSpeedMs)
            put("zenith_angle_deg",      az.zenithAngleDeg)
            put("solar_radius_arcsec",   az.sunAngularRadiusArcsec)
            put("calibration",           az.solarCalibration)
        })
    }

    fun updateSampleRate(kHz: Double) {
        (root.optJSONObject("instrument") ?: return)
            .put("sample_rate_khz", kHz)
    }

    // ── Meteoblue forecast ─────────────────────────────────────────────────────

    fun addMeteoblueSnapshot(fetchUtc: String, forecastJson: JSONObject) {
        meteoblueArr.put(JSONObject().apply {
            put("fetch_utc", fetchUtc)
            put("forecast",  forecastJson)
        })
        saveAsync()
    }

    // ── 0.5 s sample ──────────────────────────────────────────────────────────

    fun addSample(res: SeeingAnalyzer.AnalysisResult, stats: CameraController.FrameStats) {
        val now = Date()
        val hourNow = currentHourString()

        // Flush completed hour if we rolled over
        if (hourNow != currentHourUtc) {
            flushHourlyStats(currentHourUtc)
            currentHourUtc = hourNow
        }

        // Add to hour bucket
        if (!res.r0Cm.isNaN()) hourBucket.add(Pair(res.r0Cm, res.seeingArcsec))

        // Build sample JSON
        val s = JSONObject().apply {
            put("utc",               isoMs.format(now))
            put("r0_cm",             if (res.r0Cm.isNaN()) JSONObject.NULL else res.r0Cm)
            put("seeing_arcsec",     if (res.seeingArcsec.isNaN()) JSONObject.NULL else res.seeingArcsec)
            put("sigma_i_pct",       res.scintillationSigma * 100.0)
            put("fresnel_hz",        if (res.fresnelFreqHz.isFinite()) res.fresnelFreqHz else JSONObject.NULL)
            put("char_freq_hz",      if (res.characteristicFreqHz.isFinite()) res.characteristicFreqHz else JSONObject.NULL)
            put("h_spectral_km",     if (res.hFromSpectralFitKm.isFinite() && !res.hFromSpectralFitKm.isNaN()) res.hFromSpectralFitKm else JSONObject.NULL)
            put("sample_rate_khz",   res.sampleRateHz / 1000.0)
            put("n_samples",         res.nSamples)
            put("mean_signal_pct",   stats.meanPct)
            put("peak_signal_pct",   stats.peakPct)
            put("sat_rows",          stats.satRows)
            put("total_rows",        stats.totalRows)
        }
        samplesArr.put(s)

        // Save periodically (every 10 samples ≈ 5 s)
        if (samplesArr.length() % 10 == 0) saveAsync()
    }

    // ── Hourly statistics ──────────────────────────────────────────────────────

    private fun flushHourlyStats(hourUtc: String) {
        if (hourBucket.isEmpty()) return
        val r0s    = hourBucket.map { it.first }
        val seeings = hourBucket.map { it.second }
        hourlyArr.put(JSONObject().apply {
            put("hour_utc",               hourUtc)
            put("n_samples",              r0s.size)
            put("r0_cm_mean",             r0s.average())
            put("r0_cm_stddev",           stddev(r0s))
            put("r0_cm_min",              r0s.min())
            put("r0_cm_max",              r0s.max())
            put("r0_cm_median",           median(r0s))
            put("seeing_arcsec_mean",     seeings.average())
            put("seeing_arcsec_stddev",   stddev(seeings))
            put("seeing_arcsec_min",      seeings.min())
            put("seeing_arcsec_max",      seeings.max())
        })
        hourBucket.clear()
        saveAsync()
    }

    // ── Session end ────────────────────────────────────────────────────────────

    fun finalise(): String {
        // Flush any remaining partial hour
        flushHourlyStats(currentHourUtc)

        // Overall statistics
        val allSamples = (0 until samplesArr.length())
            .mapNotNull { samplesArr.optJSONObject(it)?.optDouble("r0_cm") }
            .filter { !it.isNaN() && it > 0 }
        val allSeeing = (0 until samplesArr.length())
            .mapNotNull { samplesArr.optJSONObject(it)?.optDouble("seeing_arcsec") }
            .filter { !it.isNaN() && it > 0 }

        val startStr = root.optJSONObject("session")?.optString("start_utc") ?: ""
        val startMs  = try { iso.parse(startStr)?.time ?: 0L } catch (_: Exception) { 0L }
        val durMin   = (System.currentTimeMillis() - startMs) / 60000.0

        root.optJSONObject("session")?.put("end_utc", iso.format(Date()))
        root.put("overall_stats", JSONObject().apply {
            put("n_samples",          samplesArr.length())
            put("duration_minutes",   durMin)
            if (allSamples.isNotEmpty()) {
                put("r0_cm_mean",       allSamples.average())
                put("r0_cm_stddev",     stddev(allSamples))
                put("r0_cm_min",        allSamples.min())
                put("r0_cm_max",        allSamples.max())
                put("r0_cm_median",     median(allSamples))
            }
            if (allSeeing.isNotEmpty()) {
                put("seeing_arcsec_mean",   allSeeing.average())
                put("seeing_arcsec_stddev", stddev(allSeeing))
                put("seeing_arcsec_min",    allSeeing.min())
                put("seeing_arcsec_max",    allSeeing.max())
            }
        })
        return save()
    }

    // ── File I/O ───────────────────────────────────────────────────────────────

    private fun getOutputFile(): File {
        val dir = context.getExternalFilesDir(Environment.DIRECTORY_DOCUMENTS)
            ?: context.filesDir
        dir.mkdirs()
        return File(dir, fileName)
    }

    fun getFilePath(): String = getOutputFile().absolutePath

    private fun save(): String {
        val f = getOutputFile()
        try { f.writeText(root.toString(2)) } catch (e: Exception) { /* ignore */ }
        return f.absolutePath
    }

    private fun saveAsync() {
        Thread { save() }.start()
    }

    // ── Helpers ────────────────────────────────────────────────────────────────

    private fun stddev(data: List<Double>): Double {
        if (data.size < 2) return 0.0
        val m = data.average()
        return sqrt(data.sumOf { (it - m).pow(2.0) } / (data.size - 1))
    }

    private fun median(data: List<Double>): Double {
        val s = data.sorted()
        return if (s.size % 2 == 0) (s[s.size/2-1] + s[s.size/2]) / 2.0 else s[s.size/2]
    }

    private fun currentHourString(): String {
        val cal = Calendar.getInstance(TimeZone.getTimeZone("UTC"))
        cal.set(Calendar.MINUTE, 0); cal.set(Calendar.SECOND, 0); cal.set(Calendar.MILLISECOND, 0)
        return iso.format(cal.time)
    }
}
