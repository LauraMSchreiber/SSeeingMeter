package com.seeingmeter

import android.Manifest
import android.annotation.SuppressLint
import android.content.Context
import android.content.SharedPreferences
import android.content.pm.PackageManager
import android.graphics.Color
import android.hardware.Sensor
import android.hardware.SensorEvent
import android.hardware.SensorEventListener
import android.hardware.SensorManager
import android.location.Location
import android.location.LocationListener
import android.location.LocationManager
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.util.AttributeSet
import android.view.*
import android.widget.*
import androidx.appcompat.app.AlertDialog
import androidx.appcompat.app.AppCompatActivity
import androidx.core.app.ActivityCompat
import androidx.core.content.ContextCompat

class MainActivity : AppCompatActivity() {

    companion object {
        private const val PERM_CAMERA   = Manifest.permission.CAMERA
        private const val PERM_LOC_FINE = Manifest.permission.ACCESS_FINE_LOCATION
        private const val PERM_LOC_COARSE = Manifest.permission.ACCESS_COARSE_LOCATION
        private const val REQ_CAMERA  = 1001
        private const val REQ_LOC     = 1002
        private const val ANALYSIS_MS = 500L          // 0.5 s
        private const val PREFS       = "SeeMeterPrefs"
    }

    // ── Views ──────────────────────────────────────────────────────────────────
    private lateinit var textureView:    TextureView
    private lateinit var tvR0:           TextView
    private lateinit var tvSeeing:       TextView
    private lateinit var tvSigma:        TextView
    private lateinit var tvFreq:         TextView
    private lateinit var tvStats:        TextView
    private lateinit var tvStatus:       TextView
    private lateinit var tvInfo:         TextView
    private lateinit var tvSignal:       TextView
    private lateinit var tvMeta:         TextView
    private lateinit var btnMeasure:     Button
    private lateinit var timeSeriesView: TimeSeriesView
    private lateinit var spectrumView:   SpectrumView

    // ── Core ───────────────────────────────────────────────────────────────────
    private lateinit var analyzer:         SeeingAnalyzer
    private lateinit var cameraController: CameraController
    private lateinit var dataLogger:       DataLogger
    private lateinit var prefs:            SharedPreferences

    private val mainHandler = Handler(Looper.getMainLooper())
    private var isMeasuring = false

    // ── Session stats (for tvStats) ────────────────────────────────────────────
    private val sessionR0s = mutableListOf<Double>()
    private var sessionStart = 0L

    // ── Sensors ────────────────────────────────────────────────────────────────
    private var currentLocation: Location? = null
    private var currentPressureHpa: Float? = null
    private lateinit var androidSensorManager: SensorManager
    private var pressureSensor: Sensor? = null
    private val pressureListener = object : SensorEventListener {
        override fun onSensorChanged(event: SensorEvent) {
            currentPressureHpa = event.values[0]
            updateMetaBar()
        }
        override fun onAccuracyChanged(sensor: Sensor, accuracy: Int) {}
    }

    // ── Meteoblue ──────────────────────────────────────────────────────────────
    private var meteoblueForecast: MeteoblueClient.Forecast? = null
    private var lastHourlyFetchHour = -1
    private var meteoblueApiKey = ""

    // ── Hourly JSON flush ──────────────────────────────────────────────────────
    private var lastFlushHour = -1

    // ── Lifecycle ──────────────────────────────────────────────────────────────

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        window.addFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON)
        setContentView(R.layout.activity_main)
        bindViews()

        prefs = getSharedPreferences(PREFS, Context.MODE_PRIVATE)
        meteoblueApiKey = prefs.getString("apiKey", "") ?: ""

        analyzer        = SeeingAnalyzer()
        cameraController = CameraController(this, analyzer) { skewNs, expNs, iso ->
            mainHandler.post { updateInfo(skewNs, expNs, iso) }
        }
        dataLogger = DataLogger(this).also {
            it.initSession(
                android.os.Build.MODEL,
                cameraController.selectedCameraDesc,
                "${cameraController.analysisWidth}×${cameraController.analysisHeight}"
            )
        }

        androidSensorManager = getSystemService(SENSOR_SERVICE) as SensorManager
        pressureSensor = androidSensorManager.getDefaultSensor(Sensor.TYPE_PRESSURE)

        setupButtons()
        showSolarWarning()
    }

    override fun onResume() {
        super.onResume()
        pressureSensor?.let {
            androidSensorManager.registerListener(pressureListener, it,
                SensorManager.SENSOR_DELAY_NORMAL)
        }
        if (hasCameraPermission()) openCamera()
    }

    override fun onPause() {
        super.onPause()
        androidSensorManager.unregisterListener(pressureListener)
        stop()
        mainHandler.removeCallbacksAndMessages(null)
        cameraController.detach()
        cameraController.stopBackgroundThread()
    }

    // ── Camera ─────────────────────────────────────────────────────────────────

    private fun openCamera() {
        cameraController.startBackgroundThread()
        cameraController.attachTextureView(textureView)
    }

    // ── Buttons ────────────────────────────────────────────────────────────────

    private fun setupButtons() {
        btnMeasure.setOnClickListener { if (!isMeasuring) start() else stop() }

        findViewById<Button>(R.id.btnSave).setOnClickListener {
            val path = dataLogger.finalise()
            AlertDialog.Builder(this)
                .setTitle("Data saved")
                .setMessage("JSON written to:\n$path")
                .setPositiveButton("OK", null).show()
        }

        findViewById<Button>(R.id.btnReset).setOnClickListener {
            analyzer.reset(); timeSeriesView.clear(); sessionR0s.clear()
            spectrumView.updateSpectrum(DoubleArray(0), DoubleArray(0), Double.NaN, Double.NaN)
            tvR0.text = "r₀ = —"; tvSeeing.text = "Seeing = —"
            tvSigma.text = "σ_I = —"; tvStats.text = "Stats: —"
            tvStatus.text = "Reset"
        }

        findViewById<Button>(R.id.btnSettings).setOnClickListener { showSettings() }
    }

    // ── Measurement ────────────────────────────────────────────────────────────

    private fun start() {
        isMeasuring = true; analyzer.reset(); sessionR0s.clear()
        sessionStart = System.currentTimeMillis()
        btnMeasure.text = "■  Stop"
        btnMeasure.setBackgroundColor(Color.parseColor("#CC2222"))
        tvStatus.text = "Auto-exposing…  hold steady"

        // Log parameters
        dataLogger.setParameters(analyzer)

        // Request GPS
        requestLocation()

        // Fetch meteoblue at start
        fetchMeteoblueAsync()

        mainHandler.postDelayed(loop, ANALYSIS_MS)
    }

    private fun stop() {
        isMeasuring = false
        mainHandler.removeCallbacks(loop)
        btnMeasure.text = "▶  Measure"
        btnMeasure.setBackgroundColor(Color.parseColor("#1B5E20"))
        tvStatus.text = "Stopped  —  tap 💾 Save to export JSON"
    }

    private val loop = object : Runnable {
        override fun run() {
            if (!isMeasuring) return
            tick()
            // Hourly meteoblue refresh + stats flush
            val cal = java.util.Calendar.getInstance(java.util.TimeZone.getTimeZone("UTC"))
            val hour = cal.get(java.util.Calendar.HOUR_OF_DAY)
            if (hour != lastHourlyFetchHour && sessionStart > 0 &&
                System.currentTimeMillis() - sessionStart > 120_000) {
                lastHourlyFetchHour = hour
                fetchMeteoblueAsync()
            }
            mainHandler.postDelayed(this, ANALYSIS_MS)
        }
    }

    // ── Main analysis tick ─────────────────────────────────────────────────────

    private fun tick() {
        val res = analyzer.analyze()
        val fs  = cameraController.lastFrameStats

        // Always update signal bar on every tick even if no result yet
        updateSignalBar(fs)

        if (res == null) {
            tvStatus.text = "Collecting… ${analyzer.framesProcessed} frames"
            return
        }

        // Update instrument sample rate once
        dataLogger.updateSampleRate(res.sampleRateHz / 1000.0)

        // ── r₀ / seeing ─────────────────────────────────────────────────────
        tvR0.text = if (res.r0Cm.isNaN()) "r₀ = —"
                    else "r₀ = %.1f cm  [%s]".format(res.r0Cm, res.qualityLabel)
        tvSeeing.text = if (res.seeingArcsec.isNaN()) "Seeing = —"
                        else "Seeing = %.2f\"".format(res.seeingArcsec)
        tvSigma.text  = "σ_I = %.5f  (%.3f%%)".format(
            res.scintillationSigma, res.scintillationSigma * 100.0)

        val fc = if (res.characteristicFreqHz.isFinite()) "%.0f Hz".format(res.characteristicFreqHz) else "—"
        val ff = if (res.fresnelFreqHz.isFinite()) "%.0f Hz".format(res.fresnelFreqHz) else "—"
        val hs = if (!res.hFromSpectralFitKm.isNaN() && res.hFromSpectralFitKm.isFinite())
            "  H_fit=%.1f km".format(res.hFromSpectralFitKm) else ""
        tvFreq.text   = "f_c=$fc  f_F=$ff$hs"

        // ── Session statistics ───────────────────────────────────────────────
        if (!res.r0Cm.isNaN()) sessionR0s.add(res.r0Cm)
        if (sessionR0s.size >= 2) {
            val mean = sessionR0s.average()
            val sd   = kotlin.math.sqrt(sessionR0s.sumOf { (it - mean) * (it - mean) } / (sessionR0s.size - 1))
            val elapsed = (System.currentTimeMillis() - sessionStart) / 1000.0
            tvStats.text = "n=%d  r₀: μ=%.1f σ=%.1f min=%.1f max=%.1f cm  t=%.0fs".format(
                sessionR0s.size, mean, sd,
                sessionR0s.min(), sessionR0s.max(), elapsed)
        }

        tvStatus.text = "${analyzer.framesProcessed} frames · %.0f kHz · Δt=%.1f µs · H=%.1f km".format(
            res.sampleRateHz / 1000.0, res.rowPeriodUs, res.turbulenceHeightKm)

        // ── Time series & spectrum ───────────────────────────────────────────
        if (!res.r0Cm.isNaN()) timeSeriesView.addSample(res.r0Cm, res.scintillationSigma)
        spectrumView.updateSpectrum(res.freqs, res.psd,
            res.characteristicFreqHz, res.fresnelFreqHz)

        // ── Log to JSON ──────────────────────────────────────────────────────
        dataLogger.addSample(res, fs)
    }

    // ── Signal bar ─────────────────────────────────────────────────────────────

    private fun updateSignalBar(s: CameraController.FrameStats) {
        if (s.totalRows == 0) return
        val hint = when {
            s.satRows > s.totalRows / 10 -> "⚠ SATURATED"
            s.meanPct < 5.0              -> "⚠ UNDEREXPOSED"
            s.meanPct > 85.0             -> "⚠ NEAR SAT"
            s.meanPct in 25.0..70.0      -> "✓ Good"
            else                         -> "OK"
        }
        val col = if (s.satRows > 0 || s.meanPct < 5.0 || s.meanPct > 85.0)
            Color.parseColor("#FF9800") else Color.parseColor("#69F0AE")
        tvSignal.setTextColor(col)
        tvSignal.text = "Signal  mean=%.1f%% (%.0f/255)  peak=%.1f%% (%.0f/255)  sat=%d/%d rows   %s"
            .format(s.meanPct, s.meanRowMean, s.peakPct, s.peakRowMean,
                    s.satRows, s.totalRows, hint)
    }

    // ── Info bar ───────────────────────────────────────────────────────────────

    private fun updateInfo(skewNs: Long, expNs: Long, iso: Int) {
        val expMs  = expNs  / 1_000_000.0
        val skewMs = skewNs / 1_000_000.0
        val kHz    = if (skewMs > 0) cameraController.analysisHeight / (skewMs / 1000.0) / 1000.0 else 0.0
        tvInfo.text = "Exp %.2f ms · ISO %d · RS %.1f ms · ~%.0f kHz · %s · %d×%d".format(
            expMs, iso, skewMs, kHz,
            cameraController.selectedCameraDesc,
            cameraController.analysisWidth, cameraController.analysisHeight)
    }

    // ── Meta bar (GPS / pressure / meteoblue) ──────────────────────────────────

    private fun updateMetaBar() {
        val loc = currentLocation
        val locStr = if (loc != null)
            "GPS %.4f,%.4f ±%.0fm".format(loc.latitude, loc.longitude, loc.accuracy)
        else "GPS: —"
        val pStr = currentPressureHpa?.let { "%.1f hPa".format(it) } ?: "hPa: —"
        val mbStr = meteoblueForecast?.currentSeeingArcsec()
            ?.let { "☁ MB-seeing %.2f\"".format(it) } ?: "Meteoblue: —"
        mainHandler.post { tvMeta.text = "$locStr  ·  $pStr  ·  $mbStr" }
    }

    // ── GPS ────────────────────────────────────────────────────────────────────

    @SuppressLint("MissingPermission")
    private fun requestLocation() {
        if (!hasLocationPermission()) {
            ActivityCompat.requestPermissions(this,
                arrayOf(PERM_LOC_FINE, PERM_LOC_COARSE), REQ_LOC)
            return
        }
        val lm = getSystemService(LOCATION_SERVICE) as LocationManager
        // Try last known first
        val last = lm.getLastKnownLocation(LocationManager.GPS_PROVIDER)
            ?: lm.getLastKnownLocation(LocationManager.NETWORK_PROVIDER)
        if (last != null) handleLocation(last)
        // Also request a fresh fix
        try {
            lm.requestSingleUpdate(LocationManager.GPS_PROVIDER, locationListener, mainLooper)
        } catch (_: Exception) {
            try {
                lm.requestSingleUpdate(LocationManager.NETWORK_PROVIDER, locationListener, mainLooper)
            } catch (_: Exception) {}
        }
    }

    private val locationListener = LocationListener { loc -> handleLocation(loc) }

    private fun handleLocation(loc: Location) {
        currentLocation = loc
        dataLogger.setLocation(loc.latitude, loc.longitude,
            loc.altitude, loc.accuracy)
        updateMetaBar()
    }

    // ── Meteoblue ──────────────────────────────────────────────────────────────

    private fun fetchMeteoblueAsync() {
        val loc = currentLocation ?: return
        val key = meteoblueApiKey
        if (key.isBlank()) { return }
        Thread {
            val fc = MeteoblueClient.fetch(loc.latitude, loc.longitude, loc.altitude, key)
            if (fc != null) {
                meteoblueForecast = fc
                // Build compact JSON for logging
                val fJson = fc.rawJson
                dataLogger.addMeteoblueSnapshot(fc.fetchUtc, fJson)
                mainHandler.post { updateMetaBar() }
            }
        }.start()
    }

    // ── Settings ────────────────────────────────────────────────────────────────

    private fun showSettings() {
        val v = layoutInflater.inflate(R.layout.dialog_settings, null)
        val etZ   = v.findViewById<EditText>(R.id.etZenith)
        val etH   = v.findViewById<EditText>(R.id.etHeight)
        val etW   = v.findViewById<EditText>(R.id.etWind)
        val etL   = v.findViewById<EditText>(R.id.etLambda)
        val etSun = v.findViewById<EditText>(R.id.etSunRadius)
        val etCal = v.findViewById<EditText>(R.id.etCalib)
        val etKey = v.findViewById<EditText>(R.id.etApiKey)
        etZ.setText("%.1f".format(analyzer.zenithAngleDeg))
        etH.setText("%.1f".format(analyzer.turbulenceHeightM / 1000.0))
        etW.setText("%.1f".format(analyzer.windSpeedMs))
        etL.setText("%.0f".format(analyzer.wavelengthNm))
        etSun.setText("%.0f".format(analyzer.sunAngularRadiusArcsec))
        etCal.setText("%.2f".format(analyzer.solarCalibration))
        etKey.setText(meteoblueApiKey)
        AlertDialog.Builder(this, android.R.style.Theme_Material_Dialog_Alert)
            .setTitle("Parameters")
            .setView(v)
            .setPositiveButton("Apply") { _, _ ->
                etZ.text.toString().toDoubleOrNull()?.let  { analyzer.zenithAngleDeg        = it.coerceIn(0.0,85.0) }
                etH.text.toString().toDoubleOrNull()?.let  { analyzer.turbulenceHeightM     = (it*1000).coerceIn(50.0,20000.0) }
                etW.text.toString().toDoubleOrNull()?.let  { analyzer.windSpeedMs           = it.coerceIn(0.5,50.0) }
                etL.text.toString().toDoubleOrNull()?.let  { analyzer.wavelengthNm          = it.coerceIn(400.0,700.0) }
                etSun.text.toString().toDoubleOrNull()?.let{ analyzer.sunAngularRadiusArcsec = it.coerceIn(800.0,1100.0) }
                etCal.text.toString().toDoubleOrNull()?.let{ analyzer.solarCalibration      = it.coerceIn(0.1,10.0) }
                meteoblueApiKey = etKey.text.toString().trim()
                prefs.edit().putString("apiKey", meteoblueApiKey).apply()
            }
            .setNegativeButton("Cancel", null).show()
    }

    // ── Solar safety warning ───────────────────────────────────────────────────

    private fun showSolarWarning() {
        AlertDialog.Builder(this, android.R.style.Theme_Material_Dialog_Alert)
            .setTitle("☀  SOLAR SAFETY")
            .setMessage(
                "WITHOUT a proper solar filter the camera sensor will be PERMANENTLY DAMAGED.\n\n" +
                "Required: Baader AstroSolar ND 5.0 film over ALL rear lenses.\n\n" +
                "Setup:\n" +
                "1. Attach solar filter over rear camera\n" +
                "2. Place white paper diffuser over the filter\n" +
                "3. Point at the Sun · press MEASURE\n\n" +
                "Tap ⚙ to enter your meteoblue API key for forecast comparison.\n" +
                "Data is saved as JSON — tap 💾 Save when done."
            )
            .setPositiveButton("I have a solar filter") { _, _ ->
                val perms = mutableListOf(PERM_CAMERA)
                if (!hasLocationPermission()) {
                    perms.add(PERM_LOC_FINE); perms.add(PERM_LOC_COARSE)
                }
                if (!hasCameraPermission())
                    ActivityCompat.requestPermissions(this, perms.toTypedArray(), REQ_CAMERA)
            }
            .setNegativeButton("Exit") { _, _ -> finish() }
            .setCancelable(false).show()
    }

    // ── Permissions ────────────────────────────────────────────────────────────

    private fun hasCameraPermission() =
        ContextCompat.checkSelfPermission(this, PERM_CAMERA) == PackageManager.PERMISSION_GRANTED

    private fun hasLocationPermission() =
        ContextCompat.checkSelfPermission(this, PERM_LOC_FINE) == PackageManager.PERMISSION_GRANTED ||
        ContextCompat.checkSelfPermission(this, PERM_LOC_COARSE) == PackageManager.PERMISSION_GRANTED

    override fun onRequestPermissionsResult(
        requestCode: Int, permissions: Array<String>, grantResults: IntArray
    ) {
        super.onRequestPermissionsResult(requestCode, permissions, grantResults)
        if (requestCode == REQ_CAMERA || requestCode == REQ_LOC) {
            if (hasCameraPermission()) openCamera()
        }
    }

    private fun bindViews() {
        textureView    = findViewById(R.id.textureView)
        tvR0           = findViewById(R.id.tvR0)
        tvSeeing       = findViewById(R.id.tvSeeing)
        tvSigma        = findViewById(R.id.tvSigma)
        tvFreq         = findViewById(R.id.tvFreq)
        tvStats        = findViewById(R.id.tvStats)
        tvStatus       = findViewById(R.id.tvStatus)
        tvInfo         = findViewById(R.id.tvInfo)
        tvSignal       = findViewById(R.id.tvSignal)
        tvMeta         = findViewById(R.id.tvMeta)
        btnMeasure     = findViewById(R.id.btnMeasure)
        timeSeriesView = findViewById(R.id.timeSeriesView)
        spectrumView   = findViewById(R.id.spectrumView)
    }
}

class RoiOverlayView @JvmOverloads constructor(
    context: android.content.Context, attrs: AttributeSet? = null, defStyle: Int = 0
) : android.view.View(context, attrs, defStyle)
