package com.seeingmeter

import android.util.Log
import org.json.JSONObject
import java.net.HttpURLConnection
import java.net.URL
import java.text.SimpleDateFormat
import java.util.*

/**
 * Meteoblue astronomical seeing forecast client.
 *
 * API: https://my.meteoblue.com/packages/seeing_3h
 * Free tier: register at meteoblue.com → API Keys → create key
 *
 * The "seeing_3h" package provides 3-hourly forecasts of:
 *   seeing       — quality index 1–8 (1 = exceptional, 8 = very poor)
 *   transparency — sky transparency 1–8
 *   lifted_index — atmospheric stability (positive = stable)
 *   rh2m         — relative humidity at 2 m (%)
 *   wind10m      — wind speed at 10 m (m/s)
 *
 * Seeing index → approximate arcseconds (Antoniazzi conversion):
 *   1 → 0.5"   2 → 0.75"  3 → 1.0"   4 → 1.25"
 *   5 → 1.5"   6 → 2.0"   7 → 2.5"   8 → 3.5"+
 */
object MeteoblueClient {

    const val TAG = "MeteoblueClient"

    private val INDEX_TO_ARCSEC = mapOf(
        1 to 0.50, 2 to 0.75, 3 to 1.00, 4 to 1.25,
        5 to 1.50, 6 to 2.00, 7 to 2.50, 8 to 3.50
    )

    data class Forecast(
        val fetchUtc:          String,
        val times:             List<String>,
        val seeingIndex:       List<Int>,
        val seeingArcsec:      List<Double>,
        val transparency:      List<Int>,
        val liftedIndex:       List<Double>,
        val rh2m:              List<Double>,
        val windMs:            List<Double>,
        val rawJson:           JSONObject
    ) {
        /** Seeing closest to the current time. */
        fun currentSeeingArcsec(): Double? {
            if (times.isEmpty()) return null
            val now = System.currentTimeMillis()
            val sdf = SimpleDateFormat("yyyy-MM-dd HH:mm", Locale.US)
                .also { it.timeZone = TimeZone.getTimeZone("UTC") }
            val idx = times.indices.minByOrNull { i ->
                try { abs(sdf.parse(times[i])!!.time - now) }
                catch (_: Exception) { Long.MAX_VALUE }
            } ?: 0
            return if (idx < seeingArcsec.size) seeingArcsec[idx] else null
        }
    }

    /**
     * Fetch seeing forecast. Runs synchronously — call from background thread.
     * @param lat      Latitude (decimal degrees)
     * @param lon      Longitude (decimal degrees)
     * @param altM     Altitude above sea level (metres)
     * @param apiKey   Meteoblue API key
     * @return Forecast object, or null on failure
     */
    fun fetch(lat: Double, lon: Double, altM: Double, apiKey: String): Forecast? {
        if (apiKey.isBlank()) { Log.w(TAG, "No API key"); return null }
        val url = "https://my.meteoblue.com/packages/seeing_3h" +
            "?lat=%.4f&lon=%.4f&asl=%.0f&format=json&apikey=%s".format(
                lat, lon, altM, apiKey.trim())
        return try {
            val conn = (URL(url).openConnection() as HttpURLConnection).apply {
                connectTimeout = 10_000; readTimeout = 15_000
                requestMethod = "GET"
            }
            val code = conn.responseCode
            if (code != 200) { Log.e(TAG, "HTTP $code from meteoblue"); return null }
            val body = conn.inputStream.bufferedReader().readText()
            conn.disconnect()
            parse(body)
        } catch (e: Exception) {
            Log.e(TAG, "fetch failed: $e"); null
        }
    }

    private fun parse(json: String): Forecast? {
        return try {
            val root = JSONObject(json)
            val d    = root.optJSONObject("data_3h") ?: return null
            val sdf  = SimpleDateFormat("yyyy-MM-dd'T'HH:mm:ss'Z'", Locale.US)
                .also { it.timeZone = TimeZone.getTimeZone("UTC") }

            fun arr(key: String) = d.optJSONArray(key)
            fun intList(key: String): List<Int> {
                val a = arr(key) ?: return emptyList()
                return (0 until a.length()).map { a.optInt(it) }
            }
            fun dblList(key: String): List<Double> {
                val a = arr(key) ?: return emptyList()
                return (0 until a.length()).map { a.optDouble(it) }
            }
            fun strList(key: String): List<String> {
                val a = arr(key) ?: return emptyList()
                return (0 until a.length()).map { a.optString(it) }
            }

            val seeingIdx = intList("seeing")
            val seearcsec = seeingIdx.map { INDEX_TO_ARCSEC[it] ?: 3.5 }

            Forecast(
                fetchUtc     = sdf.format(Date()),
                times        = strList("time"),
                seeingIndex  = seeingIdx,
                seeingArcsec = seearcsec,
                transparency = intList("transparency"),
                liftedIndex  = dblList("lifted_index"),
                rh2m         = dblList("rh2m"),
                windMs       = dblList("wind10m"),
                rawJson      = d
            )
        } catch (e: Exception) {
            Log.e(TAG, "parse failed: $e"); null
        }
    }

    private fun abs(l: Long) = if (l < 0) -l else l
}
