# SeeingMeter — Android Solar Scintillometer

Single-aperture Seykora (1993) solar scintillometer using a Samsung phone with
a paper diffuser over the lens. The rolling shutter reads each row at a slightly
different time, giving a ~100 kHz intensity time series that is inverted into
the Fried coherence radius **r₀** and seeing FWHM.

## Build the APK on the phone (no PC needed)

1.  Create a new public GitHub repo (e.g. `seemeter`).
2.  From the GitHub mobile web (or the GitHub app), upload **every file in the
    ZIP**, keeping the folder paths exactly as they are. When the web UI asks
    for a filename, you can type a path with `/` to create folders, e.g.
    `app/src/main/java/com/seeingmeter/Config.kt`.
3.  After the last file is committed, open the **Actions** tab. The workflow
    *Build APK* runs automatically. (≈2–4 min the first time.)
4.  When it shows a green tick, open the run → **Artifacts** →
    `SeeingMeter-<n>` (n = the run number) and download. Tap the downloaded ZIP, extract,
    and install `app-debug.apk` (you may need to allow installs from your
    file manager / browser).

If a build fails, the log in the Actions tab is verbose and self-explanatory.

## Versioning (automatic)

The version is the **GitHub Actions run number**: it is `1` on the first build
of a fresh repo and increments by one on every build. It appears as the app name
(`SeeingMeter-<n>`), the `versionName`/`versionCode`, and the JSON filename
prefix. Nothing to edit by hand. (Local builds with no CI default to `1`.)

## Reading the top status lines (use these to debug exposure)

- **Line 1** shows `Exp=<actual>ms(set <intended>)`, `ISO=<actual>(set …)`, and
  `AE:OFF` / `AE:ON⚠`. These come straight from the camera's *capture result*,
  i.e. what the sensor really did. If you see **`AE:ON⚠`**, the camera is still
  auto-exposing and exposure-locking is NOT working on that camera — switch to a
  camera not marked `NO-MANUAL` in Settings. If `actual` tracks `set` and stays
  put as you re-aim, locking works.
- **Line 2** shows `peak=<counts>/255` and `mean=<counts>/255` in **raw counts**,
  with a flag: 🔴 OVERFLOW (clipping at 255), 🟠 N saturated rows, 🔵 underflow
  (too dark), or ✓. This is the over/underflow indicator.

## What changed vs v14

| | v14 | **v15** |
|---|---|---|
| Auto-exposure | unlocked, per-frame normalisation | **locked**, re-validated **before every frame**, re-solved only if it drifts out of band |
| Normalisation | divide each row by its frame mean (high-pass at ~50 Hz) | divide by **window mean** → keeps the full intra-window band → continuous seeing time series |
| Variance σ²_I | total time-domain | **band-limited** ∫[bandLow..bandHigh] (PSD − noiseFloor) df |
| Camera | hard-coded `"0"` | **adjustable from the Settings dialog** (lists every physical camera with focal/f/manual capability) |
| File count | ~10 | 5 Kotlin files (easier to scroll on phone) |
| Build | needs Android Studio | **GitHub Actions builds the APK in the cloud** |

## Architecture (5 files)

| File | Role |
|---|---|
| `Config.kt` | every tunable parameter in one place; reads/writes SharedPreferences; serialises into the JSON log. **Add a new parameter here and it propagates everywhere.** |
| `SeeingEngine.kt` | pure maths: ring buffer, radix-2 FFT + Welch PSD, solar zenith, Seykora inversion, the analyzer pipeline, the exposure-validation decision function |
| `CameraModule.kt` | Camera2 enumeration + manual-exposure capture loop with per-frame validation & re-lock |
| `DataModule.kt` | session JSON model, `Download/seeing/` writer via MediaStore, meteoblue client |
| `MainActivity.kt` | UI built in code (TextureView preview, results panel, params bar, in-code settings dialog, custom TimeSeries + Spectrum views, buttons) |

## Physics (Seykora)

    σ²_I = COEFF · k^(-5/6) · sec(z)^(5/6) · H^(-1/6) · λ / α_s² · r0^(-5/3)

where `k = 2π/λ`, `α_s` is the solar angular diameter, `H` the turbulent layer
height, `sec(z)` the airmass, and `COEFF ≈ 13.47`. Inverted in
`Physics.r0FromVariance`. Seeing FWHM ε = 0.98 · λ / r₀.

The textbook coefficient will not be exactly right for *your* camera+diffuser
(throughput, band, geometry). **Calibrate `Config.coeffSolar` against meteoblue
or a reference monitor**; the Settings dialog exposes it.

## JSON output

Path: `Download/seeing/SeeingMeter-<ver>_YYYYMMDD_HHMMSS.json` (via MediaStore,
visible in any file manager). Rewritten every ~5 s, finalised on **Save**.

Schema:

```jsonc
{
  "session":   { "appVersion": "15", "startedMs": ..., "endedMs": ..., "durationSec": ... },
  "gps":       { "lat": ..., "lon": ..., "accM": ..., "altM": ... },
  "pressureHpa": ...,
  "instrument": { "device": "...", "android": "...", "camera": "..." },
  "parameters": { ... all of Config.toJson() ... },   // self-describing run
  "meteoblue":  [ { "fetchedMs": ..., "indexNow": ..., "arcsecNow": ..., "raw": {...} }, ... ],
  "samples":    [ { "t": ..., "r0": ..., "seeing": ..., "sigma2I": ..., "fChar": ...,
                    "fFresnel": ..., "hFit": ..., "noiseFloor": ..., "quality": "...",
                    "expNs": ..., "iso": ..., "meanFrac": ... }, ... ],
  "hourly":     [ ... ],
  "overall":    { "seeingArcsec": { "n":..., "mean":..., "sd":..., "min":..., "max":... },
                  "r0M":          { ... } }
}
```

Adding a field to a sample: edit `SeeingResult` (in `SeeingEngine.kt`) and the
`put(...)` block in `DataLogger.addSample` (in `DataModule.kt`). Older readers
ignore unknown keys.

## Known device-tuning points

- **Row sample rate** is read from `SENSOR_ROLLING_SHUTTER_SKEW` per frame. If a
  device does not report it, the analyzer falls back to its previous estimate;
  log a frame to confirm.
- **Inter-frame blanking** introduces a small periodic gap (≈ frame rate ≈ 50 Hz)
  in the row stream. The Welch PSD treats samples as uniform with the mean rate,
  so a faint comb at ≈ frame-rate is normal. Increase `Config.bandLowHz` if it
  contaminates the band.
- **Flat-fielding** (your requested #2): tap **▦ Flat** while measuring, aimed at
  the uniform diffuser. It averages 30 frames into a per-row sensitivity profile
  (normalised to mean 1), divides every subsequent row by it (removing the fixed
  row pattern + vignetting that otherwise add a comb to the PSD), and persists it
  per camera in the app's files dir (`flat_<cameraId>.csv`). Re-capture if you
  change the diffuser or exposure.
- **Wind from meteoblue** (your requested #3): each fetch parses the seeing
  package for a jetstream/wind field and feeds it into `Config.assumedWindMs`
  (used for f_Fresnel and the height estimate). If no wind field is found it
  keeps the manual default. The full meteoblue response is stored under
  `meteoblue[].raw` in the JSON — read it to confirm the exact field names and
  tell me if you want the parser tightened to a specific key.
- **Meteoblue API key**: shipped as the default in `Config.meteoblueApiKey`.
  ⚠ It is embedded in the APK and in the repo — **keep the GitHub repo PRIVATE**
  (a key in the APK is extractable regardless, so rotate it if it ever leaks).
  It is deliberately NOT written into the JSON session files.
