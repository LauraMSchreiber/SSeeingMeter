plugins {
    id("com.android.application")
    id("org.jetbrains.kotlin.android")
}

// -----------------------------------------------------------------------------
//  Version is AUTOMATIC. GitHub Actions sets SEEINGMETER_VERSION to the workflow
//  run number (1, 2, 3, ... — starts at 1 in a fresh repo and increments on every
//  build). Local builds with no env var fall back to "1".
// -----------------------------------------------------------------------------
val appVer: String = System.getenv("SEEINGMETER_VERSION") ?: "18"

android {
    namespace = "com.seeingmeter"
    compileSdk = 35

    defaultConfig {
        applicationId = "com.seeingmeter"
        minSdk = 29           // MediaStore Downloads RELATIVE_PATH needs API 29+
        targetSdk = 35
        versionCode = appVer.toIntOrNull() ?: 1
        versionName = appVer

        // app launcher name → "SeeingMeter-<ver>"
        resValue("string", "app_name", "SeeingMeter-$appVer")
        // readable from code as Config.APP_VERSION
        buildConfigField("String", "APP_VERSION", "\"$appVer\"")
    }

    buildFeatures { buildConfig = true }

    buildTypes {
        release { isMinifyEnabled = false }
        debug   { isMinifyEnabled = false }
    }

    compileOptions {
        sourceCompatibility = JavaVersion.VERSION_17
        targetCompatibility = JavaVersion.VERSION_17
    }
    kotlinOptions { jvmTarget = "17" }
}

dependencies {
    implementation("androidx.core:core-ktx:1.13.1")
}
